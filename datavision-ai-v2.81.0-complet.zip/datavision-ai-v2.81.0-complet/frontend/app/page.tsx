'use client';

import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import {
  getColumnAnalysis, getDataset, getDatasetAccessContext, getDecision, getPreview, getProfile, getQuality, getQualityRemediation, previewQualityRemediation, applyQualityRemediation, getVersions,
  predictModel, runAnova, runClustering, runPca, runRegression, transformDataset,
  trainModel, uploadDataset, getDatasetCatalog, combineDataset, getPipelines, savePipeline, validatePipeline, runPipeline,
  runCorrelations, runStatisticalTest, getTestAdvice, getEngineInfo, runSql, recommendVisualizations, buildVisualization, editVisualization, composeVisualizations, runAutoML,
  runForecast, runAnomalyDetection, getModelDiagnostics, explainModelPrediction, getAIAnalystCapabilities, runAIAnalysis, startAIAnalysisRun, streamAIAnalysisRun, cancelAIAnalysisRun,
  runNaturalLanguageQuery, getAIHistory, getAIHistoryItem, getReports, createReport, previewStorytelling, publishReport, getReportPublication, validateReport, downloadReport, getDashboard, getInsights, scanInsights, getInsightHistory, saveVisualization, getSavedVisualizations,
  getModelEngines, runModelBenchmark, runMLSafetyAudit, getAutoMLExperiments, getModelXAICapabilities, runModelPDP, runModelSHAP, runModelXAIAudit, runModelCounterfactuals,
  getDashboards, getDashboardDefinition, saveDashboardDefinition, deleteDashboardDefinition, previewDashboard,
  getSemanticModel, saveSemanticModel, evaluateSemanticMetric, getMetricPulse, getSemanticTableCatalog, validateSemanticModel, querySemanticMetric, getTrustCenter, runModelWhatIf, runModelSensitivity, runRootCauseAnalysis, optimizeModelScenarios,
  getProactiveSummary, getProactiveWatches, autoConfigureProactiveWatches, scanProactiveSignals, getProactiveInbox, updateProactiveAlertStatus,
  bootstrapEnterprise, loginEnterprise, getEnterpriseAuthStatus, getEnterpriseSession, getEnterprisePreferences, saveEnterprisePreferences, getEnterpriseStatus, getEntrepriseReadiness, enforceEntreprisePrivateAI, createEnterpriseWorkspace, getEnterpriseWorkspace, addWorkspaceMember, bindWorkspaceDataset, saveWorkspacePolicy, getAuditEvents, getEnterpriseJobs, submitEnterpriseJob, cancelEnterpriseJob, getGovernedPreview, getGovernanceControlPlane, captureGovernanceSnapshot, getGovernanceSnapshots,
  getEnterpriseAuthSessions, revokeEnterpriseAuthSession, logoutAllEnterpriseSessions, getEnterpriseMFAStatus, beginEnterpriseWebAuthnRegistration, verifyEnterpriseWebAuthnRegistration, disableEnterpriseWebAuthnCredential, verifyEnterpriseWebAuthnLogin, getPublicOIDCProviders, startEnterpriseOIDC, exchangeEnterpriseOIDC,
  getWorkspaceOIDCProviders, createWorkspaceOIDCProvider, disableWorkspaceOIDCProvider, getWorkspaceSecrets, createWorkspaceSecret, rotateWorkspaceSecret, testWorkspaceSecret,
  getWorkspacePlugins, installWorkspacePlugin, updateWorkspacePlugin, deleteWorkspacePlugin, testWorkspacePlugin, syncWorkspacePlugin, getWorkspacePluginDetail,
  getReviewSummary, getReviews, getReviewDetail, createReview, assignReview, transitionReview, addReviewComment, resolveReviewComment, getCollaborationNotifications, markCollaborationNotificationRead, getCertifications, certifyReview, revokeCertification,
  getCollaborationTeams, createCollaborationTeam, getCollaborationShares, createCollaborationShare, revokeCollaborationShare, getCollaborationDecisions, getReviewDiff, markAllCollaborationNotificationsRead, createCollaborationRealtimeTicket, collaborationWebSocketUrl,
  getConnectorCatalog, getConnectorOverview, getConnectorHealth, createDataConnector, testDataConnector, discoverDataConnector, createConnectorSource, deleteConnectorSource, previewConnectorSource, refreshConnectorSource, saveConnectorSchedule, getRefreshRuns,
  getReliabilitySummary, getDataContracts, saveDataContract, deleteDataContract, runDataContract, getContractRuns, getLineageGraph, getImpactAnalysis, getPublicationGate, getDataCatalogAssets, getDataCatalogSummary, saveDataCatalogAsset,
  getOperationalOverview, getOperationalUsage, getOperationalTelemetry, getSREStatus, getPerformanceEvidence, runLocalPerformanceBenchmark, emitSREAlerts, getEvaluationSuites, createEvaluationSuite, getEvaluationSuite, addEvaluationCase, runEvaluationSuite, getEvaluationRun,
  getActionSummary, getActionDestinations, createActionDestination, deleteActionDestination, getActionRules, saveActionRule, deleteActionRule, dispatchActionEvent, getActionRuns, getActionRun, approveActionRun, rejectActionRun, replayActionRun, testActionDestination,
} from '../lib/api';
import { assistantEventBus } from '../lib/assistant/event-bus';
import { AIProviderControlCenter } from '../components/assistant/AIProviderControlCenter';
import { NotebookStudio } from '../components/NotebookStudio';
import { ResponsibleAIView } from '../components/ResponsibleAIView';
import { ModelRegistryView } from '../components/ModelRegistryView';
import { FeatureServingView } from '../components/FeatureServingView';
import { ComplianceCenter } from '../components/ComplianceCenter';
import { RegulatoryCompliancePanel } from '../components/RegulatoryCompliancePanel';
import { browserLocale, isLocale, localeDirection, LOCALES, translate } from '../lib/i18n';
import type { Locale } from '../lib/i18n';

type AnyObj = Record<string, any>;
type View = 'identity' | 'actions' | 'operations' | 'reliability' | 'sources' | 'home' | 'data' | 'stats' | 'tests' | 'quality' | 'prepare' | 'visual' | 'sql' | 'notebook' | 'regression' | 'anova' | 'pca' | 'cluster' | 'model' | 'registry' | 'serving' | 'forecast' | 'anomaly' | 'xai' | 'responsible' | 'predict' | 'ai' | 'insights' | 'inbox' | 'semantic' | 'decision' | 'trust' | 'dashboard' | 'report' | 'review' | 'governance' | 'ai-settings' | 'plugins' | 'compliance';
type AreaKey = 'overview'|'data'|'analyze'|'model'|'decide'|'publish'|'collaborate'|'governance';
type AccessibilityMode = 'normal' | 'comfortable' | 'large';

const areaConfig: { key:AreaKey; label:string; icon:string; defaultView:View; views:View[] }[] = [
  {key:'overview',label:'Vue d’ensemble',icon:'⌂',defaultView:'home',views:['home']},
  {key:'data',label:'Données',icon:'▦',defaultView:'data',views:['data','quality','prepare','stats']},
  {key:'analyze',label:'Analyser',icon:'∑',defaultView:'visual',views:['visual','tests','sql','notebook','regression','anova','pca','cluster']},
  {key:'model',label:'Modéliser',icon:'◆',defaultView:'model',views:['model','registry','serving','forecast','anomaly','xai','responsible','predict']},
  {key:'decide',label:'Décider',icon:'✦',defaultView:'insights',views:['insights','inbox','ai','semantic','decision','actions','trust']},
  {key:'publish',label:'Publier',icon:'▧',defaultView:'dashboard',views:['dashboard','report']},
  {key:'collaborate',label:'Collaborer',icon:'◎',defaultView:'review',views:['review']},
  {key:'governance',label:'Gouverner',icon:'⌾',defaultView:'reliability',views:['reliability','sources','operations','identity','plugins','ai-settings','compliance','governance']},
];
const viewLabels: Record<View,string> = {
  home:'Vue d’ensemble',data:'Aperçu des données',quality:'Qualité',prepare:'Préparation',stats:'Statistiques descriptives',
  visual:'Visualisation',tests:'Tests & corrélations',sql:'SQL',notebook:'Notebook',regression:'Régression',anova:'ANOVA',pca:'ACP',cluster:'Clustering',
  model:'AutoML',registry:'Model Registry',serving:'Feature Store & Serving',forecast:'Forecasting',anomaly:'Anomalies',xai:'XAI',responsible:'Responsible AI',predict:'Prédictions',insights:'Insights',inbox:'Inbox analytique',ai:'AI Analyst',semantic:'Couche sémantique',decision:'Decision Lab',actions:'Actions & Automation',trust:'Trust Center',dashboard:'Dashboards',report:'Rapports',review:'Review Center',reliability:'Fiabilité & Lineage',sources:'Sources & Refresh',operations:'Observabilité & Eval',identity:'Identité & Secrets',plugins:'Plugins & MCP','ai-settings':'IA & Modèles',compliance:'CDC & Acceptance',governance:'Gouvernance'
};
const viewIcons: Partial<Record<View,string>>={home:'⌂',data:'▦',quality:'✓',prepare:'⌘',stats:'▤',visual:'▥',tests:'∑',sql:'⌗',notebook:'⌘',regression:'↗',anova:'≋',pca:'◔',cluster:'◫',model:'◆',registry:'▣',serving:'⇆',forecast:'⌁',anomaly:'⚠',xai:'◇',responsible:'⚖',predict:'◎',insights:'✧',inbox:'◉',ai:'✦',semantic:'◈',decision:'⇄',actions:'⚡',trust:'✓',dashboard:'▦',report:'▧',review:'◎',reliability:'◫',sources:'↻',operations:'◉',identity:'◈',plugins:'⌘','ai-settings':'✦',compliance:'✓',governance:'⌾'};


function b64urlToBytes(value:string):ArrayBuffer {
  const normalized=value.replace(/-/g,'+').replace(/_/g,'/');
  const padded=normalized+'='.repeat((4-normalized.length%4)%4);
  const raw=atob(padded); const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
  return bytes.buffer;
}
function bytesToB64url(value:ArrayBuffer):string {
  const bytes=new Uint8Array(value); let raw='';
  for(const b of bytes)raw+=String.fromCharCode(b);
  return btoa(raw).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function publicKeyOptionsFromJSON(input:AnyObj):PublicKeyCredentialCreationOptions|PublicKeyCredentialRequestOptions {
  const out:any={...input,challenge:b64urlToBytes(String(input.challenge))};
  if(input.user?.id)out.user={...input.user,id:b64urlToBytes(String(input.user.id))};
  if(Array.isArray(input.excludeCredentials))out.excludeCredentials=input.excludeCredentials.map((x:AnyObj)=>({...x,id:b64urlToBytes(String(x.id))}));
  if(Array.isArray(input.allowCredentials))out.allowCredentials=input.allowCredentials.map((x:AnyObj)=>({...x,id:b64urlToBytes(String(x.id))}));
  return out;
}
function publicKeyCredentialToJSON(credential:Credential):AnyObj {
  const c:any=credential as any; const response:any=c.response; const out:any={
    id:c.id, rawId:bytesToB64url(c.rawId), type:c.type,
    response:{clientDataJSON:bytesToB64url(response.clientDataJSON)},
  };
  if(response.attestationObject)out.response.attestationObject=bytesToB64url(response.attestationObject);
  if(response.authenticatorData)out.response.authenticatorData=bytesToB64url(response.authenticatorData);
  if(response.signature)out.response.signature=bytesToB64url(response.signature);
  if(response.userHandle)out.response.userHandle=bytesToB64url(response.userHandle);
  if(typeof response.getTransports==='function')out.response.transports=response.getTransports();
  if(typeof c.getClientExtensionResults==='function')out.clientExtensionResults=c.getClientExtensionResults();
  return out;
}
function areaForView(view:View){ return areaConfig.find(a=>a.views.includes(view)) ?? areaConfig[0]; }

function formatNumber(value: unknown, digits = 3) {
  if (typeof value !== 'number') return value == null ? '—' : String(value);
  if (!Number.isFinite(value)) return '—';
  if (Math.abs(value) > 0 && Math.abs(value) < 0.001) return value.toExponential(2);
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: digits }).format(value);
}
function pText(v: unknown) { return typeof v === 'number' ? (v < 0.001 ? '< 0,001' : formatNumber(v, 4)) : '—'; }
function isNumeric(c: AnyObj) { return /int|float|double|decimal/i.test(c.dtype); }
function isLikelyIdentifier(c: AnyObj, rows = 0) { const n=String(c?.name??'').toLowerCase(); const byName=/^(id|index|row|record|patient_id|customer_id|user_id)$/.test(n)||/_id$/.test(n); const unique=Number(c?.unique??0); const highUnique=rows>20&&unique/Math.max(rows,1)>.98; const idToken=/(uuid|identifier|identifiant|code|key|numero|number|record_no|record_number)/.test(n); return byName||(highUnique&&idToken); }
function Stat({ label, value, detail }: { label: string; value: ReactNode; detail?: ReactNode }) {
  return <div className="metric-card"><span>{label}</span><strong>{value}</strong>{detail && <small>{detail}</small>}</div>;
}
function Panel({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return <section className="panel"><header className="panel-head"><h3>{title}</h3>{action}</header><div className="panel-body">{children}</div></section>;
}
function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><div className="empty-icon">↥</div><h3>{title}</h3><p>{text}</p></div>;
}
function RunButton({ busy, label, busyLabel, onClick }: { busy: boolean; label: string; busyLabel: string; onClick: () => void }) {
  return <button className="primary-btn real-button" disabled={busy} onClick={onClick}>{busy ? busyLabel : `▶ ${label}`}</button>;
}

function CommandPalette({query,setQuery,items,onClose,onNavigate,onAsk,copy}:{query:string;setQuery:(s:string)=>void;items:{key:View;label:string;area:string;icon:string}[];onClose:()=>void;onNavigate:(v:View)=>void;onAsk:(q:string)=>void;copy:{placeholder:string;navigation:string;analysis:string;ask:string;close:string}}){
  const q=query.trim().toLowerCase();
  const filtered=items.filter(x=>!q||`${x.label} ${x.area}`.toLowerCase().includes(q)).slice(0,12);
  return <div className="command-overlay" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div className="command-palette" role="dialog" aria-modal="true" aria-label={copy.navigation}><div className="command-search"><span aria-hidden="true">⌕</span><input autoFocus value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&query.trim())onAsk(query.trim())}} placeholder={copy.placeholder} aria-label={copy.placeholder}/><kbd aria-label={copy.close}>Esc</kbd></div><div className="command-results"><small>{copy.navigation}</small>{filtered.map(x=><button key={x.key} onClick={()=>onNavigate(x.key)}><span aria-hidden="true">{x.icon}</span><div><b>{x.label}</b><small>{x.area}</small></div><i aria-hidden="true">↵</i></button>)}{q&&<><small>{copy.analysis}</small><button className="ask-command" onClick={()=>onAsk(query.trim())}><span aria-hidden="true">✦</span><div><b>{copy.ask}</b><small>{query}</small></div><i aria-hidden="true">↵</i></button></>}</div></div></div>;
}

export default function Home() {
  const [view, setView] = useState<View>('home');
  const [result, setResult] = useState<AnyObj | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [selectedColumn, setSelectedColumn] = useState('');
  const [columnAnalysis, setColumnAnalysis] = useState<AnyObj | null>(null);
  const [model, setModel] = useState<AnyObj | null>(null);
  const [target, setTarget] = useState('');
  const [algorithm, setAlgorithm] = useState('auto');
  const [training, setTraining] = useState(false);
  const [automlRunning, setAutomlRunning] = useState(false);
  const [predictionText, setPredictionText] = useState('[\n  {}\n]');
  const [prediction, setPrediction] = useState<AnyObj | null>(null);
  const [predicting, setPredicting] = useState(false);
  const [paletteOpen,setPaletteOpen]=useState(false);
  const [paletteQuery,setPaletteQuery]=useState('');
  const [trustSummary,setTrustSummary]=useState<AnyObj|null>(null);
  const [aiSeed,setAiSeed]=useState('');
  const [enterpriseBadge,setEnterpriseBadge]=useState<AnyObj|null>(null);
  const [authStatus,setAuthStatus]=useState<AnyObj|null>(null);
  const [authResolved,setAuthResolved]=useState(false);
  const [uiMode,setUiMode]=useState<AccessibilityMode>('comfortable');
  const [uiZoom,setUiZoom]=useState(105);
  const [locale,setLocale]=useState<Locale>('fr');
  const [highContrast,setHighContrast]=useState(false);
  const [reduceMotion,setReduceMotion]=useState(false);
  const [displayToolsOpen,setDisplayToolsOpen]=useState(false);
  const displayToolsRef=useRef<HTMLDivElement|null>(null);
  const mainContentRef=useRef<HTMLElement|null>(null);
  const preferencesHydratedRef=useRef(false);
  const preferencesSaveTimerRef=useRef<ReturnType<typeof setTimeout>|null>(null);
  const previousSecurityScope=useRef('local');

  async function activateDataset(id: string, nextView?: View) {
    setBusy(true); setError(''); setModel(null); setPrediction(null); setColumnAnalysis(null);
    try {
      const [dataset, profile, quality, decision, preview, versions, access] = await Promise.all([
        getDataset(id), getProfile(id), getQuality(id), getDecision(id), getPreview(id, 25), getVersions(id), getDatasetAccessContext(id),
      ]);
      const complete = { dataset, profile, quality, decision, preview, versions, access };
      setResult(complete);
      const firstNumeric = profile.columns.find((c: AnyObj) => isNumeric(c) && !isLikelyIdentifier(c, profile.rows))?.name ?? profile.columns.find((c:AnyObj)=>isNumeric(c))?.name ?? profile.columns[0]?.name ?? '';
      setSelectedColumn(firstNumeric);
      setTarget([...profile.columns].reverse().find((c:AnyObj)=>!isLikelyIdentifier(c, profile.rows))?.name ?? profile.columns[profile.columns.length - 1]?.name ?? '');
      if (nextView) setView(nextView);
      return complete;
    } catch (e: unknown) { setError(e instanceof Error ? e.message : String(e)); return null; }
    finally { setBusy(false); }
  }

  async function onFile(file?: File) {
    if (!file) return;
    setBusy(true); setError('');
    try {
      const uploaded = await uploadDataset(file);
      await activateDataset(uploaded.dataset.id, 'data');
    } catch (e: unknown) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  }

  function acceptTransformed(next: AnyObj) {
    const complete = { dataset: next.dataset, profile: next.profile, quality: next.quality, decision: next.decision, preview: next.preview, versions: next.versions, access: next.access };
    setResult(complete);
    setModel(null); setPrediction(null); setColumnAnalysis(null);
    const firstNumeric = next.profile.columns.find((c: AnyObj) => isNumeric(c) && !isLikelyIdentifier(c, next.profile.rows))?.name ?? next.profile.columns.find((c:AnyObj)=>isNumeric(c))?.name ?? next.profile.columns[0]?.name ?? '';
    setSelectedColumn(firstNumeric);
    setTarget([...next.profile.columns].reverse().find((c:AnyObj)=>!isLikelyIdentifier(c, next.profile.rows))?.name ?? next.profile.columns[next.profile.columns.length - 1]?.name ?? '');
  }

  useEffect(()=>{ const handler=(e:KeyboardEvent)=>{ const modifier=e.ctrlKey||e.metaKey; if(modifier&&e.key.toLowerCase()==='k'){e.preventDefault();setPaletteOpen(v=>!v);return;} if(modifier&&(e.key==='+'||e.key==='=')){e.preventDefault();setUiZoom(v=>Math.min(140,v+5));return;} if(modifier&&e.key==='-'){e.preventDefault();setUiZoom(v=>Math.max(90,v-5));return;} if(modifier&&e.key==='0'){e.preventDefault();setUiZoom(100);return;} if(e.key==='Escape'){setPaletteOpen(false);setDisplayToolsOpen(false);} }; window.addEventListener('keydown',handler); return()=>window.removeEventListener('keydown',handler); },[]);
  useEffect(()=>{ if(!displayToolsOpen)return; const handlePointer=(e:PointerEvent)=>{if(displayToolsRef.current&&!displayToolsRef.current.contains(e.target as Node))setDisplayToolsOpen(false);}; window.addEventListener('pointerdown',handlePointer); return()=>window.removeEventListener('pointerdown',handlePointer); },[displayToolsOpen]);
  useEffect(()=>{ mainContentRef.current?.focus({preventScroll:true}); },[view]);
  useEffect(()=>{
    const handleAssistantNavigate=(event:Event)=>{
      const detail=(event as CustomEvent<{view?:string;datasetId?:string;modelId?:string;refreshDataset?:boolean}>).detail;
      if(!detail?.view || !(detail.view in viewLabels)) return;
      void (async()=>{
        const nextView=detail.view as View;
        if(detail.datasetId && (detail.datasetId!==result?.dataset?.id || detail.refreshDataset)){
          const loaded=await activateDataset(detail.datasetId,nextView);
          if(!loaded) return;
        } else {
          setView(nextView);
        }
        if(detail.modelId){
          setModel(prev=>prev?.model_id===detail.modelId?prev:{...(prev??{}),model_id:detail.modelId});
        }
      })();
    };
    window.addEventListener('datavision:assistant-navigate',handleAssistantNavigate as EventListener);
    return()=>window.removeEventListener('datavision:assistant-navigate',handleAssistantNavigate as EventListener);
  },[result?.dataset?.id]);

useEffect(()=>{
  if(typeof window==='undefined') return;
  const storedMode = localStorage.getItem('dv_accessibility_mode');
  const storedZoom = Number(localStorage.getItem('dv_ui_zoom') || '105');
  const storedLocale = localStorage.getItem('dv_locale');
  if(storedMode==='normal' || storedMode==='comfortable' || storedMode==='large') setUiMode(storedMode);
  if(Number.isFinite(storedZoom) && storedZoom>=90 && storedZoom<=140) setUiZoom(storedZoom);
  setLocale(isLocale(storedLocale)?storedLocale:browserLocale());
  setHighContrast(localStorage.getItem('dv_high_contrast')==='true');
  setReduceMotion(localStorage.getItem('dv_reduce_motion')==='true' || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches===true);
  preferencesHydratedRef.current = true;
},[]);
useEffect(()=>{
  if(typeof window==='undefined') return;
  const root = document.documentElement;
  const zoom = uiZoom/100;
  root.dataset.dvMode = uiMode;
  root.dataset.dvContrast = highContrast?'high':'default';
  root.dataset.dvMotion = reduceMotion?'reduced':'full';
  root.lang=locale;
  root.dir=localeDirection(locale);
  root.style.setProperty('--dv-user-zoom', String(zoom));
  document.body.style.setProperty('zoom', String(zoom));
  localStorage.setItem('dv_accessibility_mode', uiMode);
  localStorage.setItem('dv_ui_zoom', String(uiZoom));
  localStorage.setItem('dv_locale', locale);
  localStorage.setItem('dv_high_contrast', String(highContrast));
  localStorage.setItem('dv_reduce_motion', String(reduceMotion));
},[uiMode,uiZoom,locale,highContrast,reduceMotion]);
useEffect(()=>{
  if(typeof window==='undefined' || !enterpriseBadge || !preferencesHydratedRef.current) return;
  const token=sessionStorage.getItem('dv_enterprise_token')||'';
  if(!token) return;
  if(preferencesSaveTimerRef.current) clearTimeout(preferencesSaveTimerRef.current);
  preferencesSaveTimerRef.current=setTimeout(()=>{
    saveEnterprisePreferences(token,{accessibility_mode:uiMode,ui_zoom:uiZoom,locale,high_contrast:highContrast,reduce_motion:reduceMotion}).catch(()=>{});
  },500);
  return()=>{if(preferencesSaveTimerRef.current) clearTimeout(preferencesSaveTimerRef.current);};
},[uiMode,uiZoom,locale,highContrast,reduceMotion,enterpriseBadge?.user?.id]);
  useEffect(()=>{ const refresh=async()=>{ if(typeof window==='undefined')return; try{const status=await getEnterpriseAuthStatus();setAuthStatus(status);const t=sessionStorage.getItem('dv_enterprise_token')||''; if(!t){setEnterpriseBadge(null);setAuthResolved(true);return;} const [session,prefs]=await Promise.all([getEnterpriseSession(t),getEnterprisePreferences(t).catch(()=>({preferences:{}}))]); const preferred=localStorage.getItem('dv_enterprise_workspace')||session.workspaces?.[0]?.id||''; const ws=session.workspaces?.find((x:AnyObj)=>x.id===preferred)??session.workspaces?.[0]??null; if(ws?.id)localStorage.setItem('dv_enterprise_workspace',ws.id); const mode=prefs?.preferences?.accessibility_mode; const zoom=Number(prefs?.preferences?.ui_zoom); const preferredLocale=prefs?.preferences?.locale; if(mode==='normal'||mode==='comfortable'||mode==='large')setUiMode(mode); if(Number.isFinite(zoom)&&zoom>=90&&zoom<=140)setUiZoom(zoom); if(isLocale(preferredLocale))setLocale(preferredLocale); if(typeof prefs?.preferences?.high_contrast==='boolean')setHighContrast(prefs.preferences.high_contrast); if(typeof prefs?.preferences?.reduce_motion==='boolean')setReduceMotion(prefs.preferences.reduce_motion); preferencesHydratedRef.current=true; setEnterpriseBadge({user:session.user,workspace:ws});}catch{setEnterpriseBadge(null);}finally{setAuthResolved(true);} }; void refresh(); window.addEventListener('datavision-enterprise-session',refresh); return()=>window.removeEventListener('datavision-enterprise-session',refresh); },[]);
  useEffect(()=>{ if(typeof window==='undefined')return; const url=new URL(window.location.href); const code=url.searchParams.get('code'); const state=url.searchParams.get('state'); const provider=sessionStorage.getItem('dv_oidc_provider')||''; if(!code||!state||!provider)return; const redirectUri=window.location.origin; exchangeEnterpriseOIDC({provider_id:provider,code,state,redirect_uri:redirectUri}).then(body=>{sessionStorage.setItem('dv_enterprise_token',body.access_token);if(body.refresh_token)sessionStorage.setItem('dv_enterprise_refresh',body.refresh_token);if(body.workspace_id)localStorage.setItem('dv_enterprise_workspace',body.workspace_id);sessionStorage.removeItem('dv_oidc_provider');window.history.replaceState({},document.title,window.location.pathname);window.dispatchEvent(new Event('datavision-enterprise-session'));setView('identity');}).catch((e:unknown)=>{sessionStorage.removeItem('dv_oidc_provider');setError(e instanceof Error?e.message:String(e));window.history.replaceState({},document.title,window.location.pathname);}); },[]);
  useEffect(()=>{ const scope=enterpriseBadge?.workspace?.id?`workspace:${enterpriseBadge.workspace.id}`:'local'; if(previousSecurityScope.current!==scope){ setResult(null); setModel(null); setPrediction(null); setColumnAnalysis(null); setTrustSummary(null); previousSecurityScope.current=scope; } },[enterpriseBadge?.workspace?.id]);
  useEffect(()=>{ if(!result){setTrustSummary(null);return;} let cancelled=false; getTrustCenter(result.dataset.id).then(x=>{if(!cancelled)setTrustSummary(x)}).catch(()=>{if(!cancelled)setTrustSummary(null)}); return()=>{cancelled=true}; },[result?.dataset?.id]);

  useEffect(() => {
    if (!result || !selectedColumn || view !== 'stats') return;
    let cancelled = false;
    setColumnAnalysis(null);
    getColumnAnalysis(result.dataset.id, selectedColumn)
      .then(data => { if (!cancelled) setColumnAnalysis(data); })
      .catch(e => { if (!cancelled) setError(e instanceof Error ? e.message : String(e)); });
    return () => { cancelled = true; };
  }, [result, selectedColumn, view]);


  useEffect(() => {
    const selectedColumnProfile = result?.profile?.columns?.find(
      (column: AnyObj) => column.name === selectedColumn,
    );
    const activeArea = areaForView(view);
    const operationState = {
      busy,
      training,
      automlRunning,
      predicting,
    };

    assistantEventBus.setContext({
      workspaceId: enterpriseBadge?.workspace?.id || undefined,
      organizationId: enterpriseBadge?.workspace?.organization_id || undefined,
      route: `/${view}`,
      screen: view,
      activeDatasetId: result?.dataset?.id || undefined,
      activeDatasetVersionId:
        result?.dataset?.version != null
          ? String(result.dataset.version)
          : undefined,
      activeModelId: model?.model_id || undefined,
      selectedEntity: selectedColumn
        ? {
            type: "column",
            id: selectedColumn,
            label: selectedColumn,
            metadata: {
              dtype: selectedColumnProfile?.dtype,
              missing: selectedColumnProfile?.missing,
              unique: selectedColumnProfile?.unique,
            },
          }
        : null,
      uiState: {
        areaKey: activeArea.key,
        areaLabel: activeArea.label,
        workspaceName: enterpriseBadge?.workspace?.name ?? (enterpriseBadge ? "Entreprise" : "Analyse locale"),
        workspaceRole: enterpriseBadge?.workspace?.role ?? (enterpriseBadge ? "member" : "local"),
        userDisplayName: enterpriseBadge?.user?.display_name ?? enterpriseBadge?.user?.email ?? "Utilisateur local",
        target,
        algorithm,
        busy,
        training,
        automlRunning,
        predicting,
        operationState,
        datasetId: result?.dataset?.id,
        datasetName: result?.dataset?.name,
        datasetVersion: result?.dataset?.version,
        datasetCreatedAt: result?.dataset?.created_at,
        rowCount: result?.profile?.rows,
        columnCount: result?.profile?.columns_count,
        duplicateCount: result?.profile?.duplicates,
        missingCells:
          result?.profile?.columns?.reduce(
            (total: number, column: AnyObj) =>
              total + Number(column.missing ?? 0),
            0,
          ) ?? 0,
        qualityScore: result?.quality?.score,
        qualityIssuesCount: result?.quality?.issues_count,
        numericColumnCount:
          result?.profile?.columns?.filter((column: AnyObj) =>
            isNumeric(column),
          ).length ?? 0,
        categoricalColumnCount:
          result?.profile?.columns?.filter((column: AnyObj) =>
            !isNumeric(column),
          ).length ?? 0,
        datasetSchema:
          result?.profile?.columns?.map((column: AnyObj) => ({
            name: column.name,
            dtype: column.dtype,
          })) ?? [],
        temporalCoverage: result?.profile?.temporal ?? { detected: false, primary: null, columns: [] },
        accessMode: result?.access?.mode ?? (enterpriseBadge ? "enterprise" : "local"),
        accessGoverned: Boolean(result?.access?.governed),
        accessRole: result?.access?.role ?? enterpriseBadge?.workspace?.role,
        accessPolicyCount: result?.access?.policy_count ?? 0,
        accessPolicyIds: result?.access?.policy_ids ?? [],
        modelTask: model?.task,
        modelAlgorithm: model?.algorithm,
        modelPrimaryMetric: model?.primary_metric,
        modelExperimentId: model?.experiment_id,
        modelFeatureCount: Array.isArray(model?.features) ? model.features.length : undefined,
        trustScore: trustSummary?.overall_score,
        trustGrade: trustSummary?.grade,
        accessibilityMode: uiMode,
        uiZoom,
        locale,
        highContrast,
        reduceMotion,
      },
    });
  }, [
    view,
    result?.dataset?.id,
    result?.dataset?.version,
    model?.model_id,
    selectedColumn,
    target,
    algorithm,
    busy,
    training,
    automlRunning,
    predicting,
    result?.dataset?.name,
    result?.dataset?.created_at,
    result?.profile?.rows,
    result?.profile?.columns_count,
    result?.profile?.duplicates,
    result?.profile?.temporal,
    result?.quality?.score,
    result?.quality?.issues_count,
    enterpriseBadge?.workspace?.id,
    enterpriseBadge?.workspace?.organization_id,
    enterpriseBadge?.workspace?.name,
    enterpriseBadge?.workspace?.role,
    enterpriseBadge?.user?.display_name,
    enterpriseBadge?.user?.email,
    result?.access?.mode,
    result?.access?.governed,
    result?.access?.role,
    result?.access?.policy_count,
    model?.task,
    model?.algorithm,
    model?.primary_metric,
    model?.experiment_id,
    model?.features?.length,
    trustSummary?.overall_score,
    trustSummary?.grade,
    uiMode,
    uiZoom,
    locale,
    highContrast,
    reduceMotion,
  ]);

  useEffect(() => {
    if (!result?.dataset?.id) return;
    assistantEventBus.emit({
      type: "dataset.loaded",
      payload: {
        datasetId: result.dataset.id,
        version: result.dataset.version ?? 1,
        rows: result.profile?.rows,
        columns: result.profile?.columns_count,
      },
    });
  }, [result?.dataset?.id, result?.dataset?.version]);

  useEffect(() => {
    if (!model?.model_id) return;
    assistantEventBus.emit({
      type: "ml.training.completed",
      payload: {
        modelId: model.model_id,
        task: model.task,
        algorithm: model.algorithm,
      },
    });
  }, [model?.model_id]);

  useEffect(() => {
    if (!error) return;
    assistantEventBus.emit({
      type: "analysis.failed",
      severity: "warning",
      payload: {
        screen: view,
        message: error.slice(0, 1000),
      },
    });
  }, [error, view]);

  async function doTrain() {
    if (!result || !target) return;
    setTraining(true); setError('');
    try {
      const trained = await trainModel(result.dataset.id, { target, task: 'auto', algorithm });
      setModel(trained);
      const features = result.profile.columns.filter((c: AnyObj) => c.name !== target).slice(0, 4).reduce((acc: AnyObj, c: AnyObj) => { acc[c.name] = null; return acc; }, {});
      setPredictionText(JSON.stringify([features], null, 2)); setView('predict');
    } catch (e: unknown) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setTraining(false); }
  }
  async function doAutoML(config: { task: 'auto'|'classification'|'regression'|'clustering'|'forecasting'|'anomaly_detection'; features?: string[]; primary_metric: string; cv_folds: number; tune: boolean; max_candidates: number; split_strategy?: 'auto'|'random'|'temporal'; time_column?: string|null; horizon?:number; backtest_windows?:number; contamination?:number; threshold?:number }) {
    if (!result || ((config.task==='classification'||config.task==='regression'||config.task==='forecasting'||config.task==='auto') && !target)) return;
    setAutomlRunning(true); setError('');
    try {
      const trained = await runAutoML(result.dataset.id, { target: (config.task === 'clustering'||config.task==='anomaly_detection') ? null : target, ...config });
      setModel(trained);
      if (!['clustering','forecasting','anomaly_detection'].includes(config.task)) {
        const features = result.profile.columns.filter((c: AnyObj) => c.name !== target).slice(0, 6).reduce((acc: AnyObj, c: AnyObj) => { acc[c.name] = null; return acc; }, {});
        setPredictionText(JSON.stringify([features], null, 2));
      }
    } catch (e: unknown) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setAutomlRunning(false); }
  }

  async function doPredict() {
    if (!model) return;
    setPredicting(true); setError('');
    try {
      const rows = JSON.parse(predictionText);
      if (!Array.isArray(rows)) throw new Error('Le JSON doit être un tableau d’objets.');
      setPrediction(await predictModel(model.model_id, rows));
    } catch (e: unknown) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setPredicting(false); }
  }


const tr=(key:string,fallback?:string,params?:Record<string,string|number>)=>translate(locale,key,fallback,params);
const localizedViewLabel=(value:View)=>tr(`view.${value}`,viewLabels[value]);
const localizedAreaLabel=(value:AreaKey,fallback:string)=>tr(`area.${value}`,fallback);
const activeArea=areaForView(view);
const paletteItems=Object.entries(viewLabels).map(([key])=>({key:key as View,label:localizedViewLabel(key as View),area:localizedAreaLabel(areaForView(key as View).key,areaForView(key as View).label),icon:viewIcons[key as View]??'•'}));
const setZoomWithinBounds = (next:number) => setUiZoom(Math.max(90, Math.min(140, next)));
const setReadingMode = (mode:AccessibilityMode) => {
  const preset = mode==='normal' ? 100 : mode==='comfortable' ? 110 : 125;
  setUiMode(mode);
  setUiZoom(preset);
};
if(!authResolved) return <div className="auth-loading" role="status">Vérification de la session DataVision…</div>;
if(!enterpriseBadge && !authStatus?.local_dev_enabled) return <AuthenticationGate status={authStatus} onAuthenticated={()=>window.dispatchEvent(new Event('datavision-enterprise-session'))}/>;
return <main className="app-shell professional-shell">
    <a className="skip-link" href="#main-content">{tr('a11y.skipToContent')}</a>
    <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">{tr('a11y.viewChanged',undefined,{view:localizedViewLabel(view)})}</div>
    <header className="topbar pro-topbar">
      <div className="brand-mini"><div className="brand-mark" aria-hidden="true">DV</div><div><b>DataVision AI</b><span>{tr('app.tagline')}</span></div></div>
      <div className="top-context">
        {result?<><span className="top-dataset" title={result.dataset.name}><b>{result.dataset.name}</b><small>v{result.dataset.version??1}</small></span>{result.access?.governed&&<button className="governed-chip" onClick={()=>setView('governance')} title={`${result.access.policy_count??0} politique(s) active(s)`}>◈ Accès gouverné · {result.access.role}</button>}<span className="top-quality">{tr('shell.quality')} <b>{result.quality.score}/100</b></span>{trustSummary&&<button className="trust-pill" onClick={()=>setView('trust')}>Trust {trustSummary.overall_score}/100 · {trustSummary.grade}</button>}</>:<span className="top-empty">{tr('shell.noDataset')}</span>}
      </div>
      <div className="top-actions"><span className="runtime-dot" aria-hidden="true"/>{enterpriseBadge?<button className="enterprise-pill" onClick={()=>setView('governance')}><b>{enterpriseBadge.workspace?.name??'Entreprise'}</b><small>{enterpriseBadge.user?.display_name??enterpriseBadge.user?.email}</small></button>:<span>{tr('shell.local')}</span>}<div className="display-tools" ref={displayToolsRef}><button className="display-trigger" aria-label={tr('display.open')} aria-expanded={displayToolsOpen} aria-controls="display-accessibility-popover" onClick={()=>setDisplayToolsOpen(v=>!v)}><span aria-hidden="true">Aa</span><b>{uiZoom}%</b></button>{displayToolsOpen&&<div id="display-accessibility-popover" className="display-popover" role="dialog" aria-label={tr('display.title')}><div className="display-popover-head"><div><b>{tr('display.title')}</b><small>{tr('display.subtitle')}</small></div><button className="display-close" aria-label={tr('display.close')} onClick={()=>setDisplayToolsOpen(false)}>×</button></div><label className="display-language"><span>{tr('display.language')}</span><select value={locale} onChange={e=>setLocale(e.target.value as Locale)}>{LOCALES.map(item=><option key={item.code} value={item.code}>{item.nativeLabel}</option>)}</select></label><div className="display-mode-group"><span>{tr('display.readingMode')}</span><div className="segmented-control"><button aria-pressed={uiMode==='normal'} className={uiMode==='normal'?'active':''} onClick={()=>setReadingMode('normal')}>{tr('display.normal')}</button><button aria-pressed={uiMode==='comfortable'} className={uiMode==='comfortable'?'active':''} onClick={()=>setReadingMode('comfortable')}>{tr('display.comfortable')}</button><button aria-pressed={uiMode==='large'} className={uiMode==='large'?'active':''} onClick={()=>setReadingMode('large')}>{tr('display.large')}</button></div></div><div className="display-zoom-row"><span>{tr('display.zoom')}</span><div><button aria-label="Zoom −5%" onClick={()=>setZoomWithinBounds(uiZoom-5)}>−</button><strong>{uiZoom}%</strong><button aria-label="Zoom +5%" onClick={()=>setZoomWithinBounds(uiZoom+5)}>+</button><button className="ghost" aria-label={tr('display.resetZoom')} onClick={()=>setZoomWithinBounds(100)}>100%</button></div></div><div className="accessibility-toggles"><label><input type="checkbox" checked={highContrast} onChange={e=>setHighContrast(e.target.checked)}/><span>{tr('display.highContrast')}</span></label><label><input type="checkbox" checked={reduceMotion} onChange={e=>setReduceMotion(e.target.checked)}/><span>{tr('display.reduceMotion')}</span></label></div><small className="display-footnote">{tr('display.footnote')}</small></div>}</div><button className="command-trigger command-trigger-wide" aria-keyshortcuts="Control+K Meta+K" onClick={()=>setPaletteOpen(true)}><span aria-hidden="true">⌕</span><span className="command-trigger-label">{tr('shell.search')}</span><kbd>Ctrl K</kbd></button><button className="settings-nav-button" aria-label={tr('shell.settings')} title={tr('shell.settings')} onClick={()=>setView('governance')}>⚙</button><button className="avatar" aria-label={enterpriseBadge?String(enterpriseBadge.user?.display_name??enterpriseBadge.user?.email??'Profil'):'DataVision'} onClick={()=>enterpriseBadge&&setView('governance')}>{enterpriseBadge?String(enterpriseBadge.user?.display_name??'DV').slice(0,2).toUpperCase():'DV'}</button></div>
    </header>
    <div className="app-grid pro-grid">
      <aside className="sidebar pro-sidebar">
        <div className="workspace-label"><span>{tr('shell.workspace')}</span><b>{enterpriseBadge?.workspace?.name??tr('shell.localAnalysis')}</b><small>{enterpriseBadge?`${enterpriseBadge.workspace?.role??'member'} · ${enterpriseBadge.user?.display_name??'utilisateur'}`:tr('shell.goalWorkflow')}</small></div>
        <nav className="area-nav" aria-label={tr('a11y.primaryNavigation')}>{areaConfig.map(area=>{const label=localizedAreaLabel(area.key,area.label);return <button key={area.key} className={activeArea.key===area.key?'area-item active':'area-item'} title={label} aria-label={label} aria-current={activeArea.key===area.key?'page':undefined} onClick={()=>setView(area.defaultView)}><span aria-hidden="true">{area.icon}</span><div><b>{label}</b><small>{tr(`area.${area.key}.description`)}</small></div></button>})}</nav>
        <label className="upload-side pro-upload">{busy?tr('shell.importing'):`↥  ${tr('shell.import')}`}<input type="file" accept=".csv,.xlsx,.json,.parquet,.txt,.zip" onChange={e=>onFile(e.target.files?.[0])}/></label>
        {result&&<div className="dataset-mini"><span>{tr('shell.activeContext')}</span><b title={result.dataset.name}>{result.dataset.name}</b><small>v{result.dataset.version??1} · {result.profile.rows} lignes · {result.profile.columns_count} variables</small>{result.access?.governed&&<small className="governed-mini">◈ {result.access.role} · {result.access.policy_count??0} politique(s) · tenant-aware</small>}<div className="dataset-mini-actions"><button onClick={()=>setView('semantic')}>{tr('shell.semantic')}</button><button onClick={()=>setView('trust')}>{tr('shell.trust')}</button></div></div>}
      </aside>
      <section id="main-content" ref={mainContentRef} tabIndex={-1} className="content pro-content" aria-label={tr('a11y.mainContent')}>
        {activeArea.views.length>1&&<div className="context-tabs"><div><span aria-hidden="true">{activeArea.icon}</span><b>{localizedAreaLabel(activeArea.key,activeArea.label)}</b></div><nav aria-label={tr('a11y.contextNavigation')}>{activeArea.views.map(v=><button key={v} className={view===v?'active':''} aria-current={view===v?'page':undefined} onClick={()=>setView(v)}>{localizedViewLabel(v)}</button>)}</nav></div>}
        {error&&<div className="alert" role="alert"><b>{tr('error.title')}</b><span>{error}</span><button aria-label={tr('command.close')} onClick={()=>setError('')}>×</button></div>}
        {view==='home'&&<HomeView result={result} busy={busy} onFile={onFile} setView={setView}/>} 
        {view==='data'&&<DataView result={result}/>} 
        {view==='stats'&&<StatsView result={result} selectedColumn={selectedColumn} setSelectedColumn={setSelectedColumn} analysis={columnAnalysis}/>} 
        {view==='tests'&&<StatisticalLab result={result} setError={setError}/>} 
        {view==='quality'&&<QualityView result={result} setError={setError} onTransformed={acceptTransformed}/>} 
        {view==='prepare'&&<PrepareView result={result} setError={setError} onTransformed={acceptTransformed} onActivate={id=>activateDataset(id,'prepare')}/>} 
        {view==='visual'&&<VisualizationStudio result={result} setError={setError}/>} 
        {view==='sql'&&<SqlWorkspace result={result} setError={setError}/>} 
        {view==='notebook'&&<NotebookStudio dataset={result?.dataset??null} setError={setError}/>} 
        {view==='regression'&&<RegressionView result={result} setError={setError}/>} 
        {view==='anova'&&<AnovaView result={result} setError={setError}/>} 
        {view==='pca'&&<PcaView result={result} setError={setError}/>} 
        {view==='cluster'&&<ClusterView result={result} setError={setError}/>} 
        {view==='model'&&<ModelView result={result} target={target} setTarget={setTarget} algorithm={algorithm} setAlgorithm={setAlgorithm} training={training} automlRunning={automlRunning} doTrain={doTrain} doAutoML={doAutoML} model={model} setError={setError}/>} 
        {view==='registry'&&<ModelRegistryView activeModel={model} activeDataset={result?.dataset??null} setError={setError}/>}
        {view==='forecast'&&<ForecastView result={result} setError={setError}/>} 
        {view==='anomaly'&&<AnomalyView result={result} setError={setError}/>} 
        {view==='xai'&&<XaiView result={result} model={model} setError={setError}/>} 
        {view==='responsible'&&<ResponsibleAIView result={result} model={model} setError={setError}/>} 
        {view==='predict'&&<PredictView model={model} text={predictionText} setText={setPredictionText} predicting={predicting} doPredict={doPredict} prediction={prediction}/>} 
        {view==='insights'&&<InsightEngineView result={result} setError={setError} setView={setView}/>} 
        {view==='inbox'&&<ProactiveInbox result={result} setError={setError} setView={setView}/>} 
        {view==='ai'&&<AIAnalystView result={result} setError={setError} initialQuestion={aiSeed}/>} 
        {view==='semantic'&&<SemanticStudio result={result} setError={setError}/>} 
        {view==='decision'&&<DecisionLab result={result} model={model} setError={setError} setView={setView}/>} 
        {view==='actions'&&<GovernedActionsCenter result={result} setError={setError} setView={setView}/>} 
        {view==='trust'&&<TrustCenterView result={result} setError={setError}/>} 
        {view==='dashboard'&&<DashboardBuilder result={result} setError={setError}/>} 
        {view==='report'&&<ReportView result={result} setError={setError}/>}
        {view==='review'&&<CollaborationCenter result={result} setError={setError} setView={setView}/>}
        {view==='reliability'&&<ReliabilityLineageCenter result={result} setError={setError} setView={setView}/>}
        {view==='sources'&&<SourcesRefreshCenter setError={setError} setView={setView} onActivate={id=>activateDataset(id,'data')}/>}
        {view==='operations'&&<OperationalIntelligenceCenter result={result} setError={setError} setView={setView}/>}
        {view==='identity'&&<IdentitySecurityCenter setError={setError} setView={setView}/>}
        {view==='plugins'&&<PluginCenter setError={setError} setView={setView}/>}
        {view==='ai-settings'&&<AIProviderControlCenter setError={setError}/>} 
        {view==='compliance'&&<ComplianceCenter setError={setError}/>}
        {view==='governance'&&<GovernanceCenter result={result} setError={setError}/>}  
      </section>
    </div>
    {paletteOpen&&<CommandPalette query={paletteQuery} setQuery={setPaletteQuery} items={paletteItems} copy={{placeholder:tr('command.placeholder'),navigation:tr('command.navigation'),analysis:tr('command.analysis'),ask:tr('command.ask'),close:tr('command.close')}} onClose={()=>setPaletteOpen(false)} onNavigate={(v)=>{setView(v);setPaletteOpen(false);setPaletteQuery('')}} onAsk={(q)=>{setAiSeed(q);setView('ai');setPaletteOpen(false);setPaletteQuery('')}}/>}
  </main>;
}

function HomeView({ result, busy, onFile, setView }: { result: AnyObj | null; busy: boolean; onFile: (file?: File) => void; setView: (v: View) => void }) {
  const [dashboard,setDashboard]=useState<AnyObj|null>(null);
  const [loading,setLoading]=useState(false);
  useEffect(()=>{let cancelled=false;if(!result){setDashboard(null);return;}setLoading(true);getDashboard(result.dataset.id).then(d=>{if(!cancelled)setDashboard(d);}).catch(()=>{if(!cancelled)setDashboard(null);}).finally(()=>{if(!cancelled)setLoading(false);});return()=>{cancelled=true;};},[result?.dataset?.id]);
  if(!result) return <div className="home-view">
    <section className="hero"><div className="hero-copy"><span className="eyebrow">DATA ANALYSIS · STATISTICS · MACHINE LEARNING</span><h1>DataVision</h1><h2>De la donnée brute à une décision vérifiable.</h2><p>Importez un dataset. DataVision profile, contrôle la qualité, recommande les analyses et exécute les calculs avec des moteurs déterministes.</p><div className="hero-actions"><label className="primary-btn">{busy ? 'Analyse en cours…' : 'Importer un dataset'}<input type="file" accept=".csv,.xlsx,.json,.parquet,.txt,.zip" onChange={e => onFile(e.target.files?.[0])}/></label></div></div><div className="hero-visual"><span className="bar b1"/><span className="bar b2"/><span className="bar b3"/><span className="bar b4"/><span className="line l1"/><span className="line l2"/><span className="data-orb">AI</span></div></section>
    <div className="feature-strip"><button onClick={() => setView('stats')}><span className="feature-icon red">▤</span><div><b>Analyse statistique</b><p>Descriptif, tests, régression et ANOVA.</p></div></button><button onClick={() => setView('visual')}><span className="feature-icon green">▥</span><div><b>Visual Analytics</b><p>Graphiques adaptés aux variables et aux objectifs.</p></div></button><button onClick={() => setView('model')}><span className="feature-icon orange">◆</span><div><b>Machine Learning</b><p>AutoML, validation, XAI et prédiction.</p></div></button></div>
    <div className="workflow"><span>CONNECTER</span><i>→</i><span>COMPRENDRE</span><i>→</i><span>PRÉPARER</span><i>→</i><span>ANALYSER</span><i>→</i><span>MODÉLISER</span><i>→</i><strong>DÉCIDER</strong></div>
  </div>;
  const d=dashboard;
  return <div className="page dashboard-home">
    <div className="page-title"><div><span className="eyebrow">ANALYTICAL OVERVIEW</span><h1>{result.dataset.name}</h1><p>Vue synthétique de la structure, de la qualité, des relations et des prochaines analyses utiles.</p></div><div className="dataset-badges"><span className="version-badge">Version {result.dataset.version??1}</span><button className="secondary-btn" onClick={()=>setView('data')}>Voir les données</button></div></div>
    <div className="metrics dashboard-kpis"><Stat label="Lignes" value={d?.metrics?.rows??result.profile.rows}/><Stat label="Variables" value={d?.metrics?.columns??result.profile.columns_count}/><Stat label="Score qualité" value={`${d?.metrics?.quality_score??result.quality.score}/100`}/><Stat label="Cellules manquantes" value={d?.metrics?.missing_cells??'—'}/><Stat label="Doublons" value={d?.metrics?.duplicates??result.profile.duplicates}/></div>
    <section className="goal-playbooks"><div className="goal-playbooks-head"><div><span className="eyebrow">START WITH A GOAL</span><h3>Que voulez-vous comprendre ?</h3></div><small>DataVision ouvre le bon workflow sans vous obliger à connaître le nom du test ou de l’algorithme.</small></div><div className="goal-playbook-grid"><button onClick={()=>setView('tests')}><span>01</span><div><b>Comparer des groupes</b><p>Choisir automatiquement le test, vérifier les hypothèses et mesurer la taille d’effet.</p></div><i>→</i></button><button onClick={()=>setView('regression')}><span>02</span><div><b>Expliquer une cible</b><p>Régression, diagnostics, variables influentes et limites d’interprétation.</p></div><i>→</i></button><button onClick={()=>setView('forecast')}><span>03</span><div><b>Prévoir une métrique</b><p>Validation temporelle, benchmark et intervalles de prévision.</p></div><i>→</i></button><button onClick={()=>setView('ai')}><span>04</span><div><b>Analyser sans choisir l’outil</b><p>L’AI Analyst planifie, exécute et vérifie une analyse multi-étapes.</p></div><i>→</i></button></div></section>
    {loading&&!d&&<div className="quiet-empty">Calcul de la synthèse analytique…</div>}
    {d&&<>
      <div className="dashboard-grid dashboard-overview-grid">
        <Panel title="Valeurs manquantes">{d.missing?.length?<BarChart rows={d.missing} valueKey="missing_pct" labelKey="name" suffix="%"/>:<div className="success-box">✓ Aucune valeur manquante détectée.</div>}</Panel>
        <Panel title="Types de variables"><BarChart rows={d.types??[]} valueKey="count" labelKey="type"/></Panel>
        <Panel title="Relations les plus fortes">{d.strong_correlations?.length?<BarChart rows={d.strong_correlations.slice(0,8).map((r:AnyObj)=>({...r,label:`${r.x} × ${r.y}`}))} valueKey="abs" labelKey="label"/>:<div className="quiet-empty">Pas assez de variables numériques pertinentes.</div>}</Panel>
      </div>
      <div className="two-col dashboard-insight-row">
        <Panel title="Insights clés"><div className="insight-feed">{(d.insights??[]).map((x:AnyObj,i:number)=><article key={i} className={`insight-item ${x.severity}`}><span>{x.severity}</span><div><b>{x.title}</b><p>{x.statement}</p><small>{x.action}</small></div></article>)}</div></Panel>
        <Panel title="Prochaines analyses"><div className="smart-actions">{(d.recommended_visualizations??[]).slice(0,5).map((r:AnyObj,i:number)=><button key={i} onClick={()=>setView('visual')}><span className="smart-action-icon">▥</span><div><b>{String(r.type).toUpperCase()}</b><p>{r.reason}</p><small>{[r.x,r.y].filter(Boolean).join(' × ')}</small></div></button>)}<button onClick={()=>setView('ai')}><span className="smart-action-icon">✦</span><div><b>AI ANALYST</b><p>Construire et exécuter un plan d’analyse complet.</p><small>Provenance + Critic</small></div></button></div></Panel>
      </div>
      <div className="quick-module-grid"><button onClick={()=>setView('inbox')}><b>Inbox analytique</b><span>Signaux & changements</span></button><button onClick={()=>setView('quality')}><b>Qualité</b><span>{result.quality.issues_count} alerte(s)</span></button><button onClick={()=>setView('tests')}><b>Tests & corrélations</b><span>Relations et significativité</span></button><button onClick={()=>setView('visual')}><b>Visualisation</b><span>Explorer graphiquement</span></button><button onClick={()=>setView('model')}><b>AutoML</b><span>Benchmark prédictif</span></button><button onClick={()=>setView('dashboard')}><b>Dashboards</b><span>Construire une vue décisionnelle</span></button><button onClick={()=>setView('report')}><b>Rapports</b><span>Exporter les résultats</span></button></div>
    </>}
  </div>;
}
function DataView({ result }: { result: AnyObj | null }) {
  if (!result) return <EmptyState title="Données" text="Importez un fichier CSV, XLSX, JSON, Parquet ou TXT pour commencer."/>;
  const columns=result.profile.columns??[];
  const missing=columns.filter((c:AnyObj)=>Number(c.missing_pct)>0).sort((a:AnyObj,b:AnyObj)=>Number(b.missing_pct)-Number(a.missing_pct)).slice(0,12);
  const cardinality=[...columns].sort((a:AnyObj,b:AnyObj)=>Number(b.unique)-Number(a.unique)).slice(0,12);
  const typeMap:Record<string,number>={};
  for(const c of columns){const raw=String(c.dtype).toLowerCase();const type=/int|float|double|decimal/.test(raw)?'Numérique':/date|time/.test(raw)?'Date/heure':/bool/.test(raw)?'Booléen':/category/.test(raw)?'Catégorie':'Texte / autre';typeMap[type]=(typeMap[type]??0)+1;}
  const typeRows=Object.entries(typeMap).map(([type,count])=>({type,count}));
  return <div className="page"><div className="page-title"><div><span className="eyebrow">DATASET</span><h1>{result.dataset.name}</h1><p>Aperçu, structure, complétude et cardinalité du jeu de données.</p></div><div className="dataset-badges"><span className="version-badge">Version {result.dataset.version ?? 1}</span><span className="format-badge">{result.dataset.format.replace('.','').toUpperCase()}</span></div></div>
    <div className="metrics"><Stat label="Lignes" value={result.profile.rows}/><Stat label="Variables" value={result.profile.columns_count}/><Stat label="Doublons" value={result.profile.duplicates}/><Stat label="Mémoire" value={`${formatNumber(result.profile.memory_bytes/1024)} Ko`}/></div>
    <div className="dashboard-grid"><Panel title="Valeurs manquantes — top 12">{missing.length?<BarChart rows={missing} valueKey="missing_pct" labelKey="name" suffix="%"/>:<div className="success-box">✓ Aucune valeur manquante détectée.</div>}</Panel><Panel title="Types de variables"><BarChart rows={typeRows} valueKey="count" labelKey="type"/></Panel><Panel title="Cardinalité — top 12"><BarChart rows={cardinality} valueKey="unique" labelKey="name"/></Panel></div>
    <Panel title="Aperçu des données" action={<span className="quiet">{result.preview.shown}/{result.preview.total}</span>}><DataTable preview={result.preview}/></Panel>
    <Panel title="Variables"><div className="columns-grid">{columns.map((c: AnyObj) => {const idLike=isLikelyIdentifier(c,Number(result.profile.rows??0));return <div className={idLike?'column-card identifier':'column-card'} key={c.name}><b>{c.name}</b><span>{c.dtype}</span><small>{c.unique} valeurs uniques · {formatNumber(c.missing_pct)} % manquantes</small>{idLike&&<span className="column-role">identifiant probable · exclu des sélections automatiques</span>}</div>})}</div></Panel>
  </div>;
}
function DataTable({ preview }: { preview: AnyObj }) {
  return <div className="table-scroll"><table><thead><tr>{preview.columns.map((c:string)=><th key={c}>{c}</th>)}</tr></thead><tbody>{preview.rows.map((r:AnyObj,i:number)=><tr key={i}>{preview.columns.map((c:string)=><td key={c}>{r[c] == null ? <span className="null">NA</span> : String(r[c])}</td>)}</tr>)}</tbody></table></div>;
}

function StatsView({ result, selectedColumn, setSelectedColumn, analysis }: { result: AnyObj | null; selectedColumn: string; setSelectedColumn: (v: string) => void; analysis: AnyObj | null }) {
  if (!result) return <EmptyState title="Statistiques descriptives" text="Chargez un dataset afin d’analyser chaque variable."/>;
  return <div className="page"><div className="page-title"><div><span className="eyebrow">STATISTIQUES DESCRIPTIVES</span><h1>Statistiques Descriptives</h1><p>Sélectionnez une variable pour afficher ses indicateurs et sa représentation graphique.</p></div></div><Panel title="Choix de la variable"><div className="form-row"><label>Choisissez une variable<select value={selectedColumn} onChange={e=>setSelectedColumn(e.target.value)}>{result.profile.columns.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result.profile.rows??0))).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><span className="field-hint">Les résultats sont recalculés par le backend.</span></div></Panel>{!analysis ? <div className="loading-card">Calcul des statistiques…</div> : analysis.kind === 'numeric' ? <NumericAnalysis analysis={analysis}/> : <CategoricalAnalysis analysis={analysis}/>}</div>;
}
function NumericAnalysis({ analysis }: { analysis: AnyObj }) { const s=analysis.summary; return <><div className="metrics six"><Stat label="Moyenne" value={formatNumber(s.mean)}/><Stat label="Médiane" value={formatNumber(s.median)}/><Stat label="Écart-type" value={formatNumber(s.std)}/><Stat label="Variance" value={formatNumber(s.variance)}/><Stat label="Minimum" value={formatNumber(s.min)}/><Stat label="Maximum" value={formatNumber(s.max)}/></div><div className="two-col"><Panel title="Histogramme"><Histogram bins={analysis.histogram}/></Panel><Panel title="Quartiles et extrêmes"><div className="summary-list"><span>Premier quartile (Q1)<b>{formatNumber(s.q1)}</b></span><span>Médiane<b>{formatNumber(s.median)}</b></span><span>Troisième quartile (Q3)<b>{formatNumber(s.q3)}</b></span><span>Valeurs aberrantes IQR<b>{s.outliers_iqr}</b></span></div></Panel></div><Panel title="Box Plot"><BoxPlot data={analysis.boxplot}/></Panel></>; }
function Histogram({ bins }: { bins: AnyObj[] }) { const max=Math.max(1,...bins.map(b=>b.count)); return <div className="histogram"><div className="hist-bars">{bins.map((b,i)=><div key={i} className="hist-slot" title={`${b.from} – ${b.to}: ${b.count}`}><span style={{height:`${Math.max(3,b.count/max*100)}%`}}/></div>)}</div><div className="axis-row"><span>{formatNumber(bins[0]?.from)}</span><span>{formatNumber(bins[Math.floor(bins.length/2)]?.from)}</span><span>{formatNumber(bins[bins.length-1]?.to)}</span></div></div>; }
function BoxPlot({ data }: { data: AnyObj }) { const min=Number(data.min),max=Number(data.max),span=Math.max(1e-9,max-min); const pct=(v:number)=>5+((v-min)/span)*90; return <div className="boxplot"><div className="box-axis"><span style={{left:`${pct(data.whisker_low)}%`}} className="whisker left"/><span style={{left:`${pct(data.whisker_high)}%`}} className="whisker right"/><span className="whisker-line" style={{left:`${pct(data.whisker_low)}%`,width:`${pct(data.whisker_high)-pct(data.whisker_low)}%`}}/><span className="box" style={{left:`${pct(data.q1)}%`,width:`${pct(data.q3)-pct(data.q1)}%`}}/><span className="median" style={{left:`${pct(data.median)}%`}}/></div><div className="box-labels"><span>{formatNumber(min)}</span><span>Q1 {formatNumber(data.q1)}</span><span>Médiane {formatNumber(data.median)}</span><span>Q3 {formatNumber(data.q3)}</span><span>{formatNumber(max)}</span></div></div>; }
function CategoricalAnalysis({ analysis }: { analysis: AnyObj }) { const max=Math.max(1,...analysis.categories.map((x:AnyObj)=>x.count)); return <Panel title="Répartition des catégories"><div className="category-chart">{analysis.categories.map((x:AnyObj)=><div className="cat-row" key={x.value}><span>{x.value}</span><div><i style={{width:`${x.count/max*100}%`}}/></div><b>{x.count} <small>({x.pct}%)</small></b></div>)}</div></Panel>; }

function QualityView({ result, setError, onTransformed }: { result: AnyObj | null; setError:(s:string)=>void; onTransformed:(r:AnyObj)=>void }) {
  const [remediation,setRemediation]=useState<AnyObj|null>(null);
  const [selectedActions,setSelectedActions]=useState<string[]>([]);
  const [remediationPreview,setRemediationPreview]=useState<AnyObj|null>(null);
  const [remediationBusy,setRemediationBusy]=useState(false);
  const datasetId=String(result?.dataset?.id??'');
  const datasetVersion=Number(result?.dataset?.version??0);

  useEffect(()=>{
    let cancelled=false;
    setRemediation(null); setSelectedActions([]); setRemediationPreview(null);
    if(!datasetId)return()=>{cancelled=true;};
    void getQualityRemediation(datasetId).then(plan=>{
      if(cancelled)return;
      setRemediation(plan);
      setSelectedActions(Array.isArray(plan.default_action_ids)?plan.default_action_ids:[]);
      setRemediationPreview(plan.default_preview??null);
    }).catch(e=>{if(!cancelled)setError(e instanceof Error?e.message:String(e));});
    return()=>{cancelled=true;};
  },[datasetId,datasetVersion,setError]);

  async function refreshRemediationPreview(nextIds:string[]){
    if(!datasetId)return;
    try{setRemediationBusy(true);setRemediationPreview(await previewQualityRemediation(datasetId,nextIds));}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setRemediationBusy(false);}
  }
  function toggleRemediationAction(id:string){
    const next=selectedActions.includes(id)?selectedActions.filter(x=>x!==id):[...selectedActions,id];
    setSelectedActions(next); void refreshRemediationPreview(next);
  }
  async function applyRemediation(){
    if(!datasetId||!remediation)return;
    if(!selectedActions.length){setError('Sélectionnez au moins une action de remédiation.');return;}
    try{
      setRemediationBusy(true); setError('');
      const next=await applyQualityRemediation(datasetId,selectedActions,remediation.plan_id);
      onTransformed(next);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setRemediationBusy(false);}
  }

  if (!result) return <EmptyState title="Qualité des données" text="Chargez un dataset pour lancer automatiquement les contrôles de qualité."/>;
  const missing=(result.profile.columns??[]).filter((c:AnyObj)=>Number(c.missing_pct)>0).sort((a:AnyObj,b:AnyObj)=>Number(b.missing_pct)-Number(a.missing_pct)).slice(0,12);
  const severityCounts:Record<string,number>={}; for(const issue of result.quality.issues??[]){severityCounts[String(issue.severity??'info')]=(severityCounts[String(issue.severity??'info')]??0)+1;}
  const severityRows=Object.entries(severityCounts).map(([severity,count])=>({severity,count}));
  const actions=Array.isArray(remediation?.actions)?remediation.actions:[];
  const before=remediationPreview?.before; const after=remediationPreview?.after;
  return <div className="page"><div className="page-title"><div><span className="eyebrow">DATA QUALITY</span><h1>Diagnostic de qualité</h1><p>Complétude, doublons, colonnes constantes et valeurs aberrantes avec remédiation guidée, prévisualisée et versionnée.</p></div><div className={`score-ring ${result.quality.score >= 80 ? 'good' : result.quality.score >= 60 ? 'warn' : 'bad'}`}><strong>{result.quality.score}</strong><span>/100</span></div></div><div className="metrics"><Stat label="Score qualité" value={`${result.quality.score}/100`}/><Stat label="Problèmes" value={result.quality.issues_count}/><Stat label="Doublons" value={result.profile.duplicates}/><Stat label="Statut" value={result.quality.score >= 80 ? 'Bon' : result.quality.score >= 60 ? 'À revoir' : 'Critique'}/></div>
    <div className="two-col"><Panel title="Complétude — valeurs manquantes">{missing.length?<BarChart rows={missing} valueKey="missing_pct" labelKey="name" suffix="%"/>:<div className="success-box">✓ Dataset complet sur les colonnes profilées.</div>}</Panel><Panel title="Répartition des alertes">{severityRows.length?<BarChart rows={severityRows} valueKey="count" labelKey="severity"/>:<div className="success-box">✓ Aucune alerte qualité.</div>}</Panel></div>
    <Panel title="Remédiation guidée"><div className="quality-remediation-head"><div><b>Plan déterministe et réversible</b><p>Aucune correction silencieuse : vous choisissez les actions, DataVision prévisualise leur impact puis crée une nouvelle version immuable.</p></div>{before&&after&&<div className="quality-remediation-delta"><span>Avant <b>{before.score}/100</b></span><span>→</span><span>Après <b>{after.score}/100</b></span><small>{Number(after.score)-Number(before.score)>=0?'+':''}{Number(after.score)-Number(before.score)} point(s) · {after.issues_count} problème(s)</small></div>}</div>
      {!remediation?<div className="loading-card">Préparation du plan de remédiation…</div>:actions.length===0?<div className="success-box">✓ Aucun correctif automatique sûr à proposer pour les contrôles actuels.</div>:<div className="quality-remediation-list">{actions.map((a:AnyObj)=><label key={a.id} className={`quality-remediation-action ${selectedActions.includes(a.id)?'selected':''}`}><input type="checkbox" checked={selectedActions.includes(a.id)} onChange={()=>toggleRemediationAction(a.id)}/><div><div className="quality-remediation-title"><b>{a.title}</b><span className={`priority ${a.risk}`}>{a.risk}</span>{a.review_required&&<span className="review-chip">validation requise</span>}</div><p>{a.reason}</p><small>Confiance {Math.round(Number(a.confidence??0)*100)}% · nouvelle version · rollback possible</small></div></label>)}</div>}
      {actions.length>0&&<div className="quality-remediation-actions"><span>{selectedActions.length} action(s) sélectionnée(s){remediationBusy?' · calcul en cours…':''}</span><button disabled={remediationBusy||selectedActions.length===0} onClick={applyRemediation}>{remediationBusy?'Traitement…':'Appliquer dans une nouvelle version'}</button></div>}
    </Panel>
    <Panel title="Problèmes détectés">{result.quality.issues.length===0?<div className="success-box">✓ Aucun problème détecté par les règles actuellement implémentées.</div>:<div className="issue-list">{result.quality.issues.map((i:AnyObj,idx:number)=><article key={idx} className={`issue ${i.severity}`}><span className="severity">{i.severity}</span><div><b>{i.column?`${i.column} — `:''}{i.description}</b><p>{i.impact}</p><small>Recommandation : {i.recommendation}</small></div></article>)}</div>}</Panel><Panel title="Aide à la décision"><div className="decision-list">{result.decision.actions.map((a:AnyObj,i:number)=><div key={i}><span className={`priority ${a.priority}`}>{a.priority}</span><div><b>{a.action}</b><small>Preuve : {a.evidence}</small></div></div>)}</div></Panel></div>;
}

function PrepareView({ result, setError, onTransformed, onActivate }: { result:AnyObj|null; setError:(s:string)=>void; onTransformed:(r:AnyObj)=>void; onActivate:(id:string)=>Promise<AnyObj|null> }) {
  const [operation,setOperation]=useState('fill_missing');
  const [column,setColumn]=useState('');
  const [secondColumn,setSecondColumn]=useState('');
  const [selected,setSelected]=useState<string[]>([]);
  const [selected2,setSelected2]=useState<string[]>([]);
  const [newName,setNewName]=useState('');
  const [expression,setExpression]=useState('');
  const [strategy,setStrategy]=useState('median');
  const [constant,setConstant]=useState('');
  const [dtype,setDtype]=useState('string');
  const [operator,setOperator]=useState('eq');
  const [filterValue,setFilterValue]=useState('');
  const [ascending,setAscending]=useState(true);
  const [iqrFactor,setIqrFactor]=useState(1.5);
  const [outlierMode,setOutlierMode]=useState('clip');
  const [aggFunction,setAggFunction]=useState('mean');
  const [aggAlias,setAggAlias]=useState('');
  const [pivotAgg,setPivotAgg]=useState('mean');
  const [varName,setVarName]=useState('variable');
  const [valueName,setValueName]=useState('value');
  const [dateParts,setDateParts]=useState<string[]>(['year','month']);
  const [binMethod,setBinMethod]=useState('quantile');
  const [binCount,setBinCount]=useState(4);
  const [lagPeriods,setLagPeriods]=useState(1);
  const [rollingWindow,setRollingWindow]=useState(3);
  const [rollingFunction,setRollingFunction]=useState('mean');
  const [rollingMinPeriods,setRollingMinPeriods]=useState(1);
  const [orderColumn,setOrderColumn]=useState('');
  const [busy,setBusy]=useState(false);
  const [switching,setSwitching]=useState('');
  const [catalog,setCatalog]=useState<AnyObj[]>([]);
  const [pipelines,setPipelines]=useState<AnyObj[]>([]);
  const [pipelineName,setPipelineName]=useState('');
  const [pipelineBusy,setPipelineBusy]=useState('');
  const [pipelineChecks,setPipelineChecks]=useState<Record<string,AnyObj>>({});
  const [pipelineBindings,setPipelineBindings]=useState<Record<string,Record<string,string>>>({});
  const [otherDataset,setOtherDataset]=useState('');
  const [otherColumns,setOtherColumns]=useState<AnyObj[]>([]);
  const [combineType,setCombineType]=useState('merge');
  const [leftKey,setLeftKey]=useState('');
  const [rightKey,setRightKey]=useState('');
  const [joinHow,setJoinHow]=useState('inner');
  const columns=result?.profile?.columns??[];
  const numeric=columns.filter(isNumeric);
  const categorical=columns.filter((c:AnyObj)=>!isNumeric(c));

  useEffect(()=>{
    if(!result) return;
    setColumn(columns[0]?.name??''); setSecondColumn(numeric[0]?.name??columns[0]?.name??''); setOrderColumn(''); setSelected([]); setSelected2([]); setNewName(''); setExpression('');
    Promise.all([getDatasetCatalog(),getPipelines(result.dataset.id)]).then(([c,p])=>{
      const choices=(c.datasets??[]).filter((d:AnyObj)=>d.id!==result.dataset.id);
      setCatalog(choices); setPipelines(p.pipelines??[]);
      setOtherDataset(prev=>choices.some((d:AnyObj)=>d.id===prev)?prev:(choices[0]?.id??''));
    }).catch(()=>{});
  },[result?.dataset?.id]);

  useEffect(()=>{
    if(!otherDataset){setOtherColumns([]);setRightKey('');return;}
    getProfile(otherDataset).then(p=>{setOtherColumns(p.columns??[]);setRightKey((p.columns??[])[0]?.name??'');}).catch(()=>setOtherColumns([]));
  },[otherDataset]);

  useEffect(()=>{
    if(['clip_outliers_iqr','bin_numeric','rolling_feature'].includes(operation) && !numeric.some((c:AnyObj)=>c.name===column)) setColumn(numeric[0]?.name??'');
  },[operation,result?.dataset?.id]);
  if(!result) return <EmptyState title="Studio de préparation" text="Chargez un dataset pour nettoyer, transformer, combiner et versionner les données sans modifier l’original."/>;

  const operationMeta:Record<string,{label:string;help:string;icon:string}>={
    fill_missing:{label:'Imputer les valeurs manquantes',help:'Moyenne, médiane, mode ou constante.',icon:'∅'},
    remove_duplicates:{label:'Supprimer les doublons',help:'Toutes les colonnes ou un sous-ensemble.',icon:'≡'},
    rename_column:{label:'Renommer une colonne',help:'Renommage traçable et versionné.',icon:'✎'},
    drop_columns:{label:'Supprimer des colonnes',help:'Retrait uniquement dans la nouvelle version.',icon:'−'},
    cast_type:{label:'Convertir le type',help:'String, entier, réel, booléen, date ou catégorie.',icon:'T'},
    filter_rows:{label:'Filtrer les lignes',help:'Filtres numériques, texte et valeurs nulles.',icon:'⌕'},
    sort_rows:{label:'Trier les lignes',help:'Tri stable croissant ou décroissant.',icon:'↕'},
    clip_outliers_iqr:{label:'Traiter les outliers IQR',help:'Écrêter ou retirer les observations aberrantes.',icon:'◇'},
    standardize:{label:'Standardiser (Z-score)',help:'Centrer et réduire les variables numériques.',icon:'σ'},
    normalize_minmax:{label:'Normaliser Min-Max',help:'Ramener les variables entre 0 et 1.',icon:'↔'},
    one_hot_encode:{label:'Encodage one-hot',help:'Créer des indicatrices pour les catégories.',icon:'01'},
    add_calculated_column:{label:'Variable calculée',help:'Feature engineering avec expression sûre.',icon:'ƒ'},
    groupby_aggregate:{label:'GroupBy & agrégation',help:'Résumer les données par groupe.',icon:'Σ'},
    pivot_table:{label:'Pivot',help:'Transformer les modalités en colonnes.',icon:'⊞'},
    melt_unpivot:{label:'Unpivot / Melt',help:'Transformer des colonnes en lignes.',icon:'⇵'},
    extract_date_parts:{label:'Composantes de date',help:'Année, trimestre, mois, jour, semaine, heure.',icon:'◷'},
    bin_numeric:{label:'Discrétiser une variable',help:'Classes quantiles ou intervalles de largeur égale.',icon:'▥'},
    lag_feature:{label:'Variable retardée (lag)',help:'Décalage temporel, avec groupe et ordre optionnels.',icon:'↶'},
    rolling_feature:{label:'Fenêtre glissante',help:'Moyenne, somme, min, max, médiane ou écart-type rolling.',icon:'≈'},
  };

  async function apply(){
    setBusy(true);setError('');
    try{
      let op:AnyObj={type:operation};
      if(operation==='fill_missing') op={...op,column,strategy,...(strategy==='constant'?{value:constant}:{})};
      if(operation==='remove_duplicates') op={...op,subset:selected};
      if(operation==='rename_column') op={...op,column,new_name:newName};
      if(operation==='drop_columns') op={...op,columns:selected};
      if(operation==='cast_type') op={...op,column,dtype};
      if(operation==='filter_rows') op={...op,column,operator,...(!['is_null','not_null'].includes(operator)?{value:filterValue}:{})};
      if(operation==='sort_rows') op={...op,column,ascending};
      if(operation==='clip_outliers_iqr') op={...op,column,factor:iqrFactor,mode:outlierMode};
      if(operation==='standardize'||operation==='normalize_minmax'||operation==='one_hot_encode') op={...op,columns:selected};
      if(operation==='add_calculated_column') op={...op,new_name:newName,expression};
      if(operation==='groupby_aggregate'){const targets=selected2.length?selected2:[column];op={...op,group_by:selected,aggregations:targets.map((name:string,index:number)=>({column:name,function:aggFunction,alias:targets.length===1?(aggAlias||undefined):`${name}_${aggFunction}_${index+1}`}))};}
      if(operation==='pivot_table') op={...op,index:selected,columns:column,values:secondColumn,aggfunc:pivotAgg};
      if(operation==='melt_unpivot') op={...op,id_vars:selected,value_vars:selected2,var_name:varName,value_name:valueName};
      if(operation==='extract_date_parts') op={...op,column,parts:dateParts};
      if(operation==='bin_numeric') op={...op,column,new_name:newName||`${column}__bin`,method:binMethod,bins:binCount};
      if(operation==='lag_feature') op={...op,column,new_name:newName||`${column}__lag${lagPeriods}`,periods:lagPeriods,group_by:selected,order_by:orderColumn||undefined};
      if(operation==='rolling_feature') op={...op,column,new_name:newName||`${column}__rolling_${rollingFunction}_${rollingWindow}`,window:rollingWindow,function:rollingFunction,min_periods:rollingMinPeriods,group_by:selected,order_by:orderColumn||undefined};
      const next=await transformDataset(result!.dataset.id,op);
      onTransformed(next); setSelected([]); setSelected2([]); setNewName(''); setExpression('');
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false);}
  }

  async function combine(){
    if(!otherDataset) return setError('Chargez au moins un second dataset avant de lancer une combinaison.');
    setBusy(true);setError('');
    try{
      let op:AnyObj={type:combineType};
      if(combineType==='merge'){const leftKeys=(leftKey||columns[0]?.name||'').split(',').map((x:string)=>x.trim()).filter(Boolean);const rightKeys=rightKey.split(',').map((x:string)=>x.trim()).filter(Boolean);if(!leftKeys.length||leftKeys.length!==rightKeys.length)throw new Error('Les clés gauche et droite doivent contenir le même nombre de colonnes, séparées par des virgules.');op={...op,left_on:leftKeys,right_on:rightKeys,how:joinHow};}
      if(combineType==='concat_rows') op={...op,join:'outer'};
      const next=await combineDataset(result!.dataset.id,otherDataset,op);
      onTransformed(next);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false);}
  }

  async function saveCurrentPipeline(){
    setPipelineBusy('save');setError('');
    try{const r=await savePipeline(result!.dataset.id,pipelineName||`Pipeline v${result!.dataset.version}`);setPipelines(r.pipelines??[]);setPipelineName('');}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setPipelineBusy('');}
  }
  async function validateSavedPipeline(id:string){
    setPipelineBusy(`validate:${id}`);setError('');
    try{const baseId=result!.versions?.root_id??result!.dataset.root_id??result!.dataset.id;const check=await validatePipeline(baseId,id,pipelineBindings[id]??{});setPipelineChecks(prev=>({...prev,[id]:check}));}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setPipelineBusy('');}
  }
  async function replayPipeline(id:string){
    setPipelineBusy(id);setError('');
    try{const baseId=result!.versions?.root_id??result!.dataset.root_id??result!.dataset.id;const next=await runPipeline(baseId,id,pipelineBindings[id]??{});onTransformed(next);}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setPipelineBusy('');}
  }
  async function activate(id:string){setSwitching(id);setError('');try{await onActivate(id);}finally{setSwitching('');}}

  const versions=result.versions?.versions??[];
  const lineage=versions.filter((v:AnyObj)=>v.in_lineage).sort((a:AnyObj,b:AnyObj)=>a.version-b.version);
  return <div className="page"><div className="page-title"><div><span className="eyebrow">DATA PREPARATION STUDIO</span><h1>Préparation, pipeline & versioning</h1><p>Nettoyage, feature engineering, agrégations et combinaisons multi-datasets avec provenance et rollback.</p></div><span className="module-state implemented">implémenté</span></div>
    <div className="metrics"><Stat label="Version active" value={`v${result.dataset.version??1}`}/><Stat label="Lignes" value={result.profile.rows}/><Stat label="Variables" value={result.profile.columns_count}/><Stat label="Étapes actives" value={Math.max(0,lineage.length-1)}/></div>

    <Panel title="Pipeline visuel de la branche active" action={<span className="quiet">rejouable · traçable</span>}><div className="pipeline-canvas">{lineage.map((v:AnyObj,i:number)=><div className="pipeline-wrap" key={v.id}><div className={v.id===result.dataset.id?'pipeline-node active':'pipeline-node'}><span>v{v.version}</span><b>{v.operation?.label??'Import source'}</b><small>{v.operation?.type??'upload'}</small></div>{i<lineage.length-1&&<div className="pipeline-arrow">→</div>}</div>)}</div></Panel>

    <div className="prep-layout">
      <Panel title="Transformations"><div className="prep-operation-list">{Object.entries(operationMeta).map(([key,m])=><button key={key} className={operation===key?'prep-op active':'prep-op'} onClick={()=>{setOperation(key);setSelected([]);setSelected2([]);}}><span>{m.icon}</span><div><b>{m.label}</b><small>{m.help}</small></div></button>)}</div></Panel>
      <Panel title={operationMeta[operation].label}><div className="analysis-config prep-config">
        {['fill_missing','rename_column','cast_type','filter_rows','sort_rows','clip_outliers_iqr','pivot_table','extract_date_parts','groupby_aggregate','bin_numeric','lag_feature','rolling_feature'].includes(operation)&&<label>{operation==='pivot_table'?'Colonne de pivot':operation==='groupby_aggregate'?'Variable à agréger':'Colonne'}<select value={column} onChange={e=>setColumn(e.target.value)}>{(['clip_outliers_iqr','groupby_aggregate','bin_numeric','rolling_feature'].includes(operation)?numeric:columns).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}
        {operation==='fill_missing'&&<><label>Stratégie<select value={strategy} onChange={e=>setStrategy(e.target.value)}><option value="median">Médiane</option><option value="mean">Moyenne</option><option value="mode">Mode</option><option value="constant">Valeur constante</option></select></label>{strategy==='constant'&&<label>Valeur constante<input value={constant} onChange={e=>setConstant(e.target.value)} placeholder="Valeur de remplacement"/></label>}</>}
        {operation==='rename_column'&&<label>Nouveau nom<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="nouveau_nom"/></label>}
        {operation==='cast_type'&&<label>Type cible<select value={dtype} onChange={e=>setDtype(e.target.value)}><option value="string">String</option><option value="integer">Integer</option><option value="float">Float</option><option value="boolean">Boolean</option><option value="datetime">Date/heure</option><option value="category">Catégorie</option></select></label>}
        {operation==='filter_rows'&&<><label>Opérateur<select value={operator} onChange={e=>setOperator(e.target.value)}><option value="eq">égal à</option><option value="ne">différent de</option><option value="gt">supérieur à</option><option value="gte">supérieur ou égal</option><option value="lt">inférieur à</option><option value="lte">inférieur ou égal</option><option value="contains">contient</option><option value="not_contains">ne contient pas</option><option value="is_null">est manquant</option><option value="not_null">n’est pas manquant</option></select></label>{!['is_null','not_null'].includes(operator)&&<label>Valeur<input value={filterValue} onChange={e=>setFilterValue(e.target.value)} placeholder="Valeur du filtre"/></label>}</>}
        {operation==='sort_rows'&&<div><span className="config-label">Ordre</span><div className="segmented"><button className={ascending?'active':''} onClick={()=>setAscending(true)}>Croissant</button><button className={!ascending?'active':''} onClick={()=>setAscending(false)}>Décroissant</button></div></div>}
        {operation==='clip_outliers_iqr'&&<><label>Facteur IQR<input type="number" min="0.1" step="0.1" value={iqrFactor} onChange={e=>setIqrFactor(Number(e.target.value)||1.5)}/></label><label>Action<select value={outlierMode} onChange={e=>setOutlierMode(e.target.value)}><option value="clip">Écrêter aux bornes</option><option value="remove">Supprimer les lignes</option></select></label></>}
        {['drop_columns','remove_duplicates','standardize','normalize_minmax','one_hot_encode'].includes(operation)&&<div><span className="config-label">{operation==='remove_duplicates'?'Sous-ensemble (vide = toutes les colonnes)':'Colonnes'}</span><VariableChecklist columns={operation==='standardize'||operation==='normalize_minmax'?numeric:operation==='one_hot_encode'?categorical:columns} selected={selected} setSelected={setSelected}/></div>}
        {operation==='add_calculated_column'&&<><label>Nom de la variable<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="indice_risque"/></label><label>Expression<input value={expression} onChange={e=>setExpression(e.target.value)} placeholder={'col("Age") * 0.5 + col("Score")'} /></label><small className="help-text">DSL sûre : col("Nom"), nombres, + − × ÷ ** %, abs(), sqrt(), log(), log1p(), round(). Aucun eval Python.</small></>}
        {operation==='groupby_aggregate'&&<><div><span className="config-label">Regrouper par</span><VariableChecklist columns={columns} selected={selected} setSelected={setSelected}/></div><div><span className="config-label">Variables à agréger</span><VariableChecklist columns={numeric} selected={selected2} setSelected={setSelected2}/></div><label>Fonction<select value={aggFunction} onChange={e=>setAggFunction(e.target.value)}>{['mean','sum','min','max','median','count','nunique','std','var'].map(x=><option key={x}>{x}</option>)}</select></label>{selected2.length<=1&&<label>Alias optionnel<input value={aggAlias} onChange={e=>setAggAlias(e.target.value)} placeholder={`${selected2[0]??column}_${aggFunction}`}/></label>}</>}
        {operation==='pivot_table'&&<><div><span className="config-label">Index</span><VariableChecklist columns={columns.filter((c:AnyObj)=>c.name!==column)} selected={selected} setSelected={setSelected}/></div><label>Valeur<select value={secondColumn} onChange={e=>setSecondColumn(e.target.value)}>{numeric.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Agrégation<select value={pivotAgg} onChange={e=>setPivotAgg(e.target.value)}>{['mean','sum','min','max','median','count'].map(x=><option key={x}>{x}</option>)}</select></label></>}
        {operation==='melt_unpivot'&&<><div><span className="config-label">Colonnes identifiantes</span><VariableChecklist columns={columns} selected={selected} setSelected={setSelected}/></div><div><span className="config-label">Colonnes à dé-pivoter</span><VariableChecklist columns={columns.filter((c:AnyObj)=>!selected.includes(c.name))} selected={selected2} setSelected={setSelected2}/></div><label>Nom colonne variable<input value={varName} onChange={e=>setVarName(e.target.value)}/></label><label>Nom colonne valeur<input value={valueName} onChange={e=>setValueName(e.target.value)}/></label></>}
        {operation==='extract_date_parts'&&<div><span className="config-label">Composantes</span><div className="date-parts">{['year','quarter','month','day','weekday','hour'].map(p=><label key={p}><input type="checkbox" checked={dateParts.includes(p)} onChange={e=>setDateParts(e.target.checked?[...dateParts,p]:dateParts.filter(x=>x!==p))}/>{p}</label>)}</div></div>}
        {operation==='bin_numeric'&&<><label>Méthode<select value={binMethod} onChange={e=>setBinMethod(e.target.value)}><option value="quantile">Quantiles</option><option value="width">Largeur égale</option></select></label><label>Nombre de classes<input type="number" min="2" max="100" value={binCount} onChange={e=>setBinCount(Math.max(2,Number(e.target.value)||4))}/></label><label>Nouvelle variable<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder={`${column}__bin`}/></label></>}
        {operation==='lag_feature'&&<><label>Décalage (périodes)<input type="number" min="1" max="10000" value={lagPeriods} onChange={e=>setLagPeriods(Math.max(1,Number(e.target.value)||1))}/></label><label>Nouvelle variable<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder={`${column}__lag${lagPeriods}`}/></label><div><span className="config-label">Regrouper par (optionnel)</span><VariableChecklist columns={columns.filter((c:AnyObj)=>c.name!==column)} selected={selected} setSelected={setSelected}/></div><label>Ordonner par<select value={orderColumn} onChange={e=>setOrderColumn(e.target.value)}><option value="">Ordre actuel</option>{columns.filter((c:AnyObj)=>c.name!==column).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label></>}
        {operation==='rolling_feature'&&<><label>Fenêtre<input type="number" min="2" max="10000" value={rollingWindow} onChange={e=>setRollingWindow(Math.max(2,Number(e.target.value)||3))}/></label><label>Fonction<select value={rollingFunction} onChange={e=>setRollingFunction(e.target.value)}>{['mean','sum','min','max','median','std'].map(x=><option key={x}>{x}</option>)}</select></label><label>Minimum de périodes<input type="number" min="1" max={rollingWindow} value={rollingMinPeriods} onChange={e=>setRollingMinPeriods(Math.max(1,Math.min(rollingWindow,Number(e.target.value)||1)))}/></label><label>Nouvelle variable<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder={`${column}__rolling_${rollingFunction}_${rollingWindow}`}/></label><div><span className="config-label">Regrouper par (optionnel)</span><VariableChecklist columns={columns.filter((c:AnyObj)=>c.name!==column)} selected={selected} setSelected={setSelected}/></div><label>Ordonner par<select value={orderColumn} onChange={e=>setOrderColumn(e.target.value)}><option value="">Ordre actuel</option>{columns.filter((c:AnyObj)=>c.name!==column).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label></>}
        <div className="prep-warning"><b>Transformation non destructive</b><span>Chaque action crée une version immuable; la source et les étapes restent auditables.</span></div>
        <RunButton busy={busy} label="Appliquer et créer une version" busyLabel="Transformation…" onClick={apply}/>
      </div></Panel>
    </div>

    <div className="two-col">
      <Panel title="Combiner avec un autre dataset"><div className="analysis-config prep-config"><label>Dataset secondaire<select value={otherDataset} onChange={e=>setOtherDataset(e.target.value)}><option value="">— sélectionner —</option>{catalog.map((d:AnyObj)=><option value={d.id} key={d.id}>{d.source_name??d.name} · v{d.version}</option>)}</select></label><label>Opération<select value={combineType} onChange={e=>setCombineType(e.target.value)}><option value="merge">Jointure par clé</option><option value="concat_rows">Concaténer les lignes</option><option value="concat_columns">Concaténer les colonnes</option></select></label>{combineType==='merge'&&<><label>Clé(s) gauche<input value={leftKey||columns[0]?.name||''} onChange={e=>setLeftKey(e.target.value)} placeholder="id, date"/><small className="help-text">Une ou plusieurs colonnes séparées par des virgules.</small></label><label>Clé(s) droite<input value={rightKey} onChange={e=>setRightKey(e.target.value)} placeholder="id, date"/><small className="help-text">Même nombre et même ordre que les clés gauches.</small></label><label>Type<select value={joinHow} onChange={e=>setJoinHow(e.target.value)}><option value="inner">Inner</option><option value="left">Left</option><option value="right">Right</option><option value="outer">Outer</option></select></label></>}<RunButton busy={busy} label="Combiner et versionner" busyLabel="Combinaison…" onClick={combine}/><small className="help-text">La provenance du dataset secondaire est enregistrée dans l’opération.</small></div></Panel>
      <Panel title="Pipelines sauvegardés"><div className="pipeline-save"><input value={pipelineName} onChange={e=>setPipelineName(e.target.value)} placeholder="Nom du pipeline"/><button className="primary-btn" disabled={pipelineBusy==='save'} onClick={saveCurrentPipeline}>{pipelineBusy==='save'?'Enregistrement…':'Enregistrer la branche active'}</button></div><div className="saved-pipelines">{pipelines.length===0?<p className="quiet">Aucun pipeline enregistré.</p>:pipelines.map((p:AnyObj)=><div key={p.id}><div><b>{p.name}</b><small>{p.steps_count} étapes · {p.multi_dataset?'multi-dataset · ':''}{new Date(p.created_at).toLocaleString('fr-FR')}</small>{(p.dependencies??[]).map((dep:AnyObj)=><label className="pipeline-binding" key={dep.root_id}>Dépendance · {dep.name??dep.root_id}<select value={pipelineBindings[p.id]?.[dep.root_id]??dep.dataset_id} onChange={e=>setPipelineBindings(prev=>({...prev,[p.id]:{...(prev[p.id]??{}),[dep.root_id]:e.target.value}}))}>{catalog.map((d:AnyObj)=><option key={d.id} value={d.id}>{d.source_name??d.name} · v{d.version}</option>)}</select></label>)}{pipelineChecks[p.id]&&<small className="pipeline-check">✓ {pipelineChecks[p.id].steps_count} étapes validées · {pipelineChecks[p.id].rows} lignes · {pipelineChecks[p.id].columns} colonnes</small>}</div><div className="pipeline-actions"><button className="ghost-btn" disabled={pipelineBusy===`validate:${p.id}`} onClick={()=>validateSavedPipeline(p.id)}>{pipelineBusy===`validate:${p.id}`?'Validation…':'Valider'}</button><button className="ghost-btn" disabled={pipelineBusy===p.id} onClick={()=>replayPipeline(p.id)}>{pipelineBusy===p.id?'Exécution…':'Rejouer'}</button></div></div>)}</div></Panel>
    </div>

    <Panel title="Aperçu de la version active" action={<span className="quiet">v{result.dataset.version??1} · {result.preview.shown}/{result.preview.total}</span>}><DataTable preview={result.preview}/></Panel>
    <Panel title="Historique & rollback" action={<span className="quiet">{versions.length} version(s)</span>}><div className="version-timeline">{versions.map((v:AnyObj)=><div className={v.id===result.dataset.id?'version-row current':'version-row'} key={v.id}><span className="version-node">v{v.version}</span><div><b>{v.operation?.label??'Version du dataset'}</b><small>{v.name} · {v.created_at?new Date(v.created_at).toLocaleString('fr-FR'):'date inconnue'}</small></div>{v.id===result.dataset.id?<span className="current-chip">active</span>:<button className="ghost-btn" disabled={switching===v.id} onClick={()=>activate(v.id)}>{switching===v.id?'Ouverture…':'Réactiver'}</button>}</div>)}</div><p className="version-note">Réactiver une version antérieure ne supprime aucune version : une nouvelle transformation repart de cet état et crée une branche distincte.</p></Panel>
  </div>;
}

function VariableChecklist({ columns, selected, setSelected, numericOnly=false }: { columns: AnyObj[]; selected: string[]; setSelected:(v:string[])=>void; numericOnly?:boolean }) {
  const usable = numericOnly ? columns.filter(isNumeric) : columns;
  return <div className="check-grid">{usable.map(c=><label className={selected.includes(c.name)?'check-item selected':'check-item'} key={c.name}><input type="checkbox" checked={selected.includes(c.name)} onChange={e=>setSelected(e.target.checked?[...selected,c.name]:selected.filter(x=>x!==c.name))}/><span><b>{c.name}</b><small>{c.dtype}</small></span></label>)}</div>;
}

function RegressionView({ result, setError }: { result: AnyObj | null; setError:(s:string)=>void }) {
  const columns=result?.profile?.columns ?? []; const rows=Number(result?.profile?.rows??0); const nums=columns.filter(isNumeric); const meaningfulNums=nums.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows));
  const [dependent,setDependent]=useState(''); const [independents,setIndependents]=useState<string[]>([]); const [analysis,setAnalysis]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false);
  useEffect(()=>{ if(result){const pool=meaningfulNums.length?meaningfulNums:nums;const dep=pool[pool.length-1]?.name??''; setDependent(dep); setIndependents(columns.filter((c:AnyObj)=>c.name!==dep&&!isLikelyIdentifier(c,rows)).slice(0,3).map((c:AnyObj)=>c.name)); setAnalysis(null);} },[result?.dataset?.id]);
  if(!result) return <EmptyState title="Analyse de Régression" text="Chargez un dataset avant de configurer une régression linéaire."/>;
  async function run(){setBusy(true);setError('');try{setAnalysis(await runRegression(result!.dataset.id,{dependent,independents}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">RÉGRESSION LINÉAIRE</span><h1>Analyse de Régression</h1><p>Estimation, intervalles de confiance, qualité d'ajustement et diagnostics complets des résidus et observations influentes.</p></div><span className="module-state implemented">implémenté</span></div>
    <Panel title="Configuration"><div className="analysis-config regression-config"><label>Variable dépendante<select value={dependent} onChange={e=>setDependent(e.target.value)}>{(meaningfulNums.length?meaningfulNums:nums).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><div><span className="config-label">Variables explicatives</span><VariableChecklist columns={columns.filter((c:AnyObj)=>c.name!==dependent&&!isLikelyIdentifier(c,rows))} selected={independents} setSelected={setIndependents}/></div><RunButton busy={busy} label="Exécuter la régression" busyLabel="Calcul de la régression…" onClick={run}/></div></Panel>
    {analysis && <><div className="metrics six"><Stat label="N" value={analysis.n}/><Stat label="R²" value={formatNumber(analysis.r_squared,4)}/><Stat label="R² ajusté" value={formatNumber(analysis.adj_r_squared,4)}/><Stat label="RMSE" value={formatNumber(analysis.rmse)}/><Stat label="MAE" value={formatNumber(analysis.mae)}/><Stat label="p modèle" value={pText(analysis.f_p_value)}/></div>
      <Panel title="Coefficients — estimation & IC 95 %"><CoefficientPlot rows={analysis.coefficients}/><details className="matrix-details"><summary>Voir le tableau détaillé</summary><SimpleTable rows={analysis.coefficients} columns={[["term","Terme"],["estimate","Coefficient"],["std_error","Erreur-type"],["t","t"],["p_value","p-value"],["ci_low","IC 95% bas"],["ci_high","IC 95% haut"]]}/></details></Panel>
      <div className="dashboard-grid regression-diagnostics"><Panel title="Résidus vs valeurs prédites"><ScatterPlot points={analysis.diagnostics.map((d:AnyObj)=>({x:d.predicted,y:d.residual}))} xLabel="Prédit" yLabel="Résidu" zeroLine/></Panel><Panel title="Q-Q plot des résidus"><QQPlot points={analysis.qq_points??[]} line={analysis.qq_line}/></Panel><Panel title="Distribution des résidus"><Histogram bins={analysis.residual_histogram??[]}/></Panel></div>
      <div className="two-col"><Panel title="Observé vs prédit"><ScatterPlot points={analysis.diagnostics.map((d:AnyObj)=>({x:d.predicted,y:d.observed}))} xLabel="Prédit" yLabel="Observé" diagonal/></Panel><Panel title="Tests & influence"><div className="test-cards"><TestCard name="Shapiro-Wilk — résidus" stat={analysis.tests.shapiro_wilk_residuals.statistic} p={analysis.tests.shapiro_wilk_residuals.p_value} goodWhenHigh/><TestCard name="Breusch-Pagan" stat={analysis.tests.breusch_pagan.lm_statistic} p={analysis.tests.breusch_pagan.lm_p_value} goodWhenHigh/></div>{analysis.influence?.length>0&&<><h4 className="subheading">Observations influentes — distance de Cook</h4><BarChart rows={analysis.influence.slice(0,12).map((r:AnyObj)=>({label:`#${r.index}`,value:r.cooks_distance}))} valueKey="value" labelKey="label"/></>}</Panel></div>
      <details className="analysis-details"><summary>Informations modèle (AIC, BIC, F)</summary><div className="metrics mini"><Stat label="F" value={formatNumber(analysis.f_statistic)}/><Stat label="AIC" value={formatNumber(analysis.aic)}/><Stat label="BIC" value={formatNumber(analysis.bic)}/><Stat label="Corrélation Q-Q" value={formatNumber(analysis.qq_line?.r,4)}/></div></details></>}
  </div>;
}

function AnovaView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const columns=result?.profile?.columns??[]; const rows=Number(result?.profile?.rows??0); const nums=columns.filter(isNumeric); const meaningfulNums=nums.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows)); const factors=columns.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows)&&Number(c.unique??0)>=2&&Number(c.unique??0)<=30);
  const [type,setType]=useState<'one'|'two'>('one'); const [response,setResponse]=useState(''); const [factor1,setFactor1]=useState(''); const [factor2,setFactor2]=useState(''); const [analysis,setAnalysis]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false); const [saved,setSaved]=useState('');
  useEffect(()=>{if(result){const pool=meaningfulNums.length?meaningfulNums:nums;const resp=pool[0]?.name??''; setResponse(resp); const fs=factors.filter((c:AnyObj)=>c.name!==resp); setFactor1(fs[0]?.name??''); setFactor2(fs[1]?.name??''); setAnalysis(null);}},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Analyse ANOVA" text="Chargez un dataset pour comparer les moyennes entre groupes."/>;
  async function run(){setBusy(true);setError('');try{setAnalysis(await runAnova(result!.dataset.id,{response,factor1,factor2:type==='two'?factor2:null}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">ANALYSE DE VARIANCE</span><h1>Analyse ANOVA</h1><p>Comparer les groupes, contrôler les hypothèses, quantifier la taille d'effet et visualiser les contrastes post-hoc.</p></div><span className="module-state implemented">implémenté</span></div>
    <Panel title="Configuration"><div className="analysis-config"><div className="segmented"><button className={type==='one'?'active':''} onClick={()=>setType('one')}>ANOVA 1 facteur</button><button className={type==='two'?'active':''} onClick={()=>setType('two')}>ANOVA 2 facteurs</button></div><div className="form-row"><label>Variable réponse<select value={response} onChange={e=>setResponse(e.target.value)}>{(meaningfulNums.length?meaningfulNums:nums).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Facteur 1<select value={factor1} onChange={e=>setFactor1(e.target.value)}>{factors.filter((c:AnyObj)=>c.name!==response).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>{type==='two'&&<label>Facteur 2<select value={factor2} onChange={e=>setFactor2(e.target.value)}>{factors.filter((c:AnyObj)=>c.name!==response&&c.name!==factor1).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}</div><RunButton busy={busy} label="Exécuter l’ANOVA" busyLabel="Calcul ANOVA…" onClick={run}/></div></Panel>
    {analysis && <><Panel title="Résultats de l’ANOVA"><SimpleTable rows={analysis.anova_table} columns={[["source","Source"],["sum_sq","Somme des carrés"],["df","ddl"],["f","F"],["p_value","p-value"],["effect_size",analysis.type==='two_way'?'η² partiel':'η²']]}/></Panel><div className="two-col"><Panel title="Conditions d’application"><div className="test-cards"><TestCard name="Levene — homogénéité" stat={analysis.levene.statistic} p={analysis.levene.p_value} goodWhenHigh/>{analysis.normality.map((x:AnyObj,i:number)=><TestCard key={i} name={`Shapiro-Wilk — ${x.group}`} stat={x.statistic} p={x.p_value} goodWhenHigh/>)}</div></Panel><Panel title="Statistiques descriptives par groupe"><SimpleTable rows={analysis.groups.map((g:AnyObj)=>({...g,boxplot:undefined}))} columns={Object.keys(analysis.groups[0]??{}).filter(k=>k!=='boxplot').map(k=>[k,k] as [string,string])}/></Panel></div>
      <Panel title="Distributions par groupe"><GroupBoxplots groups={analysis.groups} factor1={analysis.factor1} factor2={analysis.factor2}/></Panel>{analysis.tukey?.length>0&&<Panel title="Post-hoc de Tukey — différences & IC 95 %"><ConfidenceIntervalPlot rows={analysis.tukey}/><details className="matrix-details"><summary>Voir le tableau post-hoc</summary><SimpleTable rows={analysis.tukey} columns={[["group1","Groupe 1"],["group2","Groupe 2"],["mean_diff","Différence"],["ci_low","IC bas"],["ci_high","IC haut"],["p_adj","p ajustée"],["reject","Significatif"]]}/></details></Panel>}</>}
  </div>;
}

function PcaView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const nums=result?.profile?.columns?.filter(isNumeric)??[]; const meaningful=nums.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result?.profile?.rows??0))); const [selected,setSelected]=useState<string[]>([]); const [scale,setScale]=useState(true); const [analysis,setAnalysis]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false); const [saved,setSaved]=useState('');
  useEffect(()=>{if(result){setSelected((meaningful.length?meaningful:nums).slice(0,Math.min(5,(meaningful.length?meaningful:nums).length)).map((c:AnyObj)=>c.name));setAnalysis(null);}},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Analyse en Composantes Principales" text="Chargez un dataset comportant au moins deux variables numériques."/>;
  async function run(){setBusy(true);setError('');try{setAnalysis(await runPca(result!.dataset.id,{columns:selected,scale}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">ANALYSE MULTIVARIÉE</span><h1>Analyse en Composantes Principales</h1><p>Adéquation, variance expliquée, contributions des variables, projection des individus et matrice de covariance.</p></div><span className="module-state implemented">implémenté</span></div>
    <Panel title="Variables de l’ACP"><div className="analysis-config"><VariableChecklist columns={meaningful.length?meaningful:nums} selected={selected} setSelected={setSelected} numericOnly/><label className="switch-line"><input type="checkbox" checked={scale} onChange={e=>setScale(e.target.checked)}/> Standardiser les variables avant l’ACP</label><RunButton busy={busy} label="Lancer l’ACP" busyLabel="Calcul ACP…" onClick={run}/></div></Panel>
    {analysis&&<><div className="metrics"><Stat label="KMO" value={formatNumber(analysis.adequacy.kmo,4)}/><Stat label="Bartlett χ²" value={formatNumber(analysis.adequacy.bartlett_chi2)}/><Stat label="p Bartlett" value={pText(analysis.adequacy.bartlett_p_value)}/><Stat label="Variance PC1+PC2" value={`${formatNumber((analysis.variance[0]?.explained_pct??0)+(analysis.variance[1]?.explained_pct??0),2)} %`}/></div><div className="two-col"><Panel title="Scree plot & variance cumulée"><PcaScreeChart rows={analysis.variance}/></Panel><Panel title="Projection des individus — PC1 / PC2"><ScatterPlot points={analysis.scores.map((p:AnyObj)=>({x:p.PC1,y:p.PC2}))} xLabel="PC1" yLabel="PC2"/></Panel></div><Panel title="Variance expliquée"><SimpleTable rows={analysis.variance} columns={[['component','Composante'],['eigenvalue','Valeur propre'],['explained_pct','Variance %'],['cumulative_pct','Cumul %']]}/></Panel><div className="two-col"><Panel title="Cercle / charges factorielles"><LoadingPlot rows={analysis.variables}/></Panel><Panel title="Contributions des variables — PC1"><BarChart rows={analysis.variables} valueKey="contrib_PC1" labelKey="variable" suffix="%"/></Panel></div><Panel title="Matrice des composantes principales"><SimpleTable rows={analysis.variables} columns={Object.keys(analysis.variables[0]??{}).filter(k=>k==='variable'||(/^PC\d+$/.test(k))).map(k=>[k,k] as [string,string])}/></Panel><Panel title="Matrice de covariance"><CorrelationHeatmap matrix={analysis.covariance} columns={analysis.columns} mode="covariance"/><details className="matrix-details"><summary>Voir les valeurs numériques</summary><SimpleTable rows={analysis.covariance} columns={Object.keys(analysis.covariance[0]??{}).map(k=>[k,k] as [string,string])}/></details></Panel></>}
  </div>;
}

function ClusterView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const nums=result?.profile?.columns?.filter(isNumeric)??[]; const meaningful=nums.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result?.profile?.rows??0))); const [selected,setSelected]=useState<string[]>([]); const [k,setK]=useState(3); const [analysis,setAnalysis]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false); const [saved,setSaved]=useState('');
  useEffect(()=>{if(result){setSelected((meaningful.length?meaningful:nums).slice(0,Math.min(5,(meaningful.length?meaningful:nums).length)).map((c:AnyObj)=>c.name));setAnalysis(null);}},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Clustering K-means" text="Chargez un dataset avec au moins deux variables numériques."/>;
  async function run(){setBusy(true);setError('');try{setAnalysis(await runClustering(result!.dataset.id,{columns:selected,k}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">CLUSTERING NON SUPERVISÉ</span><h1>Clustering K-means</h1><p>Regroupez les observations, mesurez la qualité du partitionnement et caractérisez chaque cluster.</p></div><span className="module-state implemented">implémenté</span></div>
    <Panel title="Configuration"><div className="analysis-config"><VariableChecklist columns={meaningful.length?meaningful:nums} selected={selected} setSelected={setSelected} numericOnly/><label>Nombre de clusters K<input className="number-input" type="number" min={2} max={10} value={k} onChange={e=>setK(Math.max(2,Math.min(10,Number(e.target.value)||2)))}/></label><RunButton busy={busy} label="Lancer le clustering" busyLabel="Calcul des clusters…" onClick={run}/></div></Panel>
    {analysis&&<><div className="metrics"><Stat label="K" value={analysis.k}/><Stat label="Silhouette" value={formatNumber(analysis.silhouette,4)}/><Stat label="Inertie" value={formatNumber(analysis.inertia)}/><Stat label="Variance PCA 2D" value={`${formatNumber(analysis.pca_explained_pct,2)} %`}/></div><div className="two-col"><Panel title="Clusters identifiés"><ClusterScatter points={analysis.points}/></Panel><Panel title="Taille des clusters"><BarChart rows={(analysis.counts??[]).map((count:number,i:number)=>({cluster:`Cluster ${i}`,count}))} valueKey="count" labelKey="cluster"/></Panel></div><div className="two-col"><Panel title="Silhouette selon K"><LineChart rows={analysis.comparison} xKey="k" yKey="silhouette"/></Panel><Panel title="Inertie / méthode du coude"><LineChart rows={analysis.comparison} xKey="k" yKey="inertia"/></Panel></div><Panel title="Profils des clusters"><SimpleTable rows={analysis.profiles} columns={Object.keys(analysis.profiles[0]??{}).map(k=>[k,k] as [string,string])}/></Panel><Panel title="Centres des clusters"><SimpleTable rows={analysis.centers} columns={Object.keys(analysis.centers[0]??{}).map(k=>[k,k] as [string,string])}/></Panel></>}
  </div>;
}

function TestCard({ name, stat, p, goodWhenHigh=false }: { name:string; stat:any; p:any; goodWhenHigh?:boolean; key?:any }) { const ok=typeof p==='number' ? (goodWhenHigh?p>=0.05:p<0.05) : false; return <div className="test-card"><div><b>{name}</b><small>Statistique {formatNumber(stat)}</small></div><span className={ok?'test-ok':'test-warn'}>p {pText(p)}</span></div>; }
function SimpleTable({ rows, columns }: { rows:AnyObj[]; columns:[string,string][] }) { if(!rows?.length)return <div className="quiet-empty">Aucun résultat tabulaire.</div>; return <div className="table-scroll compact"><table><thead><tr>{columns.map(([k,l])=><th key={k}>{l}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{columns.map(([k])=><td key={k}>{typeof r[k]==='boolean'?(r[k]?'Oui':'Non'):formatNumber(r[k])}</td>)}</tr>)}</tbody></table></div>; }
function ScatterPlot({ points, xLabel, yLabel, zeroLine=false, diagonal=false }: { points:{x:number,y:number,cluster?:number}[]; xLabel:string; yLabel:string; zeroLine?:boolean; diagonal?:boolean }) { const clean=points.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)); if(!clean.length)return <div className="quiet-empty">Aucun point.</div>; const xs=clean.map(p=>p.x),ys=clean.map(p=>p.y),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(x:number)=>40+(x-xmin)/Math.max(xmax-xmin,1e-9)*520,sy=(y:number)=>235-(y-ymin)/Math.max(ymax-ymin,1e-9)*190; return <div className="svg-chart"><svg viewBox="0 0 600 280" role="img"><line x1="40" y1="235" x2="560" y2="235" className="axis"/><line x1="40" y1="45" x2="40" y2="235" className="axis"/>{zeroLine&&ymin<=0&&ymax>=0&&<line x1="40" y1={sy(0)} x2="560" y2={sy(0)} className="guide"/>}{diagonal&&<line x1={sx(Math.max(xmin,ymin))} y1={sy(Math.max(xmin,ymin))} x2={sx(Math.min(xmax,ymax))} y2={sy(Math.min(xmax,ymax))} className="diag"/>}{clean.map((p,i)=><circle key={i} cx={sx(p.x)} cy={sy(p.y)} r="2.5" className="dot"/>)}<text x="300" y="270" className="axis-label">{xLabel}</text><text x="12" y="145" className="axis-label" transform="rotate(-90 12 145)">{yLabel}</text></svg></div>; }
function ClusterScatter({ points }: { points:AnyObj[] }) { const clean=points.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)); if(!clean.length)return <div className="quiet-empty">Aucun point.</div>; const xs=clean.map(p=>p.x),ys=clean.map(p=>p.y),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(x:number)=>35+(x-xmin)/Math.max(xmax-xmin,1e-9)*530,sy=(y:number)=>235-(y-ymin)/Math.max(ymax-ymin,1e-9)*195; return <div className="svg-chart"><svg viewBox="0 0 600 270"><line x1="35" y1="235" x2="565" y2="235" className="axis"/><line x1="35" y1="40" x2="35" y2="235" className="axis"/>{clean.map((p,i)=><circle key={i} cx={sx(p.x)} cy={sy(p.y)} r="3" className={`cluster-dot c${p.cluster%6}`}/>)}</svg><div className="cluster-legend">{[...new Set(clean.map(p=>p.cluster))].map(c=><span key={c}><i className={`cluster-dot c${c%6}`}/>Cluster {c}</span>)}</div></div>; }
function BarChart({ rows, valueKey, labelKey, suffix='' }: { rows:AnyObj[]; valueKey:string; labelKey:string; suffix?:string }) { const vals=rows.map(r=>Number(r[valueKey])||0),max=Math.max(1,...vals); return <div className="bar-chart">{rows.map((r,i)=><div className="bar-row" key={i}><span title={String(r[labelKey])}>{String(r[labelKey])}</span><div><i style={{width:`${Math.max(1,(Number(r[valueKey])||0)/max*100)}%`}}/></div><b>{formatNumber(r[valueKey],2)}{suffix}</b></div>)}</div>; }
function LineChart({ rows, xKey, yKey }: { rows:AnyObj[]; xKey:string; yKey:string }) { if(!rows?.length)return <div className="quiet-empty">Aucun point.</div>; const clean=rows.filter(r=>Number.isFinite(Number(r[xKey]))&&Number.isFinite(Number(r[yKey]))); if(!clean.length)return <div className="quiet-empty">Aucun point numérique.</div>; const xs=clean.map(r=>Number(r[xKey])),ys=clean.map(r=>Number(r[yKey])),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(x:number)=>55+(x-xmin)/Math.max(xmax-xmin,1)*490,sy=(y:number)=>210-(y-ymin)/Math.max(ymax-ymin,1e-9)*150; const pts=clean.map(r=>`${sx(Number(r[xKey]))},${sy(Number(r[yKey]))}`).join(' '); const step=Math.max(1,Math.ceil(clean.length/6)); return <div className="svg-chart"><svg viewBox="0 0 600 250"><line x1="55" y1="210" x2="545" y2="210" className="axis"/><line x1="55" y1="60" x2="55" y2="210" className="axis"/><polyline points={pts} className="trend"/>{clean.map((r,i)=><g key={i}><circle cx={sx(Number(r[xKey]))} cy={sy(Number(r[yKey]))} r="3.5" className="trend-dot"/>{(i%step===0||i===clean.length-1)&&<text x={sx(Number(r[xKey]))} y="230" className="tick">{formatNumber(r[xKey],2)}</text>}</g>)}<text x="58" y="52" className="tick ytick">{formatNumber(ymax,2)}</text><text x="58" y="207" className="tick ytick">{formatNumber(ymin,2)}</text></svg></div>; }

function CategoryLineChart({rows,area=false,valueLabel='Valeur'}:{rows:AnyObj[];area?:boolean;valueLabel?:string}) { if(!rows?.length)return <div className="quiet-empty">Aucun point.</div>; const clean=rows.filter(r=>Number.isFinite(Number(r.value))); if(!clean.length)return <div className="quiet-empty">Aucun point.</div>; const vals=clean.map(r=>Number(r.value)),min=Math.min(...vals),max=Math.max(...vals),span=Math.max(max-min,1e-9),sx=(i:number)=>50+i/Math.max(clean.length-1,1)*500,sy=(v:number)=>205-(v-min)/span*145; const pts=clean.map((r,i)=>`${sx(i)},${sy(Number(r.value))}`).join(' '); const step=Math.max(1,Math.ceil(clean.length/6)); const areaPts=`50,205 ${pts} ${sx(clean.length-1)},205`; return <div className="svg-chart"><svg viewBox="0 0 600 255">{area&&<polygon points={areaPts} className="area-fill"/>}<line x1="50" y1="205" x2="550" y2="205" className="axis"/><line x1="50" y1="55" x2="50" y2="205" className="axis"/><polyline points={pts} className="trend"/>{clean.map((r,i)=><g key={i}>{(i%step===0||i===clean.length-1)&&<text x={sx(i)} y="228" className="tick category-tick">{String(r.label).slice(0,14)}</text>}</g>)}<text x="55" y="45" className="axis-note">{valueLabel}</text></svg></div>; }

function XYLineChart({rows,xKey,yKey,xLabel,yLabel}:{rows:AnyObj[];xKey:string;yKey:string;xLabel:string;yLabel:string}) { const clean=rows.filter(r=>Number.isFinite(Number(r[xKey]))&&Number.isFinite(Number(r[yKey]))); if(!clean.length)return <div className="quiet-empty">Aucune donnée.</div>; const xs=clean.map(r=>Number(r[xKey])),ys=clean.map(r=>Number(r[yKey])),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(v:number)=>55+(v-xmin)/Math.max(xmax-xmin,1e-9)*490,sy=(v:number)=>205-(v-ymin)/Math.max(ymax-ymin,1e-9)*145,pts=clean.map(r=>`${sx(Number(r[xKey]))},${sy(Number(r[yKey]))}`).join(' '); return <div className="svg-chart"><svg viewBox="0 0 600 255"><line x1="55" y1="205" x2="545" y2="205" className="axis"/><line x1="55" y1="55" x2="55" y2="205" className="axis"/><polyline points={pts} className="trend"/><text x="300" y="245" className="axis-label">{xLabel}</text><text x="16" y="130" className="axis-label" transform="rotate(-90 16 130)">{yLabel}</text></svg></div>; }

function CorrelationHeatmap({matrix,columns,mode='correlation'}:{matrix:AnyObj[];columns:string[];mode?:'correlation'|'covariance'}) { if(!matrix?.length||!columns?.length)return <div className="quiet-empty">Matrice indisponible.</div>; const values=matrix.flatMap(r=>columns.map(c=>Number(r[c])).filter(Number.isFinite)); const maxAbs=mode==='correlation'?1:Math.max(1e-12,...values.map(v=>Math.abs(v))); return <div className="heatmap-scroll"><div className="heatmap-grid" style={{gridTemplateColumns:`minmax(120px,1.25fr) repeat(${columns.length},minmax(58px,1fr))`}}><span className="heatmap-corner"></span>{columns.map(c=><b key={`h-${c}`} title={c}>{c}</b>)}{matrix.map((r,i)=><Fragment key={i}><b className="heatmap-row-label" title={String(r.variable)}>{r.variable}</b>{columns.map(c=>{const raw=Number(r[c]);const norm=Number.isFinite(raw)?Math.min(1,Math.abs(raw)/maxAbs):0;const alpha=.08+norm*.72;const bg=!Number.isFinite(raw)?'transparent':raw>=0?`rgba(25, 160, 154, ${alpha})`:`rgba(210, 91, 86, ${alpha})`;return <span key={c} className="heatmap-cell" style={{background:bg,color:norm>.58?'white':'#344b58'}} title={`${r.variable} × ${c}: ${formatNumber(raw,3)}`}>{Number.isFinite(raw)?formatNumber(raw,2):'—'}</span>})}</Fragment>)}</div><div className="heatmap-legend"><span>−</span><i></i><span>0</span><i></i><span>+</span></div></div>; }

function ContingencyHeatmap({rows,columns}:{rows:AnyObj[];columns:string[]}) { if(!rows?.length||!columns?.length)return <div className="quiet-empty">Table de contingence indisponible.</div>; const max=Math.max(1,...rows.flatMap(r=>columns.map(c=>Number(r[c])||0))); return <div className="heatmap-scroll"><div className="heatmap-grid contingency-map" style={{gridTemplateColumns:`minmax(120px,1.25fr) repeat(${columns.length},minmax(64px,1fr))`}}><span className="heatmap-corner"></span>{columns.map(c=><b key={c} title={c}>{c}</b>)}{rows.map((r,i)=><Fragment key={i}><b className="heatmap-row-label">{String(r.row)}</b>{columns.map(c=>{const v=Number(r[c])||0;const a=.08+(v/max)*.72;return <span key={c} className="heatmap-cell" style={{background:`rgba(62,149,184,${a})`,color:v/max>.58?'white':'#344b58'}}>{v}</span>})}</Fragment>)}</div></div>; }

function CoefficientPlot({rows}:{rows:AnyObj[]}) { const clean=(rows??[]).filter(r=>r.term!=='const'&&Number.isFinite(Number(r.estimate))&&Number.isFinite(Number(r.ci_low))&&Number.isFinite(Number(r.ci_high))); if(!clean.length)return <div className="quiet-empty">Aucun coefficient exploitable.</div>; const vals=clean.flatMap(r=>[Number(r.ci_low),Number(r.ci_high),0]); const min=Math.min(...vals),max=Math.max(...vals),span=Math.max(max-min,1e-9),w=Math.max(700,clean.length*34+180),left=180,right=w-35,x=(v:number)=>left+(v-min)/span*(right-left),rowH=30,h=45+clean.length*rowH; return <div className="chart-scroll"><svg viewBox={`0 0 ${w} ${h}`} style={{minWidth:`${w}px`,height:`${h}px`}} className="ci-chart"><line x1={x(0)} y1="18" x2={x(0)} y2={h-18} className="reference-line"/>{clean.map((r,i)=>{const y=30+i*rowH;return <g key={r.term}><text x="8" y={y+4} className="ci-label"><title>{r.term}</title>{String(r.term).slice(0,26)}</text><line x1={x(Number(r.ci_low))} y1={y} x2={x(Number(r.ci_high))} y2={y} className="ci-range"/><circle cx={x(Number(r.estimate))} cy={y} r="4" className={Number(r.p_value)<.05?'ci-point significant':'ci-point'}/></g>})}<text x={left} y={h-3} className="axis-note">{formatNumber(min,2)}</text><text x={right-25} y={h-3} className="axis-note">{formatNumber(max,2)}</text></svg></div>; }

function QQPlot({points,line}:{points:AnyObj[];line?:AnyObj}) { const clean=(points??[]).filter(p=>Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y))); if(!clean.length)return <div className="quiet-empty">Q-Q plot indisponible.</div>; const xs=clean.map(p=>Number(p.x)),ys=clean.map(p=>Number(p.y)),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(v:number)=>45+(v-xmin)/Math.max(xmax-xmin,1e-9)*500,sy=(v:number)=>220-(v-ymin)/Math.max(ymax-ymin,1e-9)*165; const lineY=(x:number)=>Number(line?.intercept??0)+Number(line?.slope??1)*x; return <div className="svg-chart"><svg viewBox="0 0 590 255"><line x1="45" y1="220" x2="545" y2="220" className="axis"/><line x1="45" y1="55" x2="45" y2="220" className="axis"/><line x1={sx(xmin)} y1={sy(lineY(xmin))} x2={sx(xmax)} y2={sy(lineY(xmax))} className="diag"/>{clean.map((p,i)=><circle key={i} cx={sx(Number(p.x))} cy={sy(Number(p.y))} r="2.4" className="dot"/>)}<text x="295" y="248" className="axis-label">Quantiles théoriques</text><text x="14" y="140" className="axis-label" transform="rotate(-90 14 140)">Résidus observés</text></svg></div>; }

function ConfidenceIntervalPlot({rows,labelKey='group2',estimateKey='mean_diff',lowKey='ci_low',highKey='ci_high'}:{rows:AnyObj[];labelKey?:string;estimateKey?:string;lowKey?:string;highKey?:string}) { const clean=(rows??[]).filter(r=>Number.isFinite(Number(r[estimateKey]))&&Number.isFinite(Number(r[lowKey]))&&Number.isFinite(Number(r[highKey]))); if(!clean.length)return <div className="quiet-empty">Intervalles indisponibles.</div>; const vals=clean.flatMap(r=>[Number(r[lowKey]),Number(r[highKey]),0]); const min=Math.min(...vals),max=Math.max(...vals),span=Math.max(max-min,1e-9),w=Math.max(720,clean.length*28+220),left=220,right=w-35,x=(v:number)=>left+(v-min)/span*(right-left),rowH=27,h=42+clean.length*rowH; return <div className="chart-scroll"><svg viewBox={`0 0 ${w} ${h}`} style={{minWidth:`${w}px`,height:`${h}px`}} className="ci-chart"><line x1={x(0)} y1="12" x2={x(0)} y2={h-18} className="reference-line"/>{clean.map((r,i)=>{const y=25+i*rowH,label=r.group1?`${r.group1} – ${r.group2}`:String(r[labelKey]);return <g key={i}><text x="8" y={y+4} className="ci-label"><title>{label}</title>{label.slice(0,31)}</text><line x1={x(Number(r[lowKey]))} y1={y} x2={x(Number(r[highKey]))} y2={y} className="ci-range"/><circle cx={x(Number(r[estimateKey]))} cy={y} r="4" className={r.reject?'ci-point significant':'ci-point'}/></g>})}</svg></div>; }

function PcaScreeChart({rows}:{rows:AnyObj[]}) { if(!rows?.length)return <div className="quiet-empty">Aucune composante.</div>; const max=Math.max(1,...rows.map(r=>Number(r.explained_pct)||0)),left=45,bottom=225,plotH=160,step=540/Math.max(rows.length,1),barW=Math.min(42,step*.62),x=(i:number)=>left+step*i+step/2,yVar=(v:number)=>bottom-(v/max)*plotH,yCum=(v:number)=>bottom-(v/100)*plotH,cumPts=rows.map((r,i)=>`${x(i)},${yCum(Number(r.cumulative_pct)||0)}`).join(' '); return <div className="svg-chart"><svg viewBox="0 0 640 280"><line x1={left} y1={bottom} x2="600" y2={bottom} className="axis"/><line x1={left} y1="65" x2={left} y2={bottom} className="axis"/>{rows.map((r,i)=><g key={i}><rect x={x(i)-barW/2} y={yVar(Number(r.explained_pct)||0)} width={barW} height={Math.max(1,bottom-yVar(Number(r.explained_pct)||0))} className="scree-bar"/><text x={x(i)} y="244" className="tick">{r.component}</text></g>)}<polyline points={cumPts} className="cumulative-line"/>{rows.map((r,i)=><circle key={`c${i}`} cx={x(i)} cy={yCum(Number(r.cumulative_pct)||0)} r="3" className="cumulative-dot"/>)}<text x="52" y="58" className="axis-note">Variance % / cumul %</text></svg></div>; }

function LoadingPlot({ rows }: { rows:AnyObj[] }) { const pts=rows.filter(r=>Number.isFinite(r.PC1)&&Number.isFinite(r.PC2)); const max=Math.max(1,...pts.flatMap(r=>[Math.abs(r.PC1),Math.abs(r.PC2)])); const sx=(v:number)=>300+v/max*185; const sy=(v:number)=>140-v/max*92; return <div className="svg-chart"><svg viewBox="0 0 600 285"><circle cx="300" cy="140" r="95" className="circle-guide"/><line x1="110" y1="140" x2="490" y2="140" className="guide"/><line x1="300" y1="35" x2="300" y2="245" className="guide"/>{pts.map((r,i)=>{const x=sx(r.PC1),y=sy(r.PC2),dx=x>=300?6:-6,anchor=x>=300?'start':'end',dy=(i%3-1)*10;return <g key={i}><line x1="300" y1="140" x2={x} y2={y} className="loading-line"/><circle cx={x} cy={y} r="3" className="loading-dot"/><text x={x+dx} y={y-4+dy} textAnchor={anchor} className="loading-label"><title>{r.variable}</title>{String(r.variable).slice(0,18)}</text></g>})}</svg></div>; }
function GroupBoxplots({ groups, factor1, factor2 }: { groups:AnyObj[]; factor1:string; factor2?:string|null }) { if(!groups.length)return <div className="quiet-empty">Aucun groupe.</div>; const vals=groups.flatMap(g=>[g.boxplot?.min,g.boxplot?.max]).filter(Number.isFinite),min=Math.min(...vals),max=Math.max(...vals),span=Math.max(max-min,1e-9),chartW=Math.max(720,groups.length*86+110),left=55,right=chartW-30,y=(v:number)=>215-(v-min)/span*150,step=(right-left)/Math.max(groups.length,1); return <div className="svg-chart tall chart-scroll"><svg viewBox={`0 0 ${chartW} 295`} style={{minWidth:`${chartW}px`}}><line x1={left} y1="215" x2={right} y2="215" className="axis"/><line x1={left} y1="65" x2={left} y2="215" className="axis"/>{groups.map((g,i)=>{const x=left+step*i+step/2,b=g.boxplot,label=factor2?`${g[factor1]} · ${g[factor2]}`:String(g[factor1]);return <g key={i}><line x1={x} x2={x} y1={y(b.whisker_high)} y2={y(b.whisker_low)} className="box-whisker"/><rect x={x-16} y={y(b.q3)} width="32" height={Math.max(2,y(b.q1)-y(b.q3))} className="box-svg"/><line x1={x-16} x2={x+16} y1={y(b.median)} y2={y(b.median)} className="median-svg"/><text x={x} y="240" className="tick" transform={`rotate(28 ${x} 240)`}><title>{label}</title>{label.slice(0,18)}</text></g>})}<text x="58" y="58" className="tick ytick">{formatNumber(max,2)}</text><text x="58" y="212" className="tick ytick">{formatNumber(min,2)}</text></svg></div>; }


function StatisticalLab({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const cols=result?.profile?.columns??[]; const rows=Number(result?.profile?.rows??0); const nums=cols.filter(isNumeric); const meaningfulNums=nums.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows)); const groupCandidates=cols.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows)&&Number(c.unique??0)>=2&&Number(c.unique??0)<=30);
  const [value,setValue]=useState(''); const [group,setGroup]=useState(''); const [x,setX]=useState(''); const [y,setY]=useState('');
  const [test,setTest]=useState('welch_t'); const [advice,setAdvice]=useState<AnyObj|null>(null); const [testResult,setTestResult]=useState<AnyObj|null>(null);
  const [corrCols,setCorrCols]=useState<string[]>([]); const [corrMethod,setCorrMethod]=useState<'pearson'|'spearman'>('pearson'); const [corr,setCorr]=useState<AnyObj|null>(null); const [busy,setBusy]=useState('');
  useEffect(()=>{if(result){const m=meaningfulNums.length?meaningfulNums:nums;const g=groupCandidates.find((c:AnyObj)=>!isNumeric(c))??groupCandidates[0]??cols.find((c:AnyObj)=>c.name!==m[0]?.name);setValue(m[0]?.name??'');setGroup(g?.name??'');setX(m[0]?.name??nums[0]?.name??'');setY(m[1]?.name??nums.find((c:AnyObj)=>c.name!==m[0]?.name)?.name??'');setCorrCols(m.slice(0,Math.min(8,m.length)).map((c:AnyObj)=>c.name));setAdvice(null);setTestResult(null);setCorr(null);}},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Tests statistiques" text="Chargez un dataset pour accéder au moteur de tests et au Statistical Test Advisor."/>;
  async function advise(){setBusy('advice');setError('');try{const a=await getTestAdvice(result!.dataset.id,{value,group});setAdvice(a);setTest(a.recommended);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy('');}}
  async function runTest(){setBusy('test');setError('');try{let payload:AnyObj={test};if(['pearson','spearman','chi_square','fisher','paired_t','wilcoxon'].includes(test))payload={...payload,x,y,paired:['paired_t','wilcoxon'].includes(test)};else payload={...payload,value,group};setTestResult(await runStatisticalTest(result!.dataset.id,payload));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy('');}}
  async function runCorr(){setBusy('corr');setError('');try{setCorr(await runCorrelations(result!.dataset.id,{columns:corrCols,method:corrMethod}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy('');}}
  const testOptions=[['student_t','t de Student'],['welch_t','t de Welch'],['mann_whitney','Mann-Whitney'],['anova_oneway','ANOVA 1 facteur'],['kruskal_wallis','Kruskal-Wallis'],['pearson','Corrélation de Pearson'],['spearman','Corrélation de Spearman'],['chi_square','Chi-deux'],['fisher','Fisher exact 2×2'],['paired_t','t apparié'],['wilcoxon','Wilcoxon apparié']];
  const pairMode=['pearson','spearman','chi_square','fisher','paired_t','wilcoxon'].includes(test);
  return <div className="page"><div className="page-title"><div><span className="eyebrow">STATISTICAL ENGINE</span><h1>Tests statistiques & corrélations</h1><p>Choisissez des variables pertinentes, vérifiez les hypothèses puis visualisez l'effet observé — pas seulement la p-value.</p></div><span className="module-state implemented">implémenté</span></div>
    <div className="two-col compact-config-panels"><Panel title="Test conseillé"><div className="analysis-config"><div className="form-row"><label>Mesure numérique<select value={value} onChange={e=>setValue(e.target.value)}>{(meaningfulNums.length?meaningfulNums:nums).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Variable de groupe<select value={group} onChange={e=>setGroup(e.target.value)}>{groupCandidates.filter((c:AnyObj)=>c.name!==value).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label></div><RunButton busy={busy==='advice'} label="Recommander" busyLabel="Diagnostic…" onClick={advise}/>{advice&&<div className="advisor-box compact-advisor"><span>TEST RECOMMANDÉ</span><b>{advice.recommended}</b><p>{advice.reason}</p></div>}</div></Panel>
      <Panel title="Exécuter"><div className="analysis-config"><label>Test<select value={test} onChange={e=>setTest(e.target.value)}>{testOptions.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>{pairMode?<div className="form-row"><label>Variable X<select value={x} onChange={e=>setX(e.target.value)}>{cols.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows)||c.name===x).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Variable Y<select value={y} onChange={e=>setY(e.target.value)}>{cols.filter((c:AnyObj)=>c.name!==x&&(!isLikelyIdentifier(c,rows)||c.name===y)).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label></div>:<div className="form-row"><label>Mesure<select value={value} onChange={e=>setValue(e.target.value)}>{(meaningfulNums.length?meaningfulNums:nums).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Groupe<select value={group} onChange={e=>setGroup(e.target.value)}>{groupCandidates.filter((c:AnyObj)=>c.name!==value).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label></div>}<RunButton busy={busy==='test'} label="Exécuter le test" busyLabel="Calcul…" onClick={runTest}/></div></Panel></div>
    {testResult&&<><div className="metrics test-summary-metrics"><Stat label="Test" value={testResult.test}/><Stat label="Statistique" value={formatNumber(testResult.statistic,4)}/><Stat label="p-value" value={pText(testResult.p_value)}/><Stat label="Conclusion α=0,05" value={testResult.significant?'Significatif':'Non significatif'}/>{testResult.effect_size&&<Stat label={testResult.effect_size.name} value={formatNumber(testResult.effect_size.value,3)} detail={testResult.effect_size.magnitude??undefined}/>}</div>
      {(testResult.group_summary?.length||testResult.scatter_points?.length||testResult.contingency?.length)&&<div className="dashboard-grid test-visual-grid">{testResult.group_summary?.length>0&&<Panel title="Distribution par groupe"><GroupBoxplots groups={testResult.group_summary} factor1="group"/></Panel>}{testResult.scatter_points?.length>0&&<Panel title={testResult.variables?'Relation observée':'Paires observées'}><ScatterPlot points={testResult.scatter_points} xLabel={testResult.variables?.[0]??x} yLabel={testResult.variables?.[1]??y} diagonal={['paired_t','wilcoxon'].includes(testResult.test)}/></Panel>}{testResult.contingency?.length>0&&<Panel title="Table de contingence — intensité"><ContingencyHeatmap rows={testResult.contingency} columns={testResult.contingency_columns??Object.keys(testResult.contingency[0]??{}).filter((k:string)=>k!=='row')}/></Panel>}</div>}
      <Panel title="Diagnostics & valeurs"><div className="test-cards">{testResult.diagnostics?.levene&&<TestCard name="Levene" stat={testResult.diagnostics.levene.statistic} p={testResult.diagnostics.levene.p_value} goodWhenHigh/>}{(testResult.diagnostics?.normality??[]).map((n:AnyObj,i:number)=><TestCard key={i} name={`Shapiro — ${n.group}`} stat={n.statistic} p={n.p_value} goodWhenHigh/>)}{testResult.normality_difference&&<TestCard name="Shapiro — différences" stat={testResult.normality_difference.statistic} p={testResult.normality_difference.p_value} goodWhenHigh/>}</div>{testResult.contingency&&<details className="matrix-details"><summary>Voir la table numérique</summary><SimpleTable rows={testResult.contingency} columns={Object.keys(testResult.contingency[0]??{}).map(k=>[k,k] as [string,string])}/></details>}</Panel></>}
    <Panel title="Matrice de corrélation"><div className="analysis-config"><VariableChecklist columns={meaningfulNums.length?meaningfulNums:nums} selected={corrCols} setSelected={setCorrCols} numericOnly/><div className="form-row correlation-actions"><label>Méthode<select value={corrMethod} onChange={e=>setCorrMethod(e.target.value as 'pearson'|'spearman')}><option value="pearson">Pearson</option><option value="spearman">Spearman</option></select></label><RunButton busy={busy==='corr'} label="Calculer la matrice" busyLabel="Calcul…" onClick={runCorr}/></div></div>{corr&&<><CorrelationHeatmap matrix={corr.matrix} columns={corr.columns}/><details className="matrix-details"><summary>Voir la matrice numérique</summary><SimpleTable rows={corr.matrix} columns={['variable',...corr.columns].map(k=>[k,k] as [string,string])}/></details><h4 className="subheading">Relations les plus fortes</h4><SimpleTable rows={corr.pairs.slice(0,15)} columns={[["x","X"],["y","Y"],["coefficient","Coefficient"],["p_value","p-value"],["n","n"]]}/></>}</Panel>
  </div>;
}

function VisualizationStudio({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const cols=result?.profile?.columns??[];
  const displayCols=cols.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result?.profile?.rows??0)));
  const numericCols=(displayCols.length?displayCols:cols).filter((c:AnyObj)=>isNumeric(c));
  const [chartType,setChartType]=useState('auto'); const [x,setX]=useState(''); const [y,setY]=useState('');
  const [color,setColor]=useState(''); const [size,setSize]=useState(''); const [aggregation,setAggregation]=useState('none');
  const [viz,setViz]=useState<AnyObj|null>(null); const [recs,setRecs]=useState<AnyObj[]>([]); const [composition,setComposition]=useState<AnyObj|null>(null);
  const [instruction,setInstruction]=useState(''); const [editInfo,setEditInfo]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false); const [saved,setSaved]=useState('');
  useEffect(()=>{if(result){setX((displayCols[0]??cols[0])?.name??'');setY((displayCols[1]??cols[1])?.name??'');setColor('');setSize((numericCols[2]??numericCols[0])?.name??'');setViz(null);setComposition(null);setRecs([]);setEditInfo(null);}},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Visualization Studio" text="Chargez un dataset pour concevoir des visualisations interactives."/>;
  const selectable=displayCols.length?displayCols:cols;
  async function build(){setBusy(true);setError('');setSaved('');try{const payload:AnyObj={chart_type:chartType,x:x||null,y:y||null,color:color||null,size:size||null,aggregation,bins:20};if(['pca','cluster','heatmap'].includes(chartType))payload.columns=numericCols.slice(0,10).map((c:AnyObj)=>c.name);setViz(await buildVisualization(result!.dataset.id,payload));setComposition(null);setEditInfo(null);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function recommend(){setBusy(true);setError('');try{const r=await recommendVisualizations(result!.dataset.id,[x,y,color,size].filter(Boolean));setRecs(r.recommendations??[]);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function compose(){setBusy(true);setError('');try{setComposition(await composeVisualizations(result!.dataset.id,{columns:[x,y,color,size].filter(Boolean),intent:'overview',max_views:4}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function editCurrent(){if(!viz||!instruction.trim())return;setBusy(true);setError('');try{const r=await editVisualization(result!.dataset.id,viz,instruction.trim());setViz(r.visualization);setEditInfo(r);setInstruction('');}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function pin(){const current=viz;if(!current)return;setBusy(true);setError('');setSaved('');try{await saveVisualization(result!.dataset.id,current.title??'Visualisation DataVision',current);setSaved('Visualisation ajoutée aux rapports.');}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  function applyRec(r:AnyObj){setChartType(r.type);setX(r.x??x);setY(r.y??'');setColor(r.color??'');setSize(r.size??size);setAggregation(r.aggregation??'none');}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">VISUAL ANALYTICS · NL→VIZ</span><h1>Visualisation intelligente</h1><p>Recommandations scorées, nouveaux graphiques, composition multi-vues et édition conversationnelle d’un graphique existant.</p></div><span className="module-state implemented">v2.69</span></div>
    <div className="viz-layout"><Panel title="Configuration"><div className="analysis-config"><label>Type<select value={chartType} onChange={e=>setChartType(e.target.value)}><option value="auto">Auto</option><option value="histogram">Histogramme</option><option value="density">Densité</option><option value="scatter">Nuage de points</option><option value="bubble">Bulles</option><option value="box">Boxplot</option><option value="violin">Violin</option><option value="bar">Barres</option><option value="line">Courbe</option><option value="area">Aire</option><option value="heatmap">Heatmap corrélations</option><option value="treemap">Treemap</option><option value="sankey">Sankey</option><option value="map">Carte de points</option><option value="pca">Projection PCA</option><option value="cluster">Projection clusters</option></select></label><label>Axe X<select value={x} onChange={e=>setX(e.target.value)}>{selectable.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Axe Y<select value={y} onChange={e=>setY(e.target.value)}><option value="">— aucun —</option>{selectable.filter((c:AnyObj)=>c.name!==x).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Couleur / groupe<select value={color} onChange={e=>setColor(e.target.value)}><option value="">— aucune —</option>{selectable.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Taille / poids<select value={size} onChange={e=>setSize(e.target.value)}><option value="">— aucune —</option>{numericCols.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Agrégation<select value={aggregation} onChange={e=>setAggregation(e.target.value)}><option value="none">Automatique / aucune</option><option value="count">Count</option><option value="mean">Moyenne</option><option value="sum">Somme</option><option value="median">Médiane</option><option value="min">Minimum</option><option value="max">Maximum</option></select></label><div className="button-row"><RunButton busy={busy} label="Générer" busyLabel="Calcul…" onClick={build}/><button className="secondary-btn" disabled={busy} onClick={recommend}>✦ Recommander</button><button className="secondary-btn" disabled={busy} onClick={compose}>▦ Composer 4 vues</button></div></div></Panel>
      <Panel title="Smart Visualization"><div className="recommendation-list">{recs.length?recs.map((r,i)=><button key={i} onClick={()=>applyRec(r)}><div className="viz-rec-head"><b>{r.type}</b><em className={`viz-confidence ${r.confidence}`}>{r.score}/100 · {r.confidence}</em></div><span>{r.reason}</span><small>{[r.x,r.y,r.size].filter(Boolean).join(' × ')||'sélection automatique'}</small></button>):<div className="quiet-empty">Cliquez sur « Recommander » pour classer les graphiques selon le type, la cardinalité et la sémantique des variables.</div>}</div></Panel></div>
    {composition&&<Panel title={composition.title??'Composition analytique'} action={<span className="quiet">{composition.view_count} vues · {composition.layout}</span>}><div className="viz-composition-grid">{(composition.views??[]).map((v:AnyObj,i:number)=><article key={i} className="viz-composition-card"><header><div><b>{v.visualization?.title}</b><small>{v.reason}</small></div><span>{v.score}/100</span></header><VizRenderer viz={v.visualization}/></article>)}</div></Panel>}
    <Panel title={viz?.title??'Aperçu du graphique'} action={viz?<button className="secondary-btn" disabled={busy} onClick={pin}>＋ Ajouter au rapport</button>:undefined}>{!viz?<div className="viz-placeholder">Sélectionnez vos variables puis générez le graphique.</div>:<><VizRenderer viz={viz}/><div className="viz-conversation"><label>Modifier ce graphique en langage naturel<textarea value={instruction} onChange={e=>setInstruction(e.target.value)} placeholder={'Exemples : « transforme en violin », « moyenne par Région », « x=CA, y=Marge », « couleur=Segment », « titre=Performance régionale »'}/></label><button className="primary-btn" disabled={busy||!instruction.trim()} onClick={editCurrent}>✦ Appliquer la modification</button></div>{editInfo&&<div className="viz-edit-summary"><b>{editInfo.applied?'Modification appliquée':'Aucun changement détecté'}</b><span>{(editInfo.changes??[]).map((c:AnyObj)=>`${c.field}: ${c.from??'—'} → ${c.to??'—'}`).join(' · ')||'Le graphique a été reconstruit avec la configuration existante.'}</span></div>}{saved&&<div className="success-box compact-success">✓ {saved}</div>}</>}</Panel>
  </div>;
}

function BubblePlot({points,xLabel,yLabel}:{points:AnyObj[];xLabel:string;yLabel:string}) { const clean=(points??[]).filter(p=>Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y))); if(!clean.length)return <div className="quiet-empty">Aucun point.</div>; const xs=clean.map(p=>Number(p.x)),ys=clean.map(p=>Number(p.y)),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),sx=(v:number)=>45+(v-xmin)/Math.max(xmax-xmin,1e-9)*510,sy=(v:number)=>225-(v-ymin)/Math.max(ymax-ymin,1e-9)*170; return <div className="svg-chart"><svg viewBox="0 0 600 270" role="img"><line x1="45" y1="225" x2="555" y2="225" className="axis"/><line x1="45" y1="55" x2="45" y2="225" className="axis"/>{clean.map((p,i)=><circle key={i} cx={sx(Number(p.x))} cy={sy(Number(p.y))} r={Math.max(3,Math.min(18,Number(p.radius)||5))} className={`cluster-dot c${i%6}`}><title>{`${xLabel}: ${formatNumber(p.x)} · ${yLabel}: ${formatNumber(p.y)}${p.size!=null?` · taille: ${formatNumber(p.size)}`:''}`}</title></circle>)}<text x="300" y="260" className="axis-label">{xLabel}</text><text x="13" y="145" className="axis-label" transform="rotate(-90 13 145)">{yLabel}</text></svg></div>; }
function ViolinPlot({groups}:{groups:AnyObj[]}) { if(!groups?.length)return <div className="quiet-empty">Aucune distribution.</div>; const values=groups.flatMap(g=>(g.density??[]).map((d:AnyObj)=>Number(d.value))).filter(Number.isFinite); const min=Math.min(...values),max=Math.max(...values),sy=(v:number)=>225-(v-min)/Math.max(max-min,1e-9)*170; const width=540/Math.max(groups.length,1); return <div className="svg-chart tall"><svg viewBox="0 0 620 285">{groups.map((g:AnyObj,i:number)=>{const cx=50+width*(i+.5),pts=g.density??[];const left=pts.map((d:AnyObj)=>`${cx-Number(d.density)*Math.min(34,width*.35)},${sy(Number(d.value))}`);const right=[...pts].reverse().map((d:AnyObj)=>`${cx+Number(d.density)*Math.min(34,width*.35)},${sy(Number(d.value))}`);return <g key={i}><polygon points={[...left,...right].join(' ')} className="violin-shape"/><line x1={cx-10} x2={cx+10} y1={sy(Number(g.median))} y2={sy(Number(g.median))} className="median-svg"/><text x={cx} y="258" className="tick">{String(g.group).slice(0,14)}</text><title>{`${g.group} · n=${g.n}`}</title></g>})}<line x1="35" y1="225" x2="585" y2="225" className="axis"/></svg></div>; }
function TreeMapView({rows}:{rows:AnyObj[]}) { const clean=(rows??[]).filter(r=>Number(r.value)>0); const total=clean.reduce((a,r)=>a+Number(r.value),0)||1; return <div className="treemap-view">{clean.slice(0,30).map((r,i)=><div key={i} className={`treemap-cell t${i%6}`} style={{flexGrow:Math.max(.2,Number(r.value)/total*20),flexBasis:`${Math.max(12,Number(r.value)/total*100)}%`}}><b>{String(r.label)}</b><span>{formatNumber(r.value,2)}</span></div>)}</div>; }
function SankeyView({links}:{links:AnyObj[]}) { const clean=(links??[]).slice(0,30); if(!clean.length)return <div className="quiet-empty">Aucun flux.</div>; const sources=[...new Set(clean.map(x=>String(x.source)))].slice(0,12),targets=[...new Set(clean.map(x=>String(x.target)))].slice(0,12); const sy=(name:string,list:string[])=>45+list.indexOf(name)/Math.max(list.length-1,1)*170; const max=Math.max(...clean.map(x=>Number(x.value)||0),1); return <div className="svg-chart"><svg viewBox="0 0 620 270">{clean.filter(x=>sources.includes(String(x.source))&&targets.includes(String(x.target))).map((l,i)=><path key={i} d={`M 155 ${sy(String(l.source),sources)} C 300 ${sy(String(l.source),sources)}, 320 ${sy(String(l.target),targets)}, 465 ${sy(String(l.target),targets)}`} className="sankey-link" style={{strokeWidth:Math.max(1,Number(l.value)/max*12)}}><title>{`${l.source} → ${l.target}: ${formatNumber(l.value)}`}</title></path>)}{sources.map((n,i)=><text key={`s${i}`} x="145" y={sy(n,sources)+4} className="sankey-label source">{n.slice(0,18)}</text>)}{targets.map((n,i)=><text key={`t${i}`} x="475" y={sy(n,targets)+4} className="sankey-label target">{n.slice(0,18)}</text>)}</svg></div>; }
function GeoPointView({points}:{points:AnyObj[]}) { const clean=(points??[]).filter(p=>Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y))); if(!clean.length)return <div className="quiet-empty">Aucun point géographique.</div>; return <div className="geo-point-view"><div className="geo-note">Projection simplifiée des coordonnées · utilisez une couche cartographique dédiée pour une analyse géographique de précision.</div><BubblePlot points={clean.map(p=>({...p,radius:5}))} xLabel="Longitude" yLabel="Latitude"/></div>; }
function VizRenderer({viz}:{viz:AnyObj}) {
  if(viz.type==='histogram') return <Histogram bins={viz.data}/>;
  if(viz.type==='density') return <XYLineChart rows={viz.data} xKey="x" yKey="density" xLabel={viz.x} yLabel="Densité"/>;
  if(viz.type==='scatter') return <ScatterPlot points={viz.data} xLabel={viz.x} yLabel={viz.y}/>;
  if(viz.type==='bubble') return <BubblePlot points={viz.data} xLabel={viz.x} yLabel={viz.y}/>;
  if(viz.type==='map') return <GeoPointView points={viz.data}/>;
  if(viz.type==='box') return <GroupBoxplots groups={viz.data.map((d:AnyObj)=>({...d,boxplot:d,group:d.group}))} factor1="group"/>;
  if(viz.type==='violin') return <ViolinPlot groups={viz.data}/>;
  if(viz.type==='bar') return <BarChart rows={viz.data} valueKey="value" labelKey="label"/>;
  if(viz.type==='treemap') return <TreeMapView rows={viz.data}/>;
  if(viz.type==='sankey') return <SankeyView links={viz.data}/>;
  if(viz.type==='line'||viz.type==='area') return <CategoryLineChart rows={viz.data} area={viz.type==='area'} valueLabel={viz.value_label}/>;
  if(viz.type==='heatmap') return <CorrelationHeatmap matrix={viz.data} columns={viz.columns}/>;
  if(viz.type==='pca') return <><ScatterPlot points={viz.data} xLabel={`PC1 (${formatNumber(viz.explained_variance_pct?.[0],1)}%)`} yLabel={`PC2 (${formatNumber(viz.explained_variance_pct?.[1],1)}%)`}/><div className="viz-meta-line">Variables : {(viz.features??[]).join(', ')}</div></>;
  if(viz.type==='cluster') return <><ClusterScatter points={viz.data}/><div className="viz-meta-line">K={viz.k} · {(viz.features??[]).join(', ')}</div></>;
  return <pre className="result-json">{JSON.stringify(viz,null,2)}</pre>;
}

function SqlWorkspace({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const [sql,setSql]=useState('SELECT * FROM dataset LIMIT 25'); const [out,setOut]=useState<AnyObj|null>(null); const [info,setInfo]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false);
  const [nlq,setNlq]=useState('Quelle est la moyenne des variables numériques ?'); const [nlqOut,setNlqOut]=useState<AnyObj|null>(null); const [nlqBusy,setNlqBusy]=useState(false);
  useEffect(()=>{if(!result)return;setOut(null);setNlqOut(null);getEngineInfo(result.dataset.id).then(setInfo).catch(e=>setError(e instanceof Error?e.message:String(e)));},[result?.dataset?.id]);
  if(!result) return <EmptyState title="SQL Workspace" text="Chargez un dataset. Il sera exposé en lecture seule sous le nom de table dataset."/>;
  async function execute(){setBusy(true);setError('');try{setOut(await runSql(result!.dataset.id,sql,500));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function executeNlq(){if(!nlq.trim())return;setNlqBusy(true);setError('');try{const r=await runNaturalLanguageQuery(result!.dataset.id,nlq.trim(),200);setNlqOut(r);if(r.execution_mode==='sql'&&r.sql)setSql(r.sql);setOut(r.result);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setNlqBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">SQL · NLQ · SEMANTIC QUERY</span><h1>Query Workspace</h1><p>Interrogez le dataset en SQL ou posez une question métier. DataVision choisit automatiquement le moteur SQL ou sémantique multi-table selon le contexte.</p></div><span className="module-state implemented">NLQ gouverné</span></div>
    {info&&<div className="metrics"><Stat label="Moteur actif" value={info.preferred_engine}/><Stat label="DuckDB" value={info.engines.duckdb??'fallback'}/><Stat label="Polars" value={info.engines.polars??'fallback'}/><Stat label="Taille estimée" value={`${formatNumber(info.dataset.estimated_size_bytes/1024)} Ko`}/></div>}
    <Panel title="Question en langage naturel" action={<span className="read-only-chip">{nlqOut?.execution_mode==='semantic'?'TEXT → SEMANTIC':'TEXT → SQL'}</span>}><div className="nlq-row"><textarea className="nlq-input" value={nlq} onChange={e=>setNlq(e.target.value)} spellCheck={false}/><RunButton busy={nlqBusy} label="Comprendre & exécuter" busyLabel="Interprétation…" onClick={executeNlq}/></div>{nlqOut&&<div className="nlq-meta"><span>Confiance <b>{nlqOut.confidence}</b></span><span>Moteur <b>{nlqOut.execution_mode==='semantic'?'Semantic Query Engine':'SQL read-only'}</b></span><span>{nlqOut.reasoning}</span>{nlqOut.semantic_grounding&&<><small className="semantic-grounding-note">◈ {nlqOut.semantic_grounding.metric_label||nlqOut.semantic_grounding.metric_id}{nlqOut.semantic_grounding.metric_unit?` · ${nlqOut.semantic_grounding.metric_unit}`:''} · {(nlqOut.semantic_grounding.dimensions??[]).join(' › ')||'global'} · modèle v{nlqOut.semantic_grounding.model_version??'—'}{nlqOut.semantic_grounding.certified?' · certifiée':''}</small>{nlqOut.semantic_grounding.metric_definition&&<small>Définition : {nlqOut.semantic_grounding.metric_definition}</small>}<small>Résolution : {nlqOut.semantic_grounding.matched_term||'nom canonique'} · tables {(nlqOut.semantic_grounding.tables??[]).join(' → ')||'base'} · relations {(nlqOut.semantic_grounding.relationships??[]).join(', ')||'aucune'} · rôle {nlqOut.semantic_grounding.access?.role??'local'}</small>{nlqOut.sql_validation&&<small>✓ SQL/plan read-only validé · calcul déterministe</small>}</>}{(nlqOut.assumptions??[]).map((x:string)=><small key={x}>⚠ {x}</small>)}</div>}</Panel>
    <div className="sql-layout"><Panel title="Éditeur SQL" action={<span className="read-only-chip">READ ONLY</span>}><textarea className="sql-editor" value={sql} onChange={e=>setSql(e.target.value)} spellCheck={false}/><div className="button-row"><RunButton busy={busy} label="Exécuter" busyLabel="Exécution…" onClick={execute}/><small className="help-text">Table disponible : <code>dataset</code> · SELECT/CTE uniquement</small></div></Panel><Panel title="Schéma"><div className="schema-list">{result.profile.columns.map((c:AnyObj)=><div key={c.name}><b>{c.name}</b><span>{c.dtype}</span></div>)}</div></Panel></div>
    {out&&<Panel title="Résultats" action={<span className="quiet">{out.returned_rows} lignes · {formatNumber(out.elapsed_ms)} ms · {out.engine}</span>}><DataTable preview={{columns:out.columns,rows:out.rows,shown:out.returned_rows,total:out.returned_rows}}/>{out.truncated&&<div className="warning-box">Résultat tronqué à {out.limit} lignes.</div>}</Panel>}
  </div>;
}

function ModelView({ result, target, setTarget, algorithm, setAlgorithm, training, automlRunning, doTrain, doAutoML, model, setError }: { result: AnyObj | null; target: string; setTarget:(v:string)=>void; algorithm:string; setAlgorithm:(v:string)=>void; training:boolean; automlRunning:boolean; doTrain:()=>void; doAutoML:(c:{task:'auto'|'classification'|'regression'|'clustering'|'forecasting'|'anomaly_detection';features?:string[];primary_metric:string;cv_folds:number;tune:boolean;max_candidates:number;split_strategy?:'auto'|'random'|'temporal';time_column?:string|null;horizon?:number;backtest_windows?:number;contamination?:number;threshold?:number})=>void; model:AnyObj|null; setError:(s:string)=>void }) {
  const [task,setTask]=useState<'auto'|'classification'|'regression'|'clustering'|'forecasting'|'anomaly_detection'>('auto');
  const [metric,setMetric]=useState('auto');
  const [folds,setFolds]=useState(5);
  const [tune,setTune]=useState(true);
  const [maxCandidates,setMaxCandidates]=useState(7);
  const [engines,setEngines]=useState<AnyObj|null>(null);
  const [benchmarkOnly,setBenchmarkOnly]=useState<AnyObj|null>(null);
  const [benchmarkBusy,setBenchmarkBusy]=useState(false);
  const [clusterFeatures,setClusterFeatures]=useState<string[]>([]);
  const [experiments,setExperiments]=useState<AnyObj[]>([]);
  const [splitStrategy,setSplitStrategy]=useState<'auto'|'random'|'temporal'>('auto');
  const [timeColumn,setTimeColumn]=useState('');
  const [safetyAudit,setSafetyAudit]=useState<AnyObj|null>(null);
  const [safetyBusy,setSafetyBusy]=useState(false);
  const [forecastHorizon,setForecastHorizon]=useState(12);
  const [forecastBacktests,setForecastBacktests]=useState(4);
  const [contamination,setContamination]=useState(0.05);
  const [anomalyThreshold,setAnomalyThreshold]=useState(3.5);

  const numericColumns=(result?.profile?.columns??[]).filter((c:AnyObj)=>isNumeric(c)&&!isLikelyIdentifier(c,Number(result?.profile?.rows??0)));
  const temporalColumns=(result?.profile?.columns??[]).filter((c:AnyObj)=>/date|time|timestamp|datetime|annee|year|mois|month/i.test(String(c.name))||/date|time/i.test(String(c.dtype??c.type??'')));

  useEffect(()=>{
    getModelEngines().then(setEngines).catch(()=>setEngines(null));
    setBenchmarkOnly(null);
    if(result?.dataset?.id){
      getAutoMLExperiments(result.dataset.id).then((x:AnyObj)=>setExperiments(x.experiments??[])).catch(()=>setExperiments([]));
      const defaults=(result.profile?.columns??[]).filter((c:AnyObj)=>isNumeric(c)&&!isLikelyIdentifier(c,Number(result.profile?.rows??0))).slice(0,8).map((c:AnyObj)=>c.name);
      setClusterFeatures(defaults);
      const timeGuess=(result.profile?.columns??[]).find((c:AnyObj)=>/date|time|timestamp|datetime|annee|year|mois|month/i.test(String(c.name)))?.name??'';
      setTimeColumn(timeGuess);
      setSafetyAudit(null);
    } else { setExperiments([]); setSafetyAudit(null); setTimeColumn(''); }
  },[result?.dataset?.id]);

  useEffect(()=>{
    if(!result?.dataset?.id||!model?.experiment_id)return;
    getAutoMLExperiments(result.dataset.id).then((x:AnyObj)=>setExperiments(x.experiments??[])).catch(()=>{});
  },[model?.experiment_id]);

  useEffect(()=>{
    const allowed=task==='clustering'?['auto','silhouette','calinski_harabasz','davies_bouldin']:
      task==='forecasting'?['auto','rmse','mae','smape']:
      task==='anomaly_detection'?['auto','quality_score','stability','agreement']:
      ['auto','roc_auc','f1_weighted','balanced_accuracy','accuracy','rmse','mae','r2'];
    if(!allowed.includes(metric)) setMetric('auto');
  },[task]);

  if (!result) return <EmptyState title="Modélisation" text="Chargez un dataset avant de configurer un workflow AutoML."/>;

  const benchmark=model?.leaderboard??model?.benchmark??[];
  const importance=model?.feature_importance??[];
  const guardrails=model?.guardrails??[];
  const engineRows=Object.entries(engines?.engines??{}).map(([name,value]:[string,any])=>({name,...value}));
  const clustering=task==='clustering';
  const forecasting=task==='forecasting';
  const anomaly=task==='anomaly_detection';
  const unsupervised=clustering||anomaly;
  const metricOptions=clustering
    ? [['auto','Auto'],['silhouette','Silhouette'],['calinski_harabasz','Calinski-Harabasz'],['davies_bouldin','Davies-Bouldin']]
    : forecasting
      ? [['auto','Auto'],['rmse','RMSE'],['mae','MAE'],['smape','sMAPE']]
      : anomaly
        ? [['auto','Auto · score qualité'],['quality_score','Score qualité'],['stability','Stabilité'],['agreement','Accord inter-méthodes']]
        : [['auto','Auto'],['roc_auc','ROC-AUC'],['f1_weighted','F1 pondéré'],['balanced_accuracy','Balanced accuracy'],['accuracy','Accuracy'],['rmse','RMSE'],['mae','MAE'],['r2','R²']];

  function toggleClusterFeature(name:string){
    setClusterFeatures(prev=>prev.includes(name)?prev.filter(x=>x!==name):[...prev,name]);
  }

  async function runBenchmarkOnly(){
    if(!unsupervised&&!target)return;
    if(clustering&&clusterFeatures.length<2){setError('Sélectionnez au moins deux variables numériques pour le clustering.');return;}
    if(anomaly&&clusterFeatures.length<1){setError('Sélectionnez au moins une variable numérique pour la détection d’anomalies.');return;}
    if(forecasting&&!timeColumn){setError('Sélectionnez une colonne temporelle pour le forecasting.');return;}
    setBenchmarkBusy(true);setError('');
    try{
      setBenchmarkOnly(await runModelBenchmark(result!.dataset.id,{
        target:unsupervised?null:target,
        task,
        features:unsupervised?clusterFeatures:undefined,
        primary_metric:metric,
        cv_folds:folds,
        max_candidates:maxCandidates,
        split_strategy:(unsupervised||forecasting)?'auto':splitStrategy,
        time_column:forecasting?timeColumn:(!unsupervised&&splitStrategy!=='random'&&timeColumn?timeColumn:null),
        horizon:forecastHorizon, backtest_windows:forecastBacktests, contamination, threshold:anomalyThreshold,
      }));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBenchmarkBusy(false);}
  }

  async function auditSafety(){
    if(!unsupervised&&!target){setError('Sélectionnez une variable cible avant l’audit ML Safety.');return;}
    if(forecasting&&!timeColumn){setError('Sélectionnez une colonne temporelle pour le forecasting.');return;}
    if(clustering&&clusterFeatures.length<2){setError('Sélectionnez au moins deux variables numériques pour le clustering.');return;}
    if(anomaly&&clusterFeatures.length<1){setError('Sélectionnez au moins une variable numérique pour la détection d’anomalies.');return;}
    setSafetyBusy(true);setError('');
    try{
      setSafetyAudit(await runMLSafetyAudit(result!.dataset.id,{
        target:unsupervised?null:target,task,features:unsupervised?clusterFeatures:undefined,primary_metric:metric,
        split_strategy:(unsupervised||forecasting)?'auto':splitStrategy,time_column:forecasting?timeColumn:(!unsupervised&&splitStrategy!=='random'&&timeColumn?timeColumn:null),
      }));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setSafetyBusy(false);}
  }

  function launchAutoML(){
    if(clustering&&clusterFeatures.length<2){setError('Sélectionnez au moins deux variables numériques pour le clustering.');return;}
    if(anomaly&&clusterFeatures.length<1){setError('Sélectionnez au moins une variable numérique pour la détection d’anomalies.');return;}
    if(forecasting&&!timeColumn){setError('Sélectionnez une colonne temporelle pour le forecasting.');return;}
    void doAutoML({task,features:unsupervised?clusterFeatures:undefined,primary_metric:metric,cv_folds:folds,tune,max_candidates:maxCandidates,split_strategy:(unsupervised||forecasting)?'auto':splitStrategy,time_column:forecasting?timeColumn:(!unsupervised&&splitStrategy!=='random'&&timeColumn?timeColumn:null),horizon:forecastHorizon,backtest_windows:forecastBacktests,contamination,threshold:anomalyThreshold});
  }

  return <div className="page">
    <div className="page-title">
      <div><span className="eyebrow">MACHINE LEARNING · AUTOML · EXPERIMENTS</span><h1>Modélisation professionnelle</h1><p>Classification, régression, clustering, forecasting et anomalies dans un workflow AutoML unifié avec validation adaptée à chaque tâche.</p></div>
      <span className="module-state implemented">AutoML unifié v2.70</span>
    </div>

    <Panel title="Moteurs disponibles" action={<span className="quiet">détection runtime</span>}>
      <div className="engine-grid">{engineRows.map((engine:AnyObj)=><div key={engine.name} className={engine.available?'engine-card available':'engine-card unavailable'}><b>{engine.name}</b><span>{engine.engine}</span><small>{engine.available?'disponible':'non installé'}</small></div>)}</div>
    </Panel>

    <div className="two-col model-layout">
      <Panel title="AutoML gouverné">
        <div className="stack-form">
          <label>Tâche<select value={task} onChange={e=>setTask(e.target.value as 'auto'|'classification'|'regression'|'clustering'|'forecasting'|'anomaly_detection')}><option value="auto">Auto — classification/régression</option><option value="classification">Classification</option><option value="regression">Régression</option><option value="clustering">Clustering non supervisé</option><option value="forecasting">Forecasting temporel</option><option value="anomaly_detection">Détection d’anomalies</option></select></label>
          {!unsupervised&&<label>Variable cible<select value={target} onChange={e=>setTarget(e.target.value)}>{result.profile.columns.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result.profile.rows??0))).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}
          {unsupervised&&<div className="automl-feature-picker"><b>{clustering?'Variables de clustering':'Variables à surveiller'}</b><small>Variables numériques uniquement. Les identifiants probables sont exclus.</small><div>{numericColumns.map((c:AnyObj)=><label key={c.name}><input type="checkbox" checked={clusterFeatures.includes(c.name)} onChange={()=>toggleClusterFeature(c.name)}/><span>{c.name}</span></label>)}</div></div>}
          <div className="form-row">
            <label>Métrique principale<select value={metric} onChange={e=>setMetric(e.target.value)}>{metricOptions.map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></label>
            {!unsupervised&&!forecasting&&<label>CV<input type="number" min={2} max={10} value={folds} onChange={e=>setFolds(Number(e.target.value))}/></label>}
            <label>Candidats<input type="number" min={2} max={24} value={maxCandidates} onChange={e=>setMaxCandidates(Number(e.target.value))}/></label>
          </div>
          {!unsupervised&&!forecasting&&<div className="form-row"><label>Split<select value={splitStrategy} onChange={e=>{setSplitStrategy(e.target.value as 'auto'|'random'|'temporal');setSafetyAudit(null);}}><option value="auto">Auto · temporel si détecté</option><option value="random">Aléatoire stratifié</option><option value="temporal">Chronologique obligatoire</option></select></label><label>Colonne temporelle<select value={timeColumn} onChange={e=>{setTimeColumn(e.target.value);setSafetyAudit(null);}} disabled={splitStrategy==='random'}><option value="">Détection automatique</option>{temporalColumns.map((c:AnyObj)=><option key={c.name} value={c.name}>{c.name}</option>)}</select></label></div>}
          {forecasting&&<div className="form-row"><label>Colonne temporelle<select value={timeColumn} onChange={e=>setTimeColumn(e.target.value)}><option value="">Sélectionner…</option>{temporalColumns.map((c:AnyObj)=><option key={c.name} value={c.name}>{c.name}</option>)}</select></label><label>Horizon<input type="number" min={1} max={365} value={forecastHorizon} onChange={e=>setForecastHorizon(Number(e.target.value))}/></label><label>Backtests<input type="number" min={1} max={8} value={forecastBacktests} onChange={e=>setForecastBacktests(Number(e.target.value))}/></label></div>}
          {anomaly&&<div className="form-row"><label>Contamination<input type="number" min={0.001} max={0.4} step={0.01} value={contamination} onChange={e=>setContamination(Number(e.target.value))}/></label><label>Seuil robuste<input type="number" min={1} max={10} step={0.1} value={anomalyThreshold} onChange={e=>setAnomalyThreshold(Number(e.target.value))}/></label></div>}
          {!unsupervised&&!forecasting&&<label className="switch-line"><input type="checkbox" checked={tune} onChange={e=>setTune(e.target.checked)}/> Optimisation contrôlée des hyperparamètres</label>}
          <div className="button-row"><button className="secondary-btn real-button" disabled={safetyBusy} onClick={()=>void auditSafety()}>{safetyBusy?'Audit…':'🛡 Auditer ML Safety'}</button><button className="primary-btn real-button" disabled={automlRunning||safetyAudit?.status==='blocked'} onClick={launchAutoML}>{automlRunning?'AutoML en cours…':'▶ Lancer AutoML'}</button><button className="secondary-btn real-button" disabled={benchmarkBusy} onClick={()=>void runBenchmarkOnly()}>{benchmarkBusy?'Benchmark…':'Comparer sans entraîner'}</button></div>
          <small className="help-text">{clustering?'Le clustering est sélectionné sur métriques internes ; aucune cible supervisée n’est utilisée.':forecasting?'Le forecasting est classé uniquement sur backtests rolling-origin chronologiques.':anomaly?'Les détecteurs sont classés sans vérité terrain, selon stabilité, accord inter-méthodes et plausibilité du taux.':'Le jeu de test final reste isolé jusqu’à l’évaluation du modèle sélectionné.'}</small>
        </div>
      </Panel>

      <Panel title="Entraînement manuel supervisé">
        <div className="stack-form">
          <label>Algorithme<select value={algorithm} onChange={e=>setAlgorithm(e.target.value)}><option value="auto">Auto baseline</option><option value="linear_regression">Régression linéaire</option><option value="ridge">Ridge</option><option value="logistic_regression">Régression logistique</option><option value="random_forest">Random Forest</option><option value="extra_trees">Extra Trees</option><option value="gradient_boosting">Gradient Boosting</option><option value="hist_gradient_boosting">Histogram Gradient Boosting</option><option value="svm">SVM</option><option value="xgboost">XGBoost</option><option value="lightgbm">LightGBM</option><option value="catboost">CatBoost</option></select></label>
          <button className="secondary-btn real-button" disabled={training||clustering||forecasting||anomaly} onClick={doTrain}>{training?'Entraînement…':'Entraîner un modèle précis'}</button>
          <ul className="guardrails compact"><li>✓ Imputation + encodage dans le pipeline</li><li>✓ Split reproductible 60/20/20</li><li>✓ Test final non utilisé pour l’optimisation</li><li>✓ Model Card + provenance</li></ul>
        </div>
      </Panel>
    </div>

    {safetyAudit&&<Panel title="ML Safety · pré-entraînement" action={<span className={`module-state ${safetyAudit.status==='blocked'?'planned':safetyAudit.status==='warn'?'partial':'implemented'}`}>{String(safetyAudit.status).toUpperCase()}</span>}><div className="metrics six"><Stat label="Split" value={safetyAudit.split_policy?.strategy??'—'}/><Stat label="Temps" value={safetyAudit.split_policy?.time_column??'—'}/><Stat label="Métrique effective" value={safetyAudit.metric_policy?.effective??'—'}/><Stat label="Features sûres" value={(safetyAudit.usable_features??[]).length}/><Stat label="Exclues" value={(safetyAudit.excluded_features??[]).length}/><Stat label="Blocages" value={safetyAudit.blocking_findings??0}/></div><div className="ml-guardrail-list">{(safetyAudit.findings??[]).map((g:AnyObj,i:number)=><div key={i} className={`ml-guardrail ${g.severity}`}><b>{g.code}</b><span>{g.message}</span>{g.column&&<small>{g.column}</small>}{g.columns&&<small>{JSON.stringify(g.columns)}</small>}</div>)}</div>{(safetyAudit.excluded_features??[]).length>0&&<div className="validation-line"><b>Exclusions automatiques :</b><span>{(safetyAudit.excluded_features??[]).map((x:AnyObj)=>`${x.column} (${x.reason})`).join(' · ')}</span></div>}</Panel>}

    {benchmarkOnly&&<Panel title="Benchmark indépendant" action={<span className="quiet">{benchmarkOnly.primary_metric} · {benchmarkOnly.metric_direction??`${benchmarkOnly.cv_folds} folds`}</span>}>
      <div className="two-col compact-panels"><div><h4 className="subheading first">Classement validation</h4><BarChart rows={(benchmarkOnly.leaderboard??benchmarkOnly.benchmark??[]).filter((x:AnyObj)=>x.status==='ok')} valueKey="validation_score" labelKey="label"/></div>{!clustering&&<div><h4 className="subheading first">Cross-validation</h4><BarChart rows={(benchmarkOnly.benchmark??[]).filter((x:AnyObj)=>x.status==='ok'&&x.cv_mean!=null)} valueKey="cv_mean" labelKey="label"/></div>}</div>
      <SimpleTable rows={benchmarkOnly.leaderboard??benchmarkOnly.benchmark??[]} columns={clustering?[["rank","Rang"],["label","Partition"],["validation_score","Score"],["k","Clusters"],["status","Statut"],["error","Erreur"]]:[["rank","Rang"],["label","Modèle"],["engine","Moteur"],["status","Statut"],["validation_score","Validation"],["cv_mean","CV moyenne"],["cv_std","CV σ"],["error","Erreur"]]}/>
    </Panel>}

    {model&&<>
      <div className="metrics six"><Stat label="Tâche" value={model.task}/><Stat label="Algorithme retenu" value={model.algorithm}/><Stat label="Train" value={model.rows_train}/><Stat label="Validation" value={model.rows_validation??'—'}/><Stat label={['clustering','forecasting','anomaly_detection'].includes(model.task)?'Test supervisé':'Test final'} value={model.rows_test}/><Stat label="Métrique" value={model.primary_metric??model.model_card?.primary_metric??'auto'}/></div>
      <Panel title={model.task==='clustering'?'Métriques internes de clustering':model.task==='forecasting'?'Métriques rolling-origin':model.task==='anomaly_detection'?'Robustesse des détecteurs':'Métriques — test final'} action={<code>{model.experiment_id?.slice(0,8)??model.model_id?.slice(0,8)}…</code>}><div className="metric-results">{Object.entries(model.metrics??{}).map(([k,v])=><span key={k}><small>{k}</small><b>{formatNumber(v)}</b></span>)}</div>{model.selection_rationale&&<div className="validation-line"><b>Sélection :</b><span>{model.selection_rationale}</span></div>}</Panel>
      {benchmark.length>0&&<Panel title="Leaderboard AutoML"><SimpleTable rows={benchmark} columns={model.task==='clustering'?[["rank","Rang"],["label","Candidat"],["validation_score","Score"],["k","k"],["status","Statut"]]:model.task==='forecasting'?[["rank","Rang"],["label","Méthode"],["validation_score","Score"],["rmse","RMSE"],["mae","MAE"],["smape","sMAPE"]]:model.task==='anomaly_detection'?[["rank","Rang"],["label","Méthode"],["validation_score","Score"],["stability","Stabilité"],["agreement","Accord"],["anomaly_rate_pct","Taux %"]]:[["rank","Rang"],["label","Modèle"],["validation_score","Validation"],["cv_mean","CV moyenne"],["cv_std","CV σ"]]}/></Panel>}
      {model.task==='clustering'&&model.cluster_profiles?.length>0&&<Panel title="Profils des clusters"><SimpleTable rows={model.cluster_profiles} columns={Object.keys(model.cluster_profiles[0]).map(k=>[k,k])}/></Panel>}
      <div className="two-col"><Panel title="Garde-fous ML">{guardrails.length?<div className="ml-guardrail-list">{guardrails.map((g:AnyObj,i:number)=><div key={i} className={`ml-guardrail ${g.severity}`}><b>{g.code}</b><span>{g.message}</span>{g.columns&&<small>{JSON.stringify(g.columns)}</small>}</div>)}</div>:<div className="quiet-empty">Aucun diagnostic disponible.</div>}</Panel><Panel title="Importance / structure">{importance.length?<BarChart rows={importance.slice(0,12).map((x:AnyObj)=>({...x,importance_abs:Math.abs(Number(x.importance)||0)}))} valueKey="importance_abs" labelKey="feature"/>:<div className="quiet-empty">{model.task==='clustering'?'Les profils de clusters remplacent l’importance supervisée pour ce modèle.':'Importance indisponible pour ce modèle.'}</div>}</Panel></div>
      {model.best_params&&Object.keys(model.best_params).length>0&&<Panel title="Hyperparamètres retenus"><pre className="result-json">{JSON.stringify(model.best_params,null,2)}</pre></Panel>}
      {model.model_card&&<Panel title="Model Card"><div className="model-card-grid"><div><span>Cible</span><b>{model.model_card.target??'Non supervisé'}</b></div><div><span>Dataset</span><b>{model.model_card.dataset?.name??'—'} · v{model.model_card.dataset?.version??'—'}</b></div><div><span>Validation</span><b>{model.model_card.validation_strategy?.strategy??model.model_card.validation_strategy?.split}</b></div><div><span>Test final isolé</span><b>{model.split_audit?.final_test_isolated===false?'NON':'OUI'}</b></div><div><span>Surapprentissage</span><b>{model.overfitting_assessment?.status??'—'} · {model.overfitting_assessment?.gap??'—'}</b></div><div><span>Créé</span><b>{new Date(model.model_card.created_at).toLocaleString('fr-FR')}</b></div></div><div className="limitation-box"><b>Limites connues</b><ul>{(model.model_card.known_limitations??[]).map((x:string)=><li key={x}>{x}</li>)}</ul></div><code className="model-id">Model ID: {model.model_id}</code></Panel>}
    </>}

    <Panel title="Historique des expériences AutoML" action={<span className="quiet">{experiments.length} expérience(s)</span>}>
      {experiments.length?<SimpleTable rows={experiments.slice(0,20).map((x:AnyObj)=>({experiment_id:String(x.experiment_id??'').slice(0,8),created_at:x.created_at,task:x.task,target:x.target??'—',primary_metric:x.primary_metric,selected:x.selected?.algorithm??'—',status:x.status}))} columns={[["experiment_id","Expérience"],["created_at","Créée"],["task","Tâche"],["target","Cible"],["primary_metric","Métrique"],["selected","Sélection"],["status","Statut"]]}/>:<div className="quiet-empty">Aucune expérience AutoML enregistrée pour ce dataset.</div>}
    </Panel>
  </div>;
}

function PredictView({ model, text, setText, predicting, doPredict, prediction }: { model:AnyObj|null; text:string; setText:(v:string)=>void; predicting:boolean; doPredict:()=>void; prediction:AnyObj|null }) { if(!model)return <EmptyState title="Prédictions" text="Entraînez d’abord un modèle dans l’onglet Modélisation."/>; return <div className="page"><div className="page-title"><div><span className="eyebrow">INFERENCE</span><h1>Prédictions</h1><p>Soumettez de nouvelles observations au pipeline entraîné.</p></div></div><Panel title="Observations à prédire" action={<code>{model.model_id.slice(0,8)}…</code>}><textarea className="json-editor" value={text} onChange={e=>setText(e.target.value)} spellCheck={false}/><button className="primary-btn real-button" disabled={predicting} onClick={doPredict}>{predicting?'Prédiction…':'▶ Lancer la prédiction'}</button></Panel>{prediction&&<Panel title="Résultat"><pre className="result-json">{JSON.stringify(prediction,null,2)}</pre></Panel>}</div>; }

function ForecastView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const cols=result?.profile?.columns??[]; const allNumeric=cols.filter(isNumeric); const numeric=allNumeric.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result?.profile?.rows??0)));
  const [dateColumn,setDateColumn]=useState(''); const [targetCol,setTargetCol]=useState(''); const [horizon,setHorizon]=useState(12); const [frequency,setFrequency]=useState('auto'); const [method,setMethod]=useState('auto'); const [backtestWindows,setBacktestWindows]=useState(3); const [intervalLevel,setIntervalLevel]=useState(0.95); const [missingStrategy,setMissingStrategy]=useState<'none'|'interpolate'|'ffill'|'zero'>('none'); const [selectionMetric,setSelectionMetric]=useState<'rmse'|'mae'|'smape'>('rmse'); const [out,setOut]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false);
  useEffect(()=>{if(!result)return; const dateGuess=cols.find((c:AnyObj)=>/date|time|timestamp|annee|year|mois|month/i.test(c.name))?.name??cols[0]?.name??''; setDateColumn(dateGuess);setTargetCol(numeric[0]?.name??'');setOut(null);},[result?.dataset?.id]);
  if(!result) return <EmptyState title="Forecasting" text="Chargez une série temporelle pour comparer plusieurs méthodes et produire une prévision."/>;
  async function run(){if(!dateColumn||!targetCol)return;setBusy(true);setError('');try{setOut(await runForecast(result!.dataset.id,{date_column:dateColumn,target:targetCol,horizon,frequency,method,backtest_windows:backtestWindows,interval_level:intervalLevel,missing_strategy:missingStrategy,selection_metric:selectionMetric}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">TIME SERIES · ROLLING-ORIGIN</span><h1>Forecasting</h1><p>Benchmark chronologique multi-fenêtres, diagnostics de série et intervalles empiriques fondés sur les erreurs réellement observées hors-échantillon.</p></div><span className="module-state implemented">implémenté</span></div>
    <Panel title="Configuration"><div className="analysis-config"><div className="form-row"><label>Date<select value={dateColumn} onChange={e=>setDateColumn(e.target.value)}>{cols.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Variable cible<select value={targetCol} onChange={e=>setTargetCol(e.target.value)}>{numeric.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label><label>Horizon<input type="number" min={1} max={365} value={horizon} onChange={e=>setHorizon(Number(e.target.value))}/></label><label>Backtests<input type="number" min={1} max={8} value={backtestWindows} onChange={e=>setBacktestWindows(Number(e.target.value))}/></label></div><div className="form-row"><label>Fréquence<select value={frequency} onChange={e=>setFrequency(e.target.value)}><option value="auto">Auto</option><option value="daily">Quotidienne</option><option value="weekly">Hebdomadaire</option><option value="monthly">Mensuelle</option><option value="quarterly">Trimestrielle</option><option value="yearly">Annuelle</option></select></label><label>Moteur<select value={method} onChange={e=>setMethod(e.target.value)}><option value="auto">Auto</option><option value="naive">Naïf</option><option value="seasonal_naive">Naïf saisonnier</option><option value="linear_trend">Tendance linéaire</option><option value="exponential_smoothing">Lissage exponentiel</option></select></label><label>Métrique de sélection<select value={selectionMetric} onChange={e=>setSelectionMetric(e.target.value as 'rmse'|'mae'|'smape')}><option value="rmse">RMSE</option><option value="mae">MAE</option><option value="smape">sMAPE</option></select></label><label>Intervalle<select value={intervalLevel} onChange={e=>setIntervalLevel(Number(e.target.value))}><option value={0.8}>80 %</option><option value={0.9}>90 %</option><option value={0.95}>95 %</option><option value={0.99}>99 %</option></select></label></div><div className="form-row"><label>Périodes manquantes<select value={missingStrategy} onChange={e=>setMissingStrategy(e.target.value as 'none'|'interpolate'|'ffill'|'zero')}><option value="none">Bloquer et demander une stratégie</option><option value="interpolate">Interpolation</option><option value="ffill">Propagation dernière valeur</option><option value="zero">Remplir par zéro</option></select></label><RunButton busy={busy} label="Prévoir" busyLabel="Calcul…" onClick={run}/></div></div></Panel>
    {out&&<><div className="metrics six"><Stat label="Méthode retenue" value={out.method}/><Stat label="Fréquence" value={out.frequency}/><Stat label="Backtests" value={out.backtest?.windows??'—'}/><Stat label="Métrique" value={String(out.selection_metric??'rmse').toUpperCase()}/><Stat label="Validation" value={`${out.validation_periods} périodes`}/><Stat label="Horizon" value={`${out.horizon} périodes`}/></div><Panel title="Historique & prévision" action={<span className="quiet">IC {Math.round(Number(out.prediction_interval?.level??0.95)*100)} %</span>}><ForecastChart history={out.history} forecast={out.forecast}/></Panel><div className="two-col"><Panel title="Benchmark rolling-origin"><BarChart rows={out.benchmark.filter((x:AnyObj)=>x.status==='ok')} valueKey={out.selection_metric??'rmse'} labelKey="method"/><SimpleTable rows={out.benchmark.filter((x:AnyObj)=>x.status==='ok')} columns={[["rank","Rang"],["method","Méthode"],["backtest_windows","Fenêtres"],["mae","MAE"],["rmse","RMSE"],["smape","sMAPE %"],["bias","Biais"]]}/></Panel><Panel title="Diagnostics temporels"><div className="metric-results"><span><small>Périodes manquantes</small><b>{out.series_diagnostics?.missing_periods??0}</b></span><span><small>Doublons agrégés</small><b>{out.series_diagnostics?.duplicates_aggregated??0}</b></span><span><small>R² tendance</small><b>{formatNumber(out.series_diagnostics?.trend_r2)}</b></span><span><small>Autocorr. saisonnière</small><b>{formatNumber(out.series_diagnostics?.seasonal_autocorrelation)}</b></span><span><small>Biais résiduel</small><b>{formatNumber(out.residual_diagnostics?.mean_error)}</b></span><span><small>Autocorr. résiduelle lag 1</small><b>{formatNumber(out.residual_diagnostics?.lag1_autocorrelation)}</b></span></div>{out.selection_rationale&&<div className="validation-line"><b>Sélection :</b><span>{out.selection_rationale}</span></div>}</Panel></div>{(out.warnings??[]).length>0&&<Panel title="Limites & avertissements"><ul className="limitation-list">{out.warnings.map((w:string)=><li key={w}>{w}</li>)}</ul></Panel>}<Panel title="Prévisions"><SimpleTable rows={out.forecast} columns={[["date","Date"],["prediction","Prévision"],["lower","Borne basse"],["upper","Borne haute"]]}/></Panel></>}
  </div>;
}

function ForecastChart({history,forecast}:{history:AnyObj[];forecast:AnyObj[]}) {
  const hist=history??[], fut=forecast??[]; const all=[...hist.map(x=>Number(x.value)),...fut.map(x=>Number(x.prediction)),...fut.map(x=>Number(x.lower??x.lower_95)),...fut.map(x=>Number(x.upper??x.upper_95))].filter(Number.isFinite); if(!all.length)return <div className="quiet-empty">Aucune donnée à tracer.</div>; const min=Math.min(...all),max=Math.max(...all),span=Math.max(1e-9,max-min); const total=Math.max(2,hist.length+fut.length); const x=(i:number)=>35+i/(total-1)*760; const y=(v:number)=>235-(v-min)/span*195; const hp=hist.map((r,i)=>`${x(i)},${y(Number(r.value))}`).join(' '); const fp=fut.map((r,i)=>`${x(hist.length+i)},${y(Number(r.prediction))}`).join(' '); const upper=fut.map((r,i)=>`${x(hist.length+i)},${y(Number(r.upper??r.upper_95))}`).join(' '); const lower=[...fut].reverse().map((r,rev)=>`${x(hist.length+fut.length-1-rev)},${y(Number(r.lower??r.lower_95))}`).join(' ');
  return <svg viewBox="0 0 830 260" className="forecast-chart"><line x1="35" y1="235" x2="800" y2="235" className="chart-axis"/><line x1="35" y1="40" x2="35" y2="235" className="chart-axis"/><polygon points={`${upper} ${lower}`} className="forecast-band"/>{hp&&<polyline points={hp} className="history-line" fill="none"/>}{fp&&<polyline points={fp} className="forecast-line" fill="none"/>}<text x="38" y="30" className="chart-label">{formatNumber(max)}</text><text x="38" y="252" className="chart-label">{formatNumber(min)}</text><text x="650" y="28" className="chart-label">Prévision + IC 95%</text></svg>;
}

function AnomalyView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const allNumeric=(result?.profile?.columns??[]).filter(isNumeric); const numeric=allNumeric.filter((c:AnyObj)=>!isLikelyIdentifier(c,Number(result?.profile?.rows??0))); const [selected,setSelected]=useState<string[]>([]); const [method,setMethod]=useState<'auto'|'iqr'|'robust_z'|'isolation_forest'|'consensus'>('auto'); const [contamination,setContamination]=useState(0.05); const [threshold,setThreshold]=useState(3.5); const [out,setOut]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false);
  useEffect(()=>{if(result){setSelected(numeric.slice(0,Math.min(3,numeric.length)).map((c:AnyObj)=>c.name));setOut(null);}},[result?.dataset?.id]);
  if(!result)return <EmptyState title="Détection d’anomalies" text="Chargez un dataset contenant des variables numériques."/>;
  async function run(){setBusy(true);setError('');try{setOut(await runAnomalyDetection(result!.dataset.id,{columns:selected,method,contamination,threshold}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  return <div className="page"><div className="page-title"><div><span className="eyebrow">ANOMALY DETECTION · MULTI-METHOD</span><h1>Anomalies</h1><p>IQR, z-score robuste, Isolation Forest ou consensus 2-sur-3. Les observations originales ne sont jamais modifiées.</p></div><span className="module-state implemented">implémenté</span></div><div className="two-col"><Panel title="Variables"><div className="check-grid">{numeric.map((c:AnyObj)=><label key={c.name}><input type="checkbox" checked={selected.includes(c.name)} onChange={e=>setSelected(e.target.checked?[...selected,c.name]:selected.filter(x=>x!==c.name))}/>{c.name}</label>)}</div></Panel><Panel title="Méthode"><div className="stack-form"><label>Moteur<select value={method} onChange={e=>setMethod(e.target.value as 'auto'|'iqr'|'robust_z'|'isolation_forest'|'consensus')}><option value="auto">Auto</option><option value="consensus">Consensus multi-méthodes</option><option value="iqr">IQR</option><option value="robust_z">Z-score robuste</option><option value="isolation_forest">Isolation Forest</option></select></label><label>Contamination Isolation Forest<input type="number" min={0.001} max={0.4} step={0.01} value={contamination} onChange={e=>setContamination(Number(e.target.value))}/></label><label>Seuil z-score robuste<input type="number" min={1} max={10} step={0.1} value={threshold} onChange={e=>setThreshold(Number(e.target.value))}/></label><RunButton busy={busy} label="Détecter" busyLabel="Analyse…" onClick={run}/></div></Panel></div>{out&&<><div className="metrics"><Stat label="Méthode" value={out.method}/><Stat label="Observations" value={out.rows}/><Stat label="Anomalies" value={out.anomalies_count}/><Stat label="Taux" value={`${formatNumber(out.anomaly_rate_pct)} %`}/></div>{out.method_summary?.length>1&&<Panel title="Accord entre méthodes"><SimpleTable rows={out.method_summary} columns={[["method","Méthode"],["anomalies_count","Anomalies"],["anomaly_rate_pct","Taux %"],["max_score","Score max"]]}/>{out.agreement&&<div className="validation-line"><b>Consensus :</b><span>{out.agreement.rows_with_3_votes} ligne(s) avec 3 votes · {out.agreement.rows_with_2_votes} avec 2 votes · seuil = {out.agreement.required_votes}/{out.agreement.methods}</span></div>}</Panel>}{out.anomalies?.length>0&&<Panel title="Scores d’anomalie — top 20"><BarChart rows={out.anomalies.slice(0,20).map((a:AnyObj)=>({label:`#${a.index}`,score:Math.abs(Number(a.score)||0)}))} valueKey="score" labelKey="label"/></Panel>}<Panel title="Anomalies les plus importantes"><SimpleTable rows={out.anomalies.slice(0,100).map((a:AnyObj)=>({index:a.index,score:a.score,votes:a.votes??'—',reasons:(a.reasons??[]).join('; '),values:JSON.stringify(a.values)}))} columns={[["index","Index"],["score","Score"],["votes","Votes"],["reasons","Raison"],["values","Valeurs"]]}/></Panel>{(out.warnings??[]).length>0&&<Panel title="Interprétation"><ul className="limitation-list">{out.warnings.map((w:string)=><li key={w}>{w}</li>)}</ul></Panel>}</>}</div>;
}

function XaiView({ result, model, setError }: { result:AnyObj|null; model:AnyObj|null; setError:(s:string)=>void }) {
  const [diag,setDiag]=useState<AnyObj|null>(null);
  const [local,setLocal]=useState<AnyObj|null>(null);
  const [rowText,setRowText]=useState('{}');
  const [busy,setBusy]=useState(false);
  const [explaining,setExplaining]=useState(false);
  const [caps,setCaps]=useState<AnyObj|null>(null);
  const [shap,setShap]=useState<AnyObj|null>(null);
  const [pdp,setPdp]=useState<AnyObj|null>(null);
  const [cf,setCf]=useState<AnyObj|null>(null);
  const [xaiBusy,setXaiBusy]=useState('');
  const [pdpFeatures,setPdpFeatures]=useState<string[]>([]);
  const [desiredValue,setDesiredValue]=useState('');
  const [xaiAudit,setXaiAudit]=useState<AnyObj|null>(null);
  const [immutableText,setImmutableText]=useState('');

  useEffect(()=>{
    setDiag(null);setLocal(null);setShap(null);setPdp(null);setCf(null);setXaiAudit(null);
    if(model&&result){
      const features=model.model_card?.features??model.features??[];
      const source=result.preview?.rows?.[0]??{};
      const row:AnyObj={};
      for(const f of features){if(f in source)row[f]=source[f];}
      setRowText(JSON.stringify(row,null,2));
      setPdpFeatures(features.slice(0,Math.min(3,features.length)));
      getModelXAICapabilities(model.model_id).then(setCaps).catch(()=>setCaps(null));
    }
  },[model?.model_id,result?.dataset?.id]);

  if(!model)return <EmptyState title="Explicabilité XAI" text="Entraînez d’abord un modèle dans l’onglet Modélisation."/>;
  const activeModel=model;
  const features=activeModel.model_card?.features??activeModel.features??[];

  async function load(){setBusy(true);setError('');try{setDiag(await getModelDiagnostics(activeModel.model_id));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function explain(){setExplaining(true);setError('');try{setLocal(await explainModelPrediction(activeModel.model_id,JSON.parse(rowText)));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setExplaining(false);}}
  async function runShap(){setXaiBusy('shap');setError('');try{setShap(await runModelSHAP(activeModel.model_id,{row:JSON.parse(rowText),max_rows:50}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setXaiBusy('');}}
  async function runAudit(){setXaiBusy('audit');setError('');try{const row=JSON.parse(rowText) as Record<string,unknown>;setXaiAudit(await runModelXAIAudit(activeModel.model_id,{row,pdp_features:pdpFeatures,include_shap:false,persist:true}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setXaiBusy('');}}
  async function runPdp(){if(!pdpFeatures.length)return;setXaiBusy('pdp');setError('');try{setPdp(await runModelPDP(activeModel.model_id,{features:pdpFeatures,grid_points:16}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setXaiBusy('');}}
  async function runCf(){setXaiBusy('cf');setError('');try{const row=JSON.parse(rowText) as Record<string, unknown>;const immutable=immutableText.split(',').map(x=>x.trim()).filter(Boolean);const payload:Parameters<typeof runModelCounterfactuals>[1]={row,max_changes:2,max_results:5,immutable_features:immutable};if(activeModel.task==='regression'){if(desiredValue.trim())payload.desired_value=Number(desiredValue);else payload.direction='increase';}setCf(await runModelCounterfactuals(activeModel.model_id,payload));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setXaiBusy('');}}

  return <div className="page">
    <div className="page-title">
      <div><span className="eyebrow">EXPLAINABLE AI · SHAP · PDP · COUNTERFACTUALS</span><h1>Explicabilité du modèle</h1><p>Diagnostics globaux, permutation importance, calibration, SHAP, dépendance partielle et contre-factuels bornés. Aucune sortie XAI n’est présentée comme une preuve causale.</p></div>
      <span className="module-state implemented">XAI avancé</span>
    </div>

    {caps&&<div className="xai-cap-grid">
      <div><span>SHAP</span><b>{caps.shap?.installed?'disponible':'non installé'}</b></div>
      <div><span>PDP</span><b>{caps.partial_dependence?'disponible':'—'}</b></div>
      <div><span>Contre-factuels</span><b>{caps.counterfactual_search?'disponible':'—'}</b></div>
      <div><span>Calibration</span><b>{caps.calibration?'classification':'non applicable'}</b></div>
    </div>}

    <Panel title="Diagnostics globaux" action={<code>{model.model_id.slice(0,8)}…</code>}>
      <div className="button-row"><RunButton busy={busy} label="Calculer les diagnostics" busyLabel="Calcul…" onClick={load}/><button className="secondary-btn real-button" disabled={!!xaiBusy} onClick={()=>void runAudit()}>{xaiBusy==='audit'?'Audit…':'Audit XAI complet'}</button>{diag&&<small className="help-text">Évaluation : {diag.evaluation_source} · {diag.rows} lignes</small>}</div>
    </Panel>

    {xaiAudit&&<Panel title="Audit XAI unifié"><div className="metrics mini"><Stat label="ID explication" value={String(xaiAudit.provenance?.explanation_id??'—').slice(0,12)}/><Stat label="Source" value={xaiAudit.summary?.evaluation_source??'—'}/><Stat label="SHAP" value={xaiAudit.coverage?.shap?'exécuté':'optionnel'}/><Stat label="Causalité" value="non revendiquée"/></div><SimpleTable rows={Object.entries(xaiAudit.coverage??{}).map(([method,available])=>({method,status:available==null?'n/a':available?'couvert':'non exécuté'}))} columns={[["method","Méthode"],["status","Couverture"]]}/><small className="help-text">Audit persisté dans la Model Card · {xaiAudit.provenance?.model_sha256?.slice(0,16)}…</small></Panel>}

    {diag&&<>
      <Panel title="Importance globale — permutation"><BarChart rows={(diag.permutation_importance??[]).slice(0,12).map((x:AnyObj)=>({...x,importance_abs:Math.abs(Number(x.importance)||0)}))} valueKey="importance_abs" labelKey="feature"/></Panel>
      {diag.task==='classification'&&<>
        <div className="two-col"><Panel title="Matrice de confusion"><ConfusionMatrix matrix={diag.confusion_matrix} classes={diag.classes}/></Panel><Panel title="Courbe ROC"><div className="metrics mini"><Stat label="ROC-AUC" value={formatNumber(diag.roc_auc)}/><Stat label="Brier" value={formatNumber(diag.brier_score)}/><Stat label="ECE" value={formatNumber(diag.expected_calibration_error)}/></div>{diag.roc_curve&&<CurveChart rows={diag.roc_curve} xKey="fpr" yKey="tpr"/>}</Panel></div>
        <div className="two-col"><Panel title="Precision / Recall">{diag.pr_curve&&<CurveChart rows={diag.pr_curve} xKey="recall" yKey="precision"/>}</Panel><Panel title="Calibration binaire">{diag.calibration&&<CurveChart rows={diag.calibration} xKey="mean_predicted" yKey="fraction_positive"/>}</Panel></div>
        {diag.per_class_metrics&&<Panel title="Métriques par classe"><SimpleTable rows={diag.per_class_metrics} columns={[["class","Classe"],["precision","Précision"],["recall","Rappel"],["f1","F1"],["support","Support"]]}/></Panel>}
      </>}
      {diag.task==='regression'&&<>
        <Panel title="Résidus — métriques"><div className="metrics"><Stat label="MAE" value={formatNumber(diag.metrics?.mae)}/><Stat label="RMSE" value={formatNumber(diag.metrics?.rmse)}/><Stat label="R²" value={formatNumber(diag.metrics?.r2)}/><Stat label="Écart-type résidus" value={formatNumber(diag.metrics?.residual_std)}/></div></Panel>
        <div className="two-col"><Panel title="Résidus vs prédictions"><ScatterPlot points={(diag.residual_points??[]).map((p:AnyObj)=>({x:p.predicted,y:p.residual}))} xLabel="Prédit" yLabel="Résidu" zeroLine/></Panel><Panel title="Observé vs prédit"><ScatterPlot points={(diag.residual_points??[]).map((p:AnyObj)=>({x:p.predicted,y:p.observed}))} xLabel="Prédit" yLabel="Observé" diagonal/></Panel></div>
      </>}
    </>}

    <Panel title="Observation de référence">
      <textarea className="json-editor compact-editor" value={rowText} onChange={e=>setRowText(e.target.value)} spellCheck={false}/>
      <div className="button-row">
        <RunButton busy={explaining} label="Explication locale" busyLabel="Explication…" onClick={explain}/>
        <button className="secondary-btn real-button" disabled={!!xaiBusy} onClick={()=>void runShap()}>{xaiBusy==='shap'?'SHAP…':'Calculer SHAP'}</button>
        <button className="secondary-btn real-button" disabled={!!xaiBusy} onClick={()=>void runCf()}>{xaiBusy==='cf'?'Recherche…':'Chercher des contre-factuels'}</button>
      </div>
      {model.task==='regression'&&<label className="inline-xai-field">Valeur cible contrefactuelle (optionnel)<input type="number" value={desiredValue} onChange={e=>setDesiredValue(e.target.value)} placeholder="Sinon : augmenter la prédiction"/></label>}
      <label className="inline-xai-field">Variables immuables (séparées par des virgules)<input value={immutableText} onChange={e=>setImmutableText(e.target.value)} placeholder="âge_naissance, pays_origine…"/></label>
    </Panel>

    {local&&<Panel title="Explication locale — perturbation"><div className="local-xai"><div className="advisor-box"><span>PRÉDICTION</span><b>{formatNumber(local.prediction)}</b><p>Méthode : {local.method}</p></div><SimpleTable rows={local.contributions} columns={[["feature","Variable"],["value","Valeur"],["baseline","Baseline"],["effect","Effet local"]]}/><small className="help-text">{local.caveat}</small></div></Panel>}

    {shap&&<Panel title="SHAP">
      {shap.status==='ok'?<>
        <div className="advisor-box"><span>MÉTHODE</span><b>{shap.method}</b><p>{shap.rows_explained} lignes · {shap.transformed_features} variables transformées</p></div>
        <BarChart rows={(shap.global_importance??[]).slice(0,15)} valueKey="abs_value" labelKey="feature"/>
        {shap.local?.contributions&&<details><summary>Contribution SHAP locale</summary><SimpleTable rows={shap.local.contributions.slice(0,20)} columns={[["feature","Variable"],["value","SHAP"],["abs_value","|SHAP|"]]}/></details>}
        <small className="help-text">{shap.caveat}</small>
      </>:<div className="warning-box">SHAP indisponible pour ce pipeline : {shap.reason}</div>}
    </Panel>}

    <Panel title="Dépendance partielle (PDP)">
      <div className="check-grid">{features.map((f:string)=><label key={f}><input type="checkbox" checked={pdpFeatures.includes(f)} onChange={e=>setPdpFeatures(e.target.checked?[...pdpFeatures,f].slice(0,8):pdpFeatures.filter(x=>x!==f))}/>{f}</label>)}</div>
      <button className="secondary-btn real-button" disabled={xaiBusy==='pdp'||!pdpFeatures.length} onClick={()=>void runPdp()}>{xaiBusy==='pdp'?'Calcul PDP…':'Calculer PDP'}</button>
      {pdp&&<div className="pdp-grid">{(pdp.curves??[]).map((curve:AnyObj)=><article key={curve.feature}><b>{curve.feature}</b><small>{curve.kind}{curve.target_class!=null?` · classe ${curve.target_class}`:''}</small>{curve.kind==='numeric'?<LineChart rows={curve.points.map((p:AnyObj)=>({x:Number(p.value),y:Number(p.response)}))} xKey="x" yKey="y"/>:<SimpleTable rows={curve.points} columns={[["value","Valeur"],["response","Réponse moyenne"]]}/>}</article>)}</div>}
      {pdp&&<small className="help-text">{pdp.caveat}</small>}
    </Panel>

    {cf&&<Panel title="Contre-factuels">
      <div className="decision-warning">{cf.caveat}</div>
      <SimpleTable rows={(cf.counterfactuals??[]).map((x:AnyObj)=>({reached:x.reached?'oui':'non',prediction:x.prediction,target_probability:x.target_probability,distance:x.distance,changes:JSON.stringify(x.changes)}))} columns={[["reached","Objectif atteint"],["prediction","Prédiction"],["target_probability","Proba cible"],["distance","Distance"],["changes","Modifications"]]}/>
      <small className="help-text">{cf.searched_candidates} candidats évalués par le modèle sauvegardé.</small>
    </Panel>}
  </div>;
}

function ConfusionMatrix({matrix,classes}:{matrix:number[][];classes:any[]}) { if(!matrix?.length)return <div className="quiet-empty">Indisponible</div>; return <div className="confusion-grid" style={{gridTemplateColumns:`80px repeat(${classes.length},minmax(60px,1fr))`}}><span></span>{classes.map(c=><b key={`h${c}`}>Prédit {String(c)}</b>)}{matrix.map((row,i)=><><b key={`r${i}`}>Réel {String(classes[i])}</b>{row.map((v,j)=><span key={`${i}-${j}`} className={i===j?'correct':''}>{v}</span>)}</>)}</div>; }
function CurveChart({rows,xKey,yKey}:{rows:AnyObj[];xKey:string;yKey:string}) { if(!rows?.length)return <div className="quiet-empty">Courbe indisponible</div>; const pts=rows.map(r=>`${30+(Number(r[xKey])||0)*250},${220-(Number(r[yKey])||0)*180}`).join(' '); return <svg viewBox="0 0 300 240" className="curve-chart"><line x1="30" y1="220" x2="280" y2="220" className="chart-axis"/><line x1="30" y1="40" x2="30" y2="220" className="chart-axis"/><line x1="30" y1="220" x2="280" y2="40" className="reference-line"/><polyline points={pts} className="roc-line" fill="none"/></svg>; }




function InsightEngineView({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [feed,setFeed]=useState<AnyObj|null>(null);
  const [history,setHistory]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [category,setCategory]=useState('all');
  async function load(){
    if(!result)return;
    try{const [f,h]=await Promise.all([getInsights(result.dataset.id,40),getInsightHistory(result.dataset.id,20)]);setFeed(f);setHistory(h.history??[]);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
  }
  useEffect(()=>{if(!result){setFeed(null);setHistory([]);return;}void load();},[result?.dataset?.id]);
  if(!result)return <EmptyState title="Insight Engine" text="Chargez un dataset pour générer des insights automatiques vérifiables."/>;
  async function scan(){setBusy(true);setError('');try{const f=await scanInsights(result!.dataset.id,40);setFeed(f);const h=await getInsightHistory(result!.dataset.id,20);setHistory(h.history??[]);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  const rows=(feed?.insights??[]).filter((x:AnyObj)=>category==='all'||x.category===category);
  const categories=Object.keys(feed?.summary?.by_category??{});
  const severity=feed?.summary?.by_severity??{};
  const limitations:string[]=feed?.limitations??[];
  function go(item:AnyObj){const view=item?.suggested_action?.view as View|undefined;if(view)setView(view);}
  return <div className="page insight-engine-page">
    <div className="page-title"><div><span className="eyebrow">DETERMINISTIC INSIGHT ENGINE · V1</span><h1>Insight Engine</h1><p>Détecte automatiquement qualité, anomalies, tendances, segments, corrélations et changements entre versions. Chaque insight conserve sa preuve, sa méthode et son score de priorité.</p></div><RunButton busy={busy} label="Scanner maintenant" busyLabel="Analyse…" onClick={scan}/></div>
    <div className="metrics insight-kpis"><Stat label="Insights" value={feed?.summary?.count??0}/><Stat label="Critiques" value={severity.critical??0}/><Stat label="Haute priorité" value={severity.high??0}/><Stat label="Catégories" value={categories.length}/><Stat label="Moteur" value={feed?.engine_version??'—'}/></div>
    <div className="insight-toolbar"><div className="filter-chips"><button className={category==='all'?'active':''} onClick={()=>setCategory('all')}>Tous</button>{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c} · {feed?.summary?.by_category?.[c]??0}</button>)}</div><small>Tri automatique par priorité · calcul numérique 100 % déterministe</small></div>
    <div className="insight-engine-layout"><section className="insight-engine-feed">{rows.length?rows.map((x:AnyObj)=><article key={x.id} className={`insight-engine-card severity-${x.severity}`}>
      <header><div><span className={`severity-pill ${x.severity}`}>{String(x.severity).toUpperCase()}</span><span className="insight-category">{x.category}</span><b>#{x.rank} · {x.title}</b></div><strong>{formatNumber(x.priority_score,0)}/100</strong></header>
      <p>{x.statement}</p>
      <div className="insight-score-row"><span>Confiance <b>{formatNumber(Number(x.confidence)*100,0)}%</b></span><span>Impact <b>{formatNumber(Number(x.impact)*100,0)}%</b></span><span>Méthode <b>{x.calculation?.method}</b></span></div>
      <details><summary>Preuve & traçabilité</summary><pre className="result-json insight-proof">{JSON.stringify({evidence:x.evidence,calculation:x.calculation,dataset:x.dataset,causal_claim:x.causal_claim},null,2)}</pre><p className="help-text">{x.explanation}</p></details>
      <footer><small>{x.fingerprint?.slice(0,16)}… · v{x.dataset?.version}</small>{x.suggested_action&&<button className="secondary-btn" onClick={()=>go(x)}>{x.suggested_action.label} →</button>}</footer>
    </article>):<div className="quiet-empty">Aucun insight dans cette catégorie.</div>}</section>
    <aside className="insight-engine-side"><Panel title="Couverture"><div className="proactive-method"><p><b>Qualité</b><br/>Règles déterministes, manquants, doublons, constantes et valeurs atypiques.</p><p><b>Tendances</b><br/>Agrégation temporelle puis pente normalisée, sans extrapolation causale.</p><p><b>Segments</b><br/>Concentration et écarts standardisés entre groupes.</p><p><b>Relations</b><br/>Corrélations de Pearson sur observations complètes.</p><p><b>Versions</b><br/>Variations de volume et déplacement des moyennes entre versions immuables.</p></div></Panel><Panel title="Historique des scans" action={<span className="quiet">{history.length}</span>}><div className="insight-history">{history.length?history.slice(0,10).map((h:AnyObj,i:number)=><div key={`${h.generated_at}-${i}`}><b>{h.summary?.count??0} insights</b><small>{h.generated_at?new Date(h.generated_at).toLocaleString('fr-FR'):'—'} · v{h.dataset?.version??'—'}</small></div>):<div className="quiet-empty">Lancez un scan pour créer un snapshot traçable.</div>}</div></Panel></aside></div>
    {limitations.length>0&&<Panel title="Limites d'interprétation"><div className="warning-box">{limitations.map((x:string)=><p key={x}>• {x}</p>)}</div></Panel>}
  </div>;
}

function ProactiveInbox({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [summary,setSummary]=useState<AnyObj|null>(null);
  const [alerts,setAlerts]=useState<AnyObj[]>([]);
  const [watches,setWatches]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [filter,setFilter]=useState('open');

  async function load(status=filter){
    if(!result)return;
    try{
      const [s,w,i]=await Promise.all([getProactiveSummary(result.dataset.id),getProactiveWatches(result.dataset.id),getProactiveInbox(result.dataset.id,status,100)]);
      setSummary(s);setWatches(w.watches??[]);setAlerts(i.alerts??[]);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
  }
  useEffect(()=>{if(!result){setSummary(null);setAlerts([]);setWatches([]);return;}load(filter);},[result?.dataset?.id,filter]);
  if(!result)return <EmptyState title="Inbox analytique" text="Chargez un dataset pour activer la surveillance proactive des métriques."/>;

  async function configure(){setBusy(true);setError('');try{await autoConfigureProactiveWatches(result!.dataset.id,{threshold_pct:10,time_grain:'month'});await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function scan(){setBusy(true);setError('');try{await scanProactiveSignals(result!.dataset.id,{auto_configure:true});await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function setStatus(id:string,status:'acknowledged'|'dismissed'|'resolved'|'open'){try{await updateProactiveAlertStatus(result!.dataset.id,id,status);await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  const sev=summary?.severity??{};
  const fmtDate=(v:any)=>v?new Date(v).toLocaleString('fr-FR'):'Jamais';
  return <div className="page proactive-page">
    <div className="page-title"><div><span className="eyebrow">PROACTIVE INTELLIGENCE</span><h1>Inbox analytique</h1><p>Surveille les métriques gouvernées, détecte les changements atypiques et propose les investigations à mener.</p></div><div className="button-row"><button className="secondary-btn" disabled={busy} onClick={configure}>Configurer automatiquement</button><RunButton busy={busy} label="Scanner maintenant" busyLabel="Scan…" onClick={scan}/></div></div>
    <div className="metrics proactive-kpis"><Stat label="Alertes ouvertes" value={summary?.open_alerts??0}/><Stat label="Critiques" value={sev.critical??0}/><Stat label="Haute priorité" value={sev.high??0}/><Stat label="Surveillances actives" value={summary?.active_watches??0}/><Stat label="Dernier scan" value={fmtDate(summary?.last_scan_at)}/></div>
    {watches.length===0&&<div className="proactive-empty"><div><span>◉</span><h3>Aucune métrique surveillée</h3><p>DataVision peut créer automatiquement une surveillance mensuelle pour les métriques certifiées disposant d’une dimension temporelle.</p></div><button className="primary-btn real-button" onClick={configure} disabled={busy}>Configurer la surveillance</button></div>}
    <div className="proactive-layout">
      <section className="proactive-main">
        <div className="proactive-toolbar"><div><b>Signaux détectés</b><small>Les alertes sont fondées sur des variations de période et des scores robustes d’anomalie.</small></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="open">Ouvertes</option><option value="acknowledged">Reconnues</option><option value="resolved">Résolues</option><option value="dismissed">Ignorées</option><option value="all">Toutes</option></select></div>
        <div className="proactive-alert-list">{alerts.length?alerts.map(a=><article key={a.id} className={`proactive-alert severity-${a.severity}`}>
          <header><div><span className={`severity-pill ${a.severity}`}>{String(a.severity).toUpperCase()}</span><span className="status-pill">{a.status}</span><b>{a.title}</b></div><small>{fmtDate(a.detected_at)}</small></header>
          <p className="proactive-statement">{a.statement}</p>
          <div className="proactive-evidence"><div><span>Valeur</span><b>{formatNumber(a.value,2)}</b></div><div><span>Précédent</span><b>{formatNumber(a.previous_value,2)}</b></div><div><span>Variation</span><b>{a.delta_pct==null?'—':`${formatNumber(a.delta_pct,1)} %`}</b></div><div><span>Z niveau</span><b>{formatNumber(a.level_z,2)}</b></div></div>
          <small className="evidence-line">Preuve · {a.evidence}</small>
          {a.trend?.length>1&&<div className="proactive-trend"><BarChart rows={a.trend.slice(-8)} valueKey="value" labelKey="period"/></div>}
          <div className="investigation-grid">{(a.investigations??[]).slice(0,4).map((x:AnyObj,i:number)=><button key={i} onClick={()=>setView(x.type==='quality_check'?'quality':'semantic')}><span>{x.type==='quality_check'?'✓':'◈'}</span><div><b>{x.label}</b><small>{x.reason}</small></div></button>)}</div>
          <footer><div><small>Moteur : {a.provenance?.engine} · modèle sémantique v{a.provenance?.semantic_model_version??'—'}</small></div><div className="button-row">{a.status==='open'&&<button className="secondary-btn" onClick={()=>setStatus(a.id,'acknowledged')}>Reconnaître</button>}<button className="secondary-btn" onClick={()=>setStatus(a.id,'resolved')}>Résoudre</button><button className="ghost-btn" onClick={()=>setStatus(a.id,'dismissed')}>Ignorer</button></div></footer>
        </article>):<div className="proactive-clear"><span>✓</span><h3>Aucun signal dans cette vue</h3><p>Lancez un scan pour comparer les dernières périodes aux comportements historiques.</p></div>}</div>
      </section>
      <aside className="proactive-side"><Panel title="Métriques surveillées" action={<span className="quiet">{watches.length}</span>}><div className="watch-list">{watches.length?watches.map(w=><div key={w.id} className="watch-card"><div><b>{w.name}</b><small>{w.metric_id} · {w.time_grain}</small></div><span className={w.last_status==='alert'?'watch-state alert':'watch-state'}>{w.last_status??'prête'}</span><dl><div><dt>Seuil</dt><dd>{formatNumber(w.threshold_pct,1)} %</dd></div><div><dt>Anomalie</dt><dd>|z| ≥ {formatNumber(w.anomaly_z_threshold,1)}</dd></div><div><dt>Dernière valeur</dt><dd>{formatNumber(w.last_value,2)}</dd></div></dl></div>):<div className="quiet-empty">Aucune surveillance configurée.</div>}</div></Panel><Panel title="Méthode"><div className="proactive-method"><p><b>Variation</b><br/>Compare la dernière période à la précédente.</p><p><b>Anomalie robuste</b><br/>Compare le niveau courant à l’historique via médiane/MAD.</p><p><b>Rupture</b><br/>Compare la variation courante aux variations historiques.</p><small>Les signaux sont des indicateurs analytiques, pas des preuves causales.</small></div></Panel></aside>
    </div>
  </div>;
}

function SemanticStudio({result,setError}:{result:AnyObj|null;setError:(s:string)=>void}){
  const [semantic,setSemantic]=useState<AnyObj|null>(null);
  const [catalog,setCatalog]=useState<AnyObj[]>([]);
  const [validation,setValidation]=useState<AnyObj|null>(null);
  const [busy,setBusy]=useState(false);
  const [tab,setTab]=useState<'model'|'metrics'|'dimensions'|'hierarchies'|'glossary'|'query'>('model');
  const [metricId,setMetricId]=useState('');
  const [dimension,setDimension]=useState('');
  const [dateDimension,setDateDimension]=useState('');
  const [timeGrain,setTimeGrain]=useState('month');
  const [comparison,setComparison]=useState('previous_period');
  const [timeCalc,setTimeCalc]=useState('none');
  const [queryResult,setQueryResult]=useState<AnyObj|null>(null);
  const [newTableDataset,setNewTableDataset]=useState('');
  const [newRelation,setNewRelation]=useState<AnyObj>({from_table:'base',from_column:'',to_table:'',to_column:'',cardinality:'many_to_one',join_type:'left'});
  const [newCalc,setNewCalc]=useState<AnyObj>({id:'',label:'',formula:'',unit:'',certified:false});
  const [newHierarchy,setNewHierarchy]=useState<AnyObj>({name:'Calendrier',levels:[]});
  const [newGlossary,setNewGlossary]=useState<AnyObj>({term:'',definition:'',target_type:'metric',target_id:'',synonyms:[],allowed_roles:[]});
  const semanticRoles=['owner','admin','data_scientist','analyst','viewer'];

  useEffect(()=>{let cancelled=false;if(!result){setSemantic(null);setCatalog([]);return;}Promise.all([getSemanticModel(result.dataset.id),getSemanticTableCatalog(result.dataset.id)]).then(([x,c])=>{if(cancelled)return;setSemantic(x);setCatalog(c.tables??[]);setMetricId(x.metrics?.[0]?.id??'');const firstDate=(x.dimensions??[]).find((d:AnyObj)=>d.kind==='date'||/date|time/i.test(d.column??''));setDateDimension(firstDate?.id??'');}).catch(e=>{if(!cancelled)setError(e instanceof Error?e.message:String(e));});return()=>{cancelled=true}},[result?.dataset?.id]);
  if(!result)return <EmptyState title="Couche sémantique" text="Chargez un dataset pour construire un modèle métier multi-tables, certifié et réutilisable."/>;
  if(!semantic)return <div className="loading-card">Initialisation du Semantic Model Studio…</div>;

  const metrics=semantic.metrics??[],dimensions=semantic.dimensions??[],tables=semantic.tables??[],relationships=semantic.relationships??[],hierarchies=semantic.hierarchies??[],glossary=semantic.business_glossary??[];
  const tableById=(id:string)=>tables.find((t:AnyObj)=>t.id===id);
  const catalogForTable=(id:string)=>{const table=tableById(id);if(!table)return null;if(id==='base')return {columns:result.profile.columns.map((c:AnyObj)=>({name:c.name,dtype:c.dtype}))};return catalog.find((x:AnyObj)=>x.dataset_id===table.dataset_id)??null};
  const columnsForTable=(id:string)=>(catalogForTable(id)?.columns??[]).map((c:AnyObj)=>String(c.name));
  const payload=()=>({tables:semantic.tables??[],relationships:semantic.relationships??[],metrics:semantic.metrics??[],dimensions:semantic.dimensions??[],hierarchies:semantic.hierarchies??[],business_glossary:semantic.business_glossary??[]});
  const updateMetric=(i:number,patch:AnyObj)=>setSemantic({...semantic,metrics:metrics.map((m:AnyObj,j:number)=>j===i?{...m,...patch}:m)});
  const updateDim=(i:number,patch:AnyObj)=>setSemantic({...semantic,dimensions:dimensions.map((d:AnyObj,j:number)=>j===i?{...d,...patch}:d)});

  async function validate(){setBusy(true);setError('');try{setValidation(await validateSemanticModel(result!.dataset.id,payload()));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function save(){setBusy(true);setError('');try{const saved=await saveSemanticModel(result!.dataset.id,payload());setSemantic(saved);setValidation(saved.validation??null);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  function addTable(){const row=catalog.find((x:AnyObj)=>x.dataset_id===newTableDataset);if(!row)return;let alias=String(row.name??'table').replace(/\.[^.]+$/,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')||'table';let n=2;while(tables.some((t:AnyObj)=>t.id===alias)){alias=`${alias}_${n++}`;}setSemantic({...semantic,tables:[...tables,{id:alias,dataset_id:row.dataset_id,label:row.name,role:'dimension',active:true}]});setNewTableDataset('');}
  function removeTable(id:string){if(id==='base')return;setSemantic({...semantic,tables:tables.filter((t:AnyObj)=>t.id!==id),relationships:relationships.filter((r:AnyObj)=>r.from_table!==id&&r.to_table!==id),metrics:metrics.filter((m:AnyObj)=>m.table!==id),dimensions:dimensions.filter((d:AnyObj)=>d.table!==id)});}
  function addRelation(){if(!newRelation.from_table||!newRelation.to_table||!newRelation.from_column||!newRelation.to_column)return;const id=`${newRelation.from_table}_${newRelation.to_table}_${newRelation.from_column}`.toLowerCase().replace(/[^a-z0-9_]+/g,'_');setSemantic({...semantic,relationships:[...relationships,{id,...newRelation,active:true}]});setNewRelation({...newRelation,from_column:'',to_table:'',to_column:''});}
  function addCalculatedMetric(){const id=(newCalc.id||newCalc.label).toLowerCase().replace(/[^a-z0-9_]+/g,'_').replace(/^_|_$/g,'');if(!id||!newCalc.formula)return;setSemantic({...semantic,metrics:[...metrics,{id,name:newCalc.label||id,label:newCalc.label||id,type:'calculated',table:'base',column:'',aggregation:'sum',formula:newCalc.formula,unit:newCalc.unit??'',format:'number',description:'',synonyms:[],certified:!!newCalc.certified,source:'user'}]});setNewCalc({id:'',label:'',formula:'',unit:'',certified:false});setMetricId(id);}
  function addHierarchy(){const id=String(newHierarchy.name||'hierarchy').toLowerCase().replace(/[^a-z0-9_]+/g,'_');if((newHierarchy.levels??[]).length<2)return;setSemantic({...semantic,hierarchies:[...hierarchies,{id,name:newHierarchy.name,levels:newHierarchy.levels,certified:false,description:''}]});setNewHierarchy({name:'Hiérarchie',levels:[]});}
  function addGlossary(){const term=String(newGlossary.term??'').trim();const targetId=String(newGlossary.target_id??'').trim();if(!term||!targetId)return;setSemantic({...semantic,business_glossary:[...glossary,{term,definition:String(newGlossary.definition??''),target_type:newGlossary.target_type,target_id:targetId,synonyms:newGlossary.synonyms??[],allowed_roles:newGlossary.allowed_roles??[]}]});setNewGlossary({term:'',definition:'',target_type:'metric',target_id:'',synonyms:[],allowed_roles:[]});}
  async function runQuery(){if(!metricId)return;setBusy(true);setError('');try{setQueryResult(await querySemanticMetric(result!.dataset.id,{metric_id:metricId,dimensions:dimension?[dimension]:[],date_dimension:dateDimension||null,time_grain:dateDimension?timeGrain:null,comparison:dateDimension?comparison:'none',time_calculation:dateDimension?timeCalc:'none',rolling_window:3,limit:500}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}

  const validationScore=validation?.score??semantic.validation?.score;
  return <div className="page semantic-page semantic-v2-page">
    <div className="page-title"><div><span className="eyebrow">SEMANTIC MODEL STUDIO · V2</span><h1>Couche sémantique gouvernée</h1><p>Reliez plusieurs tables, définissez des métriques certifiées et calculées, des hiérarchies et une intelligence temporelle sans exposer la complexité physique des données.</p></div><div className="semantic-head-actions"><span className={`semantic-status ${semantic.status}`}>{semantic.status==='governed'?'Gouvernée':'Brouillon'}</span>{validationScore!=null&&<span className="semantic-health">Health {validationScore}/100</span>}<button className="secondary-btn" disabled={busy} onClick={validate}>Valider</button><button className="primary-btn" disabled={busy} onClick={save}>{busy?'Traitement…':'Enregistrer'}</button></div></div>
    <div className="semantic-summary semantic-summary-v2"><div><b>{tables.length}</b><span>Tables</span></div><div><b>{relationships.length}</b><span>Relations</span></div><div><b>{metrics.length}</b><span>Métriques</span></div><div><b>{metrics.filter((m:AnyObj)=>m.certified).length}</b><span>Certifiées</span></div><div><b>{hierarchies.length}</b><span>Hiérarchies</span></div><div><b>v{semantic.version??1}</b><span>Version</span></div></div>
    {validation&&<div className={`semantic-validation-banner ${validation.valid?'valid':'invalid'}`}><div><b>{validation.valid?'✓ Modèle cohérent':'! Modèle à corriger'}</b><span>{validation.errors?.length??0} erreur(s) · {validation.warnings?.length??0} avertissement(s)</span></div>{validation.errors?.slice(0,3).map((x:string,i:number)=><small key={i}>{x}</small>)}{validation.warnings?.slice(0,2).map((x:string,i:number)=><small key={`w${i}`}>△ {x}</small>)}</div>}
    <nav className="semantic-tabs">{([['model','Modèle & relations'],['metrics','Métriques'],['dimensions','Dimensions'],['hierarchies','Hiérarchies'],['glossary','Glossaire'],['query','Query Lab']] as const).map(([k,l])=><button key={k} className={tab===k?'active':''} onClick={()=>setTab(k)}>{l}</button>)}</nav>

    {tab==='model'&&<div className="semantic-workspace-grid"><Panel title="Tables du modèle" action={<span className="quiet">Fact + dimensions</span>}><div className="semantic-table-list">{tables.map((t:AnyObj)=><article key={t.id} className={t.id==='base'?'base':''}><div><span>{t.role==='fact'?'FACT':'DIM'}</span><b>{t.label||t.id}</b><small>{t.id} · {t.dataset_id===result.dataset.id?`dataset actif v${result.dataset.version}`:t.dataset_id.slice(0,8)+'…'}</small></div>{t.id!=='base'&&<button className="icon-danger" onClick={()=>removeTable(t.id)}>×</button>}</article>)}</div><div className="semantic-add-line"><select value={newTableDataset} onChange={e=>setNewTableDataset(e.target.value)}><option value="">Ajouter une table liée…</option>{catalog.filter((x:AnyObj)=>!x.current&&!tables.some((t:AnyObj)=>t.dataset_id===x.dataset_id)).map((x:AnyObj)=><option value={x.dataset_id} key={x.dataset_id}>{x.name} · v{x.version} · {x.rows} lignes</option>)}</select><button className="secondary-btn" onClick={addTable} disabled={!newTableDataset}>Ajouter</button></div></Panel>
      <Panel title="Relations sûres" action={<span className="quiet">N:1 / 1:1 · anti fan-out</span>}><div className="semantic-relations">{relationships.map((r:AnyObj,i:number)=><article key={r.id}><div><b>{r.from_table}.{r.from_column}</b><span>→</span><b>{r.to_table}.{r.to_column}</b><small>{r.cardinality.replaceAll('_',':')} · {r.join_type}</small></div><button className="icon-danger" onClick={()=>setSemantic({...semantic,relationships:relationships.filter((_:AnyObj,j:number)=>j!==i)})}>×</button></article>)}</div><div className="relation-builder"><label>Depuis<select value={newRelation.from_table} onChange={e=>setNewRelation({...newRelation,from_table:e.target.value,from_column:''})}>{tables.map((t:AnyObj)=><option key={t.id} value={t.id}>{t.id}</option>)}</select></label><label>Clé<select value={newRelation.from_column} onChange={e=>setNewRelation({...newRelation,from_column:e.target.value})}><option value="">—</option>{columnsForTable(newRelation.from_table).map((c:string)=><option key={c}>{c}</option>)}</select></label><span className="relation-arrow">→</span><label>Vers<select value={newRelation.to_table} onChange={e=>setNewRelation({...newRelation,to_table:e.target.value,to_column:''})}><option value="">—</option>{tables.filter((t:AnyObj)=>t.id!==newRelation.from_table).map((t:AnyObj)=><option key={t.id} value={t.id}>{t.id}</option>)}</select></label><label>Clé<select value={newRelation.to_column} onChange={e=>setNewRelation({...newRelation,to_column:e.target.value})}><option value="">—</option>{columnsForTable(newRelation.to_table).map((c:string)=><option key={c}>{c}</option>)}</select></label><label>Cardinalité<select value={newRelation.cardinality} onChange={e=>setNewRelation({...newRelation,cardinality:e.target.value})}><option value="many_to_one">N:1</option><option value="one_to_one">1:1</option></select></label><button className="primary-btn" onClick={addRelation}>Créer relation</button></div><div className="semantic-note">Les relations N:N et 1:N ne sont pas exécutées automatiquement : DataVision bloque les jointures susceptibles de dupliquer artificiellement une métrique.</div></Panel></div>}

    {tab==='metrics'&&<><Panel title="Métriques métier" action={<span className="quiet">Base + calculées · certification</span>}><div className="semantic-metric-list semantic-metric-v2">{metrics.map((m:AnyObj,i:number)=><article className={m.certified?'semantic-metric certified':'semantic-metric'} key={`${m.id}-${i}`}><div className="metric-cert"><input type="checkbox" checked={!!m.certified} onChange={e=>updateMetric(i,{certified:e.target.checked})}/><span>{m.certified?'CERTIFIÉE':'BROUILLON'}</span><em>{m.type==='calculated'?'ƒx':'Σ'}</em></div><label>Nom métier<input value={m.label??m.name??''} onChange={e=>updateMetric(i,{label:e.target.value,name:e.target.value})}/></label>{m.type!=='calculated'?<><label>Table<select value={m.table??'base'} onChange={e=>{const table=e.target.value;updateMetric(i,{table,column:columnsForTable(table)[0]??''})}}>{tables.map((t:AnyObj)=><option key={t.id}>{t.id}</option>)}</select></label><label>Colonne<select value={m.column} onChange={e=>updateMetric(i,{column:e.target.value})}>{columnsForTable(m.table??'base').map((c:string)=><option key={c}>{c}</option>)}</select></label><label>Agrégation<select value={m.aggregation} onChange={e=>updateMetric(i,{aggregation:e.target.value})}>{['sum','mean','median','min','max','count','nunique'].map(a=><option key={a}>{a}</option>)}</select></label></>:<label className="semantic-wide">Formule<input value={m.formula??''} onChange={e=>updateMetric(i,{formula:e.target.value})} placeholder="revenue - cost"/></label>}<label>Unité<input value={m.unit??''} onChange={e=>updateMetric(i,{unit:e.target.value})} placeholder="€, %, ms…"/></label><label className="semantic-wide">Définition métier<input value={m.business_definition??m.description??''} onChange={e=>updateMetric(i,{business_definition:e.target.value,description:e.target.value})} placeholder="Définition, périmètre et règle d’interprétation"/></label><label className="semantic-wide">Synonymes<input value={(m.synonyms??[]).join(', ')} onChange={e=>updateMetric(i,{synonyms:e.target.value.split(',').map(x=>x.trim()).filter(Boolean)})} placeholder="CA, ventes, revenue"/></label><label className="semantic-wide">Rôles autorisés<select multiple value={m.allowed_roles??[]} onChange={e=>updateMetric(i,{allowed_roles:Array.from((e.target as HTMLSelectElement).selectedOptions).map((o:HTMLOptionElement)=>o.value)})}>{semanticRoles.map(r=><option key={r} value={r}>{r}</option>)}</select><small>Vide = tous les rôles ayant accès au dataset.</small></label></article>)}</div></Panel><Panel title="Créer une métrique calculée"><div className="calc-metric-builder"><label>ID<input value={newCalc.id} onChange={e=>setNewCalc({...newCalc,id:e.target.value})} placeholder="margin_pct"/></label><label>Nom<input value={newCalc.label} onChange={e=>setNewCalc({...newCalc,label:e.target.value})} placeholder="Marge %"/></label><label className="wide">Formule<input value={newCalc.formula} onChange={e=>setNewCalc({...newCalc,formula:e.target.value})} placeholder="(revenue - cost) / revenue * 100"/></label><label>Unité<input value={newCalc.unit} onChange={e=>setNewCalc({...newCalc,unit:e.target.value})} placeholder="%"/></label><button className="primary-btn" onClick={addCalculatedMetric}>Ajouter</button></div><small className="help-text">La formule référence des IDs de métriques existantes. Aucun eval/exec Python n'est utilisé.</small></Panel></>}

    {tab==='dimensions'&&<Panel title="Dimensions & vocabulaire"><div className="semantic-dim-grid semantic-dim-v2">{dimensions.map((d:AnyObj,i:number)=><article key={`${d.id}-${i}`} className={d.certified?'certified':''}><div><b>{d.label||d.column}</b><span>{d.table}.{d.column}</span></div><label className="switch-line"><input type="checkbox" checked={!d.hidden} onChange={e=>updateDim(i,{hidden:!e.target.checked})}/>Exposée</label><label className="switch-line"><input type="checkbox" checked={!!d.certified} onChange={e=>updateDim(i,{certified:e.target.checked})}/>Certifiée</label><label>Type<select value={d.kind??'categorical'} onChange={e=>updateDim(i,{kind:e.target.value})}><option value="categorical">Catégorielle</option><option value="date">Date</option><option value="numeric">Numérique</option></select></label><input value={d.label??d.column} onChange={e=>updateDim(i,{label:e.target.value})}/><input value={(d.synonyms??[]).join(', ')} onChange={e=>updateDim(i,{synonyms:e.target.value.split(',').map(x=>x.trim()).filter(Boolean)})} placeholder="Synonymes métier"/><input value={d.business_definition??d.description??''} onChange={e=>updateDim(i,{business_definition:e.target.value,description:e.target.value})} placeholder="Définition métier"/><label>Rôles<select multiple value={d.allowed_roles??[]} onChange={e=>updateDim(i,{allowed_roles:Array.from((e.target as HTMLSelectElement).selectedOptions).map((o:HTMLOptionElement)=>o.value)})}>{semanticRoles.map(r=><option key={r} value={r}>{r}</option>)}</select></label></article>)}</div></Panel>}

    {tab==='hierarchies'&&<div className="semantic-workspace-grid"><Panel title="Hiérarchies"><div className="hierarchy-list">{hierarchies.map((h:AnyObj,i:number)=><article key={h.id}><div><b>{h.name}</b><small>{(h.levels??[]).map((x:string)=>dimensions.find((d:AnyObj)=>d.id===x)?.label??x).join(' → ')}</small></div><label className="switch-line"><input type="checkbox" checked={!!h.certified} onChange={e=>setSemantic({...semantic,hierarchies:hierarchies.map((x:AnyObj,j:number)=>j===i?{...x,certified:e.target.checked}:x)})}/>Certifiée</label><button className="icon-danger" onClick={()=>setSemantic({...semantic,hierarchies:hierarchies.filter((_:AnyObj,j:number)=>j!==i)})}>×</button></article>)}</div></Panel><Panel title="Créer une hiérarchie"><div className="hierarchy-builder"><label>Nom<input value={newHierarchy.name} onChange={e=>setNewHierarchy({...newHierarchy,name:e.target.value})}/></label><label>Niveaux<select multiple value={newHierarchy.levels} onChange={e=>setNewHierarchy({...newHierarchy,levels:Array.from((e.target as HTMLSelectElement).selectedOptions).map((o:HTMLOptionElement)=>o.value)})}>{dimensions.filter((d:AnyObj)=>!d.hidden).map((d:AnyObj)=><option key={d.id} value={d.id}>{d.label} · {d.table}</option>)}</select></label><button className="primary-btn" onClick={addHierarchy}>Créer la hiérarchie</button><small className="help-text">Sélection multiple : Ctrl/Cmd + clic. Exemple : Année → Trimestre → Mois.</small></div></Panel></div>}

    {tab==='glossary'&&<div className="semantic-workspace-grid"><Panel title="Glossaire métier lié" action={<span className="quiet">termes → objets sémantiques</span>}><div className="hierarchy-list">{glossary.map((g:AnyObj,i:number)=><article key={`${g.term}-${i}`}><div><b>{g.term}</b><small>{g.target_type}:{g.target_id} · {g.definition||'sans définition'}</small><small>{(g.synonyms??[]).join(' · ')}</small></div><button className="icon-danger" onClick={()=>setSemantic({...semantic,business_glossary:glossary.filter((_:AnyObj,j:number)=>j!==i)})}>×</button></article>)}</div></Panel><Panel title="Ajouter un terme"><div className="hierarchy-builder"><label>Terme<input value={newGlossary.term} onChange={e=>setNewGlossary({...newGlossary,term:e.target.value})} placeholder="CA"/></label><label>Cible<select value={newGlossary.target_type} onChange={e=>setNewGlossary({...newGlossary,target_type:e.target.value,target_id:''})}><option value="metric">Métrique</option><option value="dimension">Dimension</option></select></label><label>Objet<select value={newGlossary.target_id} onChange={e=>setNewGlossary({...newGlossary,target_id:e.target.value})}><option value="">Sélectionner…</option>{(newGlossary.target_type==='metric'?metrics:dimensions).map((x:AnyObj)=><option key={x.id} value={x.id}>{x.label||x.name||x.id}</option>)}</select></label><label className="semantic-wide">Définition<input value={newGlossary.definition} onChange={e=>setNewGlossary({...newGlossary,definition:e.target.value})} placeholder="Définition métier du terme"/></label><label className="semantic-wide">Synonymes<input value={(newGlossary.synonyms??[]).join(', ')} onChange={e=>setNewGlossary({...newGlossary,synonyms:e.target.value.split(',').map(x=>x.trim()).filter(Boolean)})}/></label><label>Rôles<select multiple value={newGlossary.allowed_roles??[]} onChange={e=>setNewGlossary({...newGlossary,allowed_roles:Array.from((e.target as HTMLSelectElement).selectedOptions).map((o:HTMLOptionElement)=>o.value)})}>{semanticRoles.map(r=><option key={r} value={r}>{r}</option>)}</select></label><button className="primary-btn" onClick={addGlossary}>Ajouter au glossaire</button></div></Panel></div>}

    {tab==='query'&&<><Panel title="Semantic Query Lab" action={<span className="quiet">moteur déterministe · grain-safe</span>}><div className="semantic-query-grid"><label>Métrique<select value={metricId} onChange={e=>setMetricId(e.target.value)}>{metrics.map((m:AnyObj)=><option value={m.id} key={m.id}>{m.label||m.name}{m.certified?' ✓':''}</option>)}</select></label><label>Ventiler par<select value={dimension} onChange={e=>setDimension(e.target.value)}><option value="">Aucune</option>{dimensions.filter((d:AnyObj)=>!d.hidden).map((d:AnyObj)=><option value={d.id} key={d.id}>{d.label} · {d.table}</option>)}</select></label><label>Date<select value={dateDimension} onChange={e=>setDateDimension(e.target.value)}><option value="">Aucune</option>{dimensions.filter((d:AnyObj)=>!d.hidden&&(d.kind==='date'||/date|time|jour|mois|annee|year/i.test(d.column))).map((d:AnyObj)=><option value={d.id} key={d.id}>{d.label}</option>)}</select></label><label>Grain<select value={timeGrain} onChange={e=>setTimeGrain(e.target.value)}><option value="day">Jour</option><option value="week">Semaine</option><option value="month">Mois</option><option value="quarter">Trimestre</option><option value="year">Année</option></select></label><label>Comparaison<select value={comparison} onChange={e=>setComparison(e.target.value)}><option value="none">Aucune</option><option value="previous_period">Période précédente</option><option value="yoy">Année précédente (YoY)</option></select></label><label>Time intelligence<select value={timeCalc} onChange={e=>setTimeCalc(e.target.value)}><option value="none">Aucune</option><option value="running_total">Cumul</option><option value="ytd">YTD</option><option value="rolling_mean">Moyenne mobile</option><option value="rolling_sum">Somme mobile</option></select></label><RunButton busy={busy} label="Exécuter" busyLabel="Calcul…" onClick={runQuery}/></div></Panel>{queryResult&&<div className="semantic-query-result"><div className="metric-hero semantic-query-hero"><span>{queryResult.metric?.label}</span><strong>{formatNumber(queryResult.value,2)} {queryResult.metric?.unit}</strong><small>{queryResult.metric?.type==='calculated'?'Métrique calculée':`${queryResult.metric?.aggregation}(${queryResult.metric?.table}.${queryResult.metric?.column})`} · {queryResult.rows} lignes gouvernées</small><small>Tables: {(queryResult.tables_used??[]).join(' → ')||'base'} · Relations: {(queryResult.relationships_used??[]).join(', ')||'aucune'} · Accès: {queryResult.semantic_access?.role??'local'}</small>{queryResult.business_definition&&<small>Définition: {queryResult.business_definition}</small>}</div>{queryResult.result?.length>0&&<Panel title={queryResult.date_dimension?'Série temporelle':'Résultat ventilé'}>{queryResult.date_dimension?<LineChart rows={queryResult.result.map((r:AnyObj,i:number)=>({x:i,value:Number((queryResult.time_calculation!=='none'?r.time_value:r.value)??0)}))} xKey="x" yKey="value"/>:<BarChart rows={queryResult.result.slice(0,20)} valueKey="value" labelKey={queryResult.dimensions?.[0]}/>}<details><summary>Voir les données calculées</summary><SimpleTable rows={queryResult.result.slice(0,100)} columns={Object.keys(queryResult.result[0]??{}).map(k=>[k,k])}/></details></Panel>}</div>}</>}
  </div>;
}

function TrustCenterView({result,setError}:{result:AnyObj|null;setError:(s:string)=>void}){
  const [trust,setTrust]=useState<AnyObj|null>(null);
  useEffect(()=>{let cancelled=false;if(!result){setTrust(null);return;}getTrustCenter(result.dataset.id).then(x=>{if(!cancelled)setTrust(x)}).catch(e=>{if(!cancelled)setError(e instanceof Error?e.message:String(e));});return()=>{cancelled=true}},[result?.dataset?.id]);
  if(!result)return <EmptyState title="Trust Center" text="Chargez un dataset pour auditer qualité, sémantique, reproductibilité et confidentialité."/>;
  if(!trust)return <div className="loading-card">Calcul du Trust Score…</div>;
  const trustChecks:AnyObj[]=Array.isArray(trust?.checks)?trust.checks:[];
  const trustWarnings:string[]=Array.isArray(trust?.warnings)?trust.warnings.map((w:unknown)=>String(w)):[];
  const versionPayload=result?.versions;
  const lineageVersions:AnyObj[]=Array.isArray(versionPayload?.versions)?versionPayload.versions:(Array.isArray(versionPayload)?versionPayload:[]);
  const trustPolicy=trust?.policy??{};
  return <div className="page trust-page"><div className="page-title"><div><span className="eyebrow">TRUST · PROVENANCE · GOVERNANCE</span><h1>Trust Center</h1><p>Un point de contrôle unique avant de publier, modéliser ou prendre une décision. Chaque score est relié à des contrôles déterministes.</p></div><span className="module-state implemented">audit vérifiable</span></div>
    <div className="trust-hero"><div className="trust-ring" style={{'--trust':`${trust.overall_score}%`} as CSSProperties}><strong>{trust.overall_score}</strong><span>/100</span></div><div><span className="trust-grade">Grade {trust.grade}</span><h2>Niveau de confiance analytique</h2><p>Le score combine qualité des données, couche sémantique, reproductibilité et signaux de confidentialité. Il ne remplace pas une revue métier.</p></div><div className="trust-policy"><span>Calculs numériques</span><b>Moteurs déterministes</b><span>Données brutes vers LLM externe</span><b>{trustPolicy.raw_data_to_external_llm?'Autorisé':'Bloqué par défaut'}</b><span>Version dataset</span><b>v{trustPolicy.dataset_version??result.dataset.version??'—'}</b></div></div>
    <div className="trust-check-grid">{trustChecks.map((c:AnyObj)=><article className={`trust-check ${c.status}`} key={c.area}><div><span>{c.status==='pass'?'✓':c.status==='fail'?'!':'△'}</span><b>{c.area}</b></div><strong>{c.score}/100</strong><p>{c.evidence}</p></article>)}</div>
    <div className="two-col"><Panel title="Points d’attention">{trustWarnings.length?<div className="trust-warning-list">{trustWarnings.map((w:string,i:number)=><div key={i}><span>!</span><p>{w}</p></div>)}</div>:<div className="success-box">✓ Aucun avertissement majeur détecté.</div>}</Panel><Panel title="Lineage du dataset"><div className="lineage-compact">{lineageVersions.slice().sort((a:AnyObj,b:AnyObj)=>Number(a.version??0)-Number(b.version??0)).map((v:AnyObj)=><div key={v.id}><span>v{v.version}</span><div><b>{v.operation?.label??v.operation?.type??'Version'}</b><small>{v.id===result.dataset.id?'Version active':'Version enregistrée'}</small></div></div>)}</div></Panel></div>
  </div>;
}

function DecisionLab({result,model,setError,setView}:{result:AnyObj|null;model:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [baseText,setBaseText]=useState('{}');
  const [scenariosText,setScenariosText]=useState('[\n  {"name":"Scénario A","overrides":{}}\n]');
  const [out,setOut]=useState<AnyObj|null>(null);
  const [sensitivity,setSensitivity]=useState<AnyObj|null>(null);
  const [feature,setFeature]=useState('');
  const [range,setRange]=useState({min:0,max:10,steps:9});
  const [busy,setBusy]=useState(false);

  const [rcaTarget,setRcaTarget]=useState('');
  const [rcaCompare,setRcaCompare]=useState('');
  const [rcaMetric,setRcaMetric]=useState<'mean'|'sum'|'count'>('mean');
  const [rcaTimeGrain,setRcaTimeGrain]=useState<'auto'|'raw'|'day'|'week'|'month'|'quarter'|'year'>('auto');
  const [rcaDimensions,setRcaDimensions]=useState<string[]>([]);
  const [rca,setRca]=useState<AnyObj|null>(null);
  const [rcaBusy,setRcaBusy]=useState(false);

  const [controlsText,setControlsText]=useState('{}');
  const [objective,setObjective]=useState<'maximize'|'minimize'|'target'>('maximize');
  const [objectiveTarget,setObjectiveTarget]=useState('');
  const [optimized,setOptimized]=useState<AnyObj|null>(null);
  const [optBusy,setOptBusy]=useState(false);

  useEffect(()=>{
    if(!result)return;
    const cols=result.profile?.columns??[];
    const numeric=cols.filter((c:AnyObj)=>isNumeric(c));
    const comparative=cols.filter((c:AnyObj)=>{
      const name=String(c.name??'').toLowerCase();
      const dateLike=name.includes('date')||name.includes('time')||name.includes('month')||name.includes('mois')||name.includes('year')||name.includes('annee')||name.includes('année');
      return Number(c.unique??0)>=2&&(Number(c.unique??0)<=100||dateLike);
    });
    setRcaTarget(prev=>prev&&cols.some((c:AnyObj)=>c.name===prev)?prev:(numeric[0]?.name??''));
    setRcaCompare(prev=>prev&&cols.some((c:AnyObj)=>c.name===prev)?prev:(comparative[0]?.name??''));
    setRcaDimensions(prev=>prev.length?prev:comparative.slice(1,5).map((c:AnyObj)=>c.name));
    setRca(null);

    if(!model)return;
    const features=model.model_card?.features??model.features??[];
    const src=result.preview?.rows?.[0]??{};
    const row:AnyObj={};
    for(const f of features)row[f]=src[f]??null;
    setBaseText(JSON.stringify(row,null,2));
    const first=features.find((f:string)=>typeof row[f]==='number')??features[0]??'';
    setFeature(first);

    const controls:AnyObj={};
    for(const f of features.slice(0,5)){
      const v=row[f];
      if(typeof v==='number'&&Number.isFinite(v)){
        const span=Math.max(Math.abs(v)*.2,1);
        controls[f]={min:Number((v-span).toFixed(4)),max:Number((v+span).toFixed(4)),steps:5};
      }else if(v!=null){
        controls[f]={values:[v]};
      }
    }
    setControlsText(JSON.stringify(controls,null,2));

    if(first&&typeof row[first]==='number'){
      const v=Number(row[first]);
      const span=Math.max(Math.abs(v)*.25,1);
      setRange({min:Number((v-span).toFixed(3)),max:Number((v+span).toFixed(3)),steps:9});
      setScenariosText(JSON.stringify([
        {name:'-10 %',overrides:{[first]:Number((v*.9).toFixed(3))}},
        {name:'+10 %',overrides:{[first]:Number((v*1.1).toFixed(3))}},
      ],null,2));
    }
  },[model?.model_id,result?.dataset?.id]);

  if(!result)return <EmptyState title="Decision Lab" text="Chargez un dataset pour analyser les écarts, identifier les facteurs associés et simuler des décisions."/>;
  const columns=result.profile?.columns??[];
  const numericColumns=columns.filter((c:AnyObj)=>isNumeric(c));
  const comparisonColumns=columns.filter((c:AnyObj)=>{
    const name=String(c.name??'').toLowerCase();
    const dateLike=name.includes('date')||name.includes('time')||name.includes('month')||name.includes('mois')||name.includes('year')||name.includes('annee')||name.includes('année');
    return Number(c.unique??0)>=2&&(Number(c.unique??0)<=100||dateLike);
  });
  const features=model?.model_card?.features??model?.features??[];

  async function runRca(){
    if(!rcaTarget||!rcaCompare)return;
    setRcaBusy(true);setError('');
    try{
      setRca(await runRootCauseAnalysis(result!.dataset.id,{
        target:rcaTarget,
        comparison_column:rcaCompare,
        metric:rcaMetric,
        dimensions:rcaDimensions,
        time_grain:rcaTimeGrain,
        min_segment_size:3,
        top_n:8,
      }));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setRcaBusy(false);}
  }

  async function run(){
    if(!model)return;
    setBusy(true);setError('');
    try{
      const base=JSON.parse(baseText),scenarios=JSON.parse(scenariosText);
      if(!Array.isArray(scenarios))throw new Error('Les scénarios doivent être un tableau JSON.');
      setOut(await runModelWhatIf(model.model_id,{base_row:base,scenarios}));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false);}
  }

  async function sens(){
    if(!model||!feature)return;
    setBusy(true);setError('');
    try{
      const base=JSON.parse(baseText);
      const steps=Math.max(3,Math.min(30,range.steps));
      const values=Array.from({length:steps},(_,i)=>range.min+(range.max-range.min)*i/(steps-1));
      setSensitivity(await runModelSensitivity(model.model_id,{base_row:base,feature,values}));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false);}
  }

  async function optimize(){
    if(!model)return;
    setOptBusy(true);setError('');
    try{
      const base=JSON.parse(baseText);
      const controls=JSON.parse(controlsText);
      setOptimized(await optimizeModelScenarios(model.model_id,{
        base_row:base,
        controls,
        objective,
        target_value:objective==='target'&&objectiveTarget.trim()?Number(objectiveTarget):null,
        max_candidates:2000,
        max_results:10,
      }));
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setOptBusy(false);}
  }

  const scenarioRows=(out?.scenarios??[]).map((x:AnyObj)=>({...x,delta_display:x.delta_pct==null?'—':`${x.delta_pct>=0?'+':''}${formatNumber(x.delta_pct,1)}%`}));
  const rcaTop=(rca?.dimension_decompositions??[]).flatMap((d:AnyObj)=>(d.top_segments??[]).slice(0,4).map((s:AnyObj)=>({dimension:d.dimension,...s}))).sort((a:AnyObj,b:AnyObj)=>Math.abs(Number(b.contribution))-Math.abs(Number(a.contribution))).slice(0,12);

  return <div className="page decision-page">
    <div className="page-title">
      <div><span className="eyebrow">ROOT CAUSE · WHAT-IF · OPTIMIZATION · MODEL EVIDENCE</span><h1>Decision Lab</h1><p>Expliquez les écarts observés, mesurez les changements de distribution et explorez des scénarios sans modifier les données originales. Les résultats décrivent des associations et le comportement des modèles, jamais une causalité garantie.</p></div>
      {model?<span className="model-badge">{model.algorithm??model.model_card?.algorithm}</span>:<span className="module-state implemented">RCA sans modèle</span>}
    </div>

    <Panel title="Root Cause Analysis — décomposition de l’écart" action={<span className="quiet">moteur déterministe</span>}>
      <div className="rca-form">
        <label>Indicateur cible<select value={rcaTarget} onChange={e=>setRcaTarget(e.target.value)}>{numericColumns.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>
        <label>Comparer selon<select value={rcaCompare} onChange={e=>setRcaCompare(e.target.value)}>{comparisonColumns.filter((c:AnyObj)=>c.name!==rcaTarget).map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>
        <label>Agrégation<select value={rcaMetric} onChange={e=>setRcaMetric(e.target.value as any)}><option value="mean">Moyenne</option><option value="sum">Somme</option><option value="count">Nombre de valeurs</option></select></label>
        <label>Granularité date<select value={rcaTimeGrain} onChange={e=>setRcaTimeGrain(e.target.value as any)}><option value="auto">Auto</option><option value="raw">Valeur brute</option><option value="day">Jour</option><option value="week">Semaine</option><option value="month">Mois</option><option value="quarter">Trimestre</option><option value="year">Année</option></select></label>
        <RunButton busy={rcaBusy} label="Identifier les facteurs" busyLabel="Décomposition…" onClick={runRca}/>
      </div>
      <div className="rca-dimensions"><span>Dimensions explicatives</span><div className="check-grid">{comparisonColumns.filter((c:AnyObj)=>c.name!==rcaCompare&&c.name!==rcaTarget).slice(0,14).map((c:AnyObj)=><label key={c.name}><input type="checkbox" checked={rcaDimensions.includes(c.name)} onChange={e=>setRcaDimensions(e.target.checked?[...rcaDimensions,c.name].slice(0,20):rcaDimensions.filter(x=>x!==c.name))}/>{c.name}</label>)}</div></div>
      <small className="help-text">Si aucune période n’est fournie explicitement, DataVision compare automatiquement les deux dernières valeurs de la variable de comparaison.</small>
    </Panel>

    {rca&&<>
      <div className="metrics four">
        <Stat label={`Baseline · ${String(rca.baseline.value)}`} value={formatNumber(rca.baseline.metric,3)}/>
        <Stat label={`Actuel · ${String(rca.current.value)}`} value={formatNumber(rca.current.metric,3)}/>
        <Stat label="Écart" value={`${Number(rca.delta)>=0?'+':''}${formatNumber(rca.delta,3)}`}/>
        <Stat label="Écart %" value={rca.delta_pct==null?'—':`${Number(rca.delta_pct)>=0?'+':''}${formatNumber(rca.delta_pct,1)}%`}/>
      </div>
      <Panel title="Principales contributions à l’écart">
        {rcaTop.length?<SimpleTable rows={rcaTop} columns={[["dimension","Dimension"],["segment","Segment"],["baseline_count","N baseline"],["current_count","N actuel"],["baseline_mean","Moy. baseline"],["current_mean","Moy. actuelle"],["contribution","Contribution"],["mix_effect","Effet mix"],["rate_effect","Effet niveau"]]}/>:<div className="quiet-empty">Aucune contribution suffisamment documentée.</div>}
      </Panel>
      <div className="two-col">
        <Panel title="Dimensions les plus discriminantes">
          <SimpleTable rows={(rca.dimension_decompositions??[]).slice(0,10)} columns={[["dimension","Dimension"],["segments_analyzed","Segments"],["top_contribution_share","Concentration top"],["absolute_contribution","Contribution absolue"],["reconciliation_error","Erreur réconciliation"]]}/>
        </Panel>
        <Panel title="Changements de distribution">
          <SimpleTable rows={(rca.feature_shifts??[]).slice(0,12).map((x:AnyObj)=>({...x,detail:x.type==='numeric'?`Δ=${formatNumber(x.delta,3)} · d=${formatNumber(x.standardized_shift,2)}`:`TVD=${formatNumber(x.tvd,2)}`}))} columns={[["feature","Variable"],["type","Type"],["score","Score shift"],["detail","Détail"]]}/>
        </Panel>
      </div>
      <div className="decision-warning">{rca.caveat}</div>
      <small className="help-text">Provenance : dataset {rca.provenance?.dataset_id} · version {rca.provenance?.dataset_version??'—'} · {rca.provenance?.calculation_engine} · granularité {rca.comparison_time_grain}</small>
    </>}

    {!model&&<div className="decision-empty compact">
      <span>⇄</span><h3>Simulation prédictive non disponible</h3><p>La Root Cause Analysis fonctionne déjà. Pour What-if, sensibilité et optimisation de scénarios, entraînez un modèle dans AutoML.</p><button className="primary-btn" onClick={()=>setView('model')}>Ouvrir AutoML</button>
    </div>}

    {model&&<>
      <div className="decision-grid">
        <Panel title="Référence"><textarea className="json-editor compact-editor" value={baseText} onChange={e=>setBaseText(e.target.value)} spellCheck={false}/></Panel>
        <Panel title="Scénarios manuels"><textarea className="json-editor compact-editor" value={scenariosText} onChange={e=>setScenariosText(e.target.value)} spellCheck={false}/><RunButton busy={busy} label="Comparer les scénarios" busyLabel="Simulation…" onClick={run}/></Panel>
      </div>

      {out&&<Panel title="Impact sur la prédiction" action={<span className="quiet">{out.target} · {out.task}</span>}><div className="decision-warning">{out.warning}</div><div className="scenario-cards">{out.scenarios.map((x:AnyObj,i:number)=><article key={i} className={i===0?'baseline':''}><span>{x.name}</span><strong>{formatNumber(x.prediction,3)}</strong>{x.delta_pct!=null&&<small className={x.delta_pct>=0?'up':'down'}>{x.delta_pct>=0?'+':''}{formatNumber(x.delta_pct,1)}%</small>}{x.probabilities&&<small>Probabilités : {x.probabilities.map((p:number)=>formatNumber(p,2)).join(' · ')}</small>}</article>)}</div><details><summary>Voir le détail des scénarios</summary><SimpleTable rows={scenarioRows} columns={[["name","Scénario"],["prediction","Prédiction"],["delta_display","Variation"]]}/></details></Panel>}

      <Panel title="Analyse de sensibilité"><div className="decision-sensitivity-form"><label>Variable<select value={feature} onChange={e=>setFeature(e.target.value)}>{features.map((f:string)=><option key={f}>{f}</option>)}</select></label><label>Minimum<input type="number" value={range.min} onChange={e=>setRange({...range,min:Number(e.target.value)})}/></label><label>Maximum<input type="number" value={range.max} onChange={e=>setRange({...range,max:Number(e.target.value)})}/></label><label>Points<input type="number" min={3} max={30} value={range.steps} onChange={e=>setRange({...range,steps:Number(e.target.value)})}/></label><RunButton busy={busy} label="Tracer la sensibilité" busyLabel="Calcul…" onClick={sens}/></div>{sensitivity&&<>{sensitivity.task==='regression'?<LineChart rows={sensitivity.points.map((p:AnyObj)=>({x:Number(p.value),y:Number(p.prediction)}))} xKey="x" yKey="y"/>:<SimpleTable rows={sensitivity.points.map((p:AnyObj)=>({value:p.value,prediction:p.prediction,probability:Math.max(...(p.probabilities??[]))}))} columns={[["value","Valeur"],["prediction","Classe"],["probability","Probabilité max"]]}/>}<small className="help-text">Courbe obtenue par inférence répétée du modèle sauvegardé, les autres variables restant à leur valeur de référence.</small></>}</Panel>

      <Panel title="Optimisation multi-scénarios">
        <div className="decision-opt-grid">
          <label>Objectif<select value={objective} onChange={e=>setObjective(e.target.value as any)}><option value="maximize">Maximiser</option><option value="minimize">Minimiser</option><option value="target">Atteindre une valeur</option></select></label>
          {objective==='target'&&<label>Valeur cible<input type="number" value={objectiveTarget} onChange={e=>setObjectiveTarget(e.target.value)}/></label>}
        </div>
        <label className="json-label">Variables contrôlables<textarea className="json-editor compact-editor" value={controlsText} onChange={e=>setControlsText(e.target.value)} spellCheck={false}/></label>
        <RunButton busy={optBusy} label="Optimiser les scénarios" busyLabel="Exploration…" onClick={optimize}/>
        <small className="help-text">Maximum 5 variables contrôlables et 5 000 combinaisons. Les valeurs sont évaluées par le modèle sauvegardé.</small>
      </Panel>

      {optimized&&<Panel title="Scénarios recommandés" action={<span className="quiet">{optimized.searched_candidates} candidats évalués</span>}>
        <div className="decision-warning">{optimized.warning}</div>
        <SimpleTable rows={(optimized.recommended_scenarios??[]).map((x:AnyObj,i:number)=>({rank:i+1,prediction:x.prediction,target_probability:x.target_probability,score:x.score,change_cost:x.change_cost,overrides:JSON.stringify(x.overrides)}))} columns={[["rank","#"],["prediction","Prédiction"],["target_probability","Proba cible"],["score","Score objectif"],["change_cost","Coût de changement"],["overrides","Variables"]]}/>
      </Panel>}
    </>}
  </div>;
}

function AIAnalystView({ result, setError, initialQuestion='' }: { result: AnyObj|null; setError:(s:string)=>void; initialQuestion?:string }) {
  const [question,setQuestion]=useState(initialQuestion||'Analyse ce dataset et identifie les principaux problèmes, relations et anomalies.');
  const [mode,setMode]=useState<'auto'|'fast'|'deep'>('auto');
  const [target,setTarget]=useState('');
  const [dateColumn,setDateColumn]=useState('');
  const [horizon,setHorizon]=useState(12);
  const [busy,setBusy]=useState(false);
  const [out,setOut]=useState<AnyObj|null>(null);
  const [capabilities,setCapabilities]=useState<AnyObj|null>(null);
  const [history,setHistory]=useState<AnyObj[]>([]);
  const [runId,setRunId]=useState('');
  const [progress,setProgress]=useState(0);
  const [stage,setStage]=useState('Prêt');
  const [currentTool,setCurrentTool]=useState('');
  const [cacheHit,setCacheHit]=useState(false);
  const [useCache,setUseCache]=useState(true);
  const streamAbort=useRef<AbortController|null>(null);

  useEffect(()=>{if(initialQuestion)setQuestion(initialQuestion);},[initialQuestion]);
  useEffect(()=>{if(!result)return; getAIAnalystCapabilities(result.dataset.id).then(setCapabilities).catch(()=>{}); getAIHistory(result.dataset.id).then(x=>setHistory(x.analyses??[])).catch(()=>{});},[result?.dataset?.id]);
  useEffect(()=>()=>{streamAbort.current?.abort();},[]);
  if(!result) return <EmptyState title="AI Analyst" text="Chargez un dataset pour lancer une analyse orchestrée en langage naturel."/>;
  const columns=result.profile.columns ?? [];

  async function refreshHistory(){
    try{const x=await getAIHistory(result!.dataset.id);setHistory(x.analyses??[]);}catch{}
  }

  async function run(){
    if(!question.trim()) return;
    streamAbort.current?.abort();
    const controller=new AbortController();
    streamAbort.current=controller;
    setBusy(true); setError(''); setOut(null); setProgress(2); setStage('Initialisation'); setCurrentTool(''); setCacheHit(false);
    try{
      const started=await startAIAnalysisRun(result!.dataset.id,{question:question.trim(),target:target||null,date_column:dateColumn||null,horizon,mode,use_cache:useCache});
      const run=started.run;
      setRunId(run.id);setProgress(Number(run.progress)||0);setStage(run.stage||'Analyse en cours');setCacheHit(Boolean(run.cached));
      if(run.status==='completed'&&run.result){
        setOut(run.result);setProgress(100);setStage(run.cached?'Résultat instantané depuis le cache':'Analyse terminée');setBusy(false);await refreshHistory();return;
      }
      await streamAIAnalysisRun(result!.dataset.id,run.id,(event)=>{
        setProgress(Number(event.progress)||0);setStage(event.stage||'Analyse en cours');setCurrentTool(event.current_tool||'');setCacheHit(Boolean(event.cached));
        if(event.status==='completed'&&event.result){setOut(event.result);setBusy(false);void refreshHistory();}
        if(event.status==='failed'){setBusy(false);setError(event.error||'AI Analyst a échoué.');}
        if(event.status==='cancelled'){setBusy(false);setStage('Analyse annulée');}
      },controller.signal);
    }catch(e:unknown){
      if(e instanceof DOMException&&e.name==='AbortError')return;
      setError(e instanceof Error?e.message:String(e));setBusy(false);
    }finally{
      if(streamAbort.current===controller)streamAbort.current=null;
    }
  }

  async function stop(){
    if(!runId)return;
    try{await cancelAIAnalysisRun(result!.dataset.id,runId);setStage('Annulation demandée…');}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{streamAbort.current?.abort();streamAbort.current=null;setBusy(false);}
  }

  const examples=[
    'Analyse ce dataset et identifie les principaux problèmes, relations et anomalies.',
    "Quel est le chiffre d'affaires par catégorie et comment évolue-t-il par mois ?",
    'Quelles sont les corrélations les plus importantes ?',
    'Détecte les anomalies dans les variables numériques.',
    'Compare les groupes et indique s’il existe une différence significative.',
    'Construis un modèle prédictif pour la variable cible.',
    'Prévois la variable cible sur les 12 prochaines périodes.'
  ];
  return <div className="page ai-analyst-page">
    <div className="page-title"><div><span className="eyebrow">AI ANALYST · STREAMING · CACHE · CANCELLATION</span><h1>AI Analyst</h1><p>Décrivez votre objectif en langage naturel. Les analyses sont exécutées par les moteurs déterministes avec progression en temps réel, déduplication des requêtes identiques et cache vérifiable.</p></div><span className="module-state implemented">orchestration accélérée</span></div>
    <div className="ai-layout">
      <section className="ai-console">
        <div className="ai-console-head"><div><b>Demande analytique</b><span>Les nombres proviennent des outils exécutables, jamais d’un LLM.</span></div><span className="ai-engine-chip">{capabilities?.engine ?? 'deterministic_orchestrator'}</span></div>
        <textarea className="ai-prompt" value={question} onChange={e=>setQuestion(e.target.value)} spellCheck={false}/>
        <div className="ai-options">
          <label>Mode<select value={mode} onChange={e=>setMode(e.target.value as any)}><option value="fast">Rapide</option><option value="auto">Auto</option><option value="deep">Approfondi</option></select></label>
          <label>Cible (optionnel)<select value={target} onChange={e=>setTarget(e.target.value)}><option value="">Détection automatique</option>{columns.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>
          <label>Date (optionnel)<select value={dateColumn} onChange={e=>setDateColumn(e.target.value)}><option value="">Détection automatique</option>{columns.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>
          <label>Horizon<input type="number" min={1} max={365} value={horizon} onChange={e=>setHorizon(Number(e.target.value))}/></label>
        </div>
        <label className="ai-cache-toggle"><input type="checkbox" checked={useCache} onChange={e=>setUseCache(e.target.checked)}/><span>Réutiliser un résultat identique si le dataset, la couche sémantique et les paramètres n’ont pas changé</span></label>
        <div className="ai-run-row"><RunButton busy={busy} label="Exécuter l’analyse" busyLabel="Analyse en cours…" onClick={run}/>{busy&&<button className="ai-stop-btn" onClick={()=>void stop()}>■ Arrêter</button>}<small>Dataset : {result.dataset.name} · version {result.dataset.version ?? 1}</small></div>
        {(busy||progress>0)&&<div className="ai-live-progress"><div className="ai-progress-head"><div><b>{stage}</b>{currentTool&&<small>{currentTool}</small>}</div><div>{cacheHit&&<span className="ai-cache-hit">CACHE</span>}<strong>{Math.min(100,Math.max(0,progress))}%</strong></div></div><div className="ai-progress-track"><i style={{width:`${Math.min(100,Math.max(0,progress))}%`}}/></div><small>{runId?`run ${runId.slice(0,8)}… · `:''}annulation coopérative entre les étapes de calcul</small></div>}
      </section>
      <aside className="ai-examples"><b>Exemples</b>{examples.map(x=><button key={x} onClick={()=>setQuestion(x)}>{x}</button>)}</aside>
    </div>
    {history.length>0&&<Panel title="Historique AI Analyst" action={<span className="quiet">{history.length} sessions</span>}><div className="analysis-history">{history.slice(0,8).map((h:AnyObj)=><button key={h.session_id} onClick={async()=>{try{setOut(await getAIHistoryItem(result!.dataset.id,h.session_id));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}}><div><b>{h.question}</b><small>{h.intent} · {h.critic_status} · v{h.dataset_version}</small></div><span>{h.executed_at?new Date(h.executed_at).toLocaleString('fr-FR'):''}</span></button>)}</div></Panel>}
    {out&&<>
      <Panel title="Réponse synthétique" action={<div className="ai-answer-meta">{out.runtime?.cache_hit&&<span className="ai-cache-hit">CACHE</span>}{out.runtime?.elapsed_ms!=null&&<span>{formatNumber(out.runtime.elapsed_ms,0)} ms</span>}<span className="ai-intent">intention : {out.intent}</span></div>}><div className="ai-answer">{out.answer}</div></Panel>
      <div className="two-col">
        <Panel title="Plan exécuté"><div className="ai-plan">{out.plan.map((p:AnyObj,i:number)=>{const exec=out.executions.find((e:AnyObj)=>e.tool===p.tool);return <div key={`${p.tool}-${i}`}><span>{String(p.step).padStart(2,'0')}</span><div><b>{p.action}</b><small>{p.tool} · {exec?.status ?? 'planned'}{exec?.duration_ms!=null?` · ${exec.duration_ms} ms`:''}</small></div><i className={exec?.status==='ok'?'ok':'bad'}>{exec?.status==='ok'?'✓':'!'}</i></div>})}</div></Panel>
        <Panel title="Critic / Validation"><div className={`critic-status ${out.critic.status}`}>{out.critic.status==='passed'?'VALIDÉ':'À VÉRIFIER'}</div><div className="critic-checks">{out.critic.checks.map((c:AnyObj)=><div key={c.check}><b>{c.passed?'✓':'!'}</b><span>{c.detail}</span></div>)}</div></Panel>
      </div>
      <Panel title="Constats vérifiables"><div className="ai-findings">{out.findings.map((f:AnyObj,i:number)=><article key={i} className={`ai-finding ${f.level}`}><div><span>{f.level}</span><b>{f.title}</b></div><p>{f.statement}</p><code>{f.evidence?.tool}</code></article>)}</div></Panel>
      <Panel title="Provenance"><div className="provenance-grid"><div><span>Dataset</span><b>{out.provenance.dataset_name}</b></div><div><span>Version</span><b>{out.provenance.dataset_version}</b></div><div><span>Calcul</span><b>{out.provenance.calculation_policy}</b></div><div><span>Outils</span><b>{(out.provenance.tools_executed??[]).join(', ')}</b></div><div><span>Semantic grounding</span><b>{out.provenance.semantic_grounding?`oui · v${out.provenance.semantic_model_version??'—'}`:'non'}</b></div></div></Panel>
      <Panel title="Résultats techniques"><details><summary>Afficher les sorties des moteurs</summary><pre className="result-json ai-json">{JSON.stringify(out.artifacts,null,2)}</pre></details></Panel>
    </>}
  </div>;
}

function ReportPreview({ report }: { report:AnyObj }) {
  const blocks=report?.blocks??[];
  return <div className="report-paper">
    <section className="report-paper-cover">
      <div className="report-paper-brand"><span>DV</span><b>DataVision AI</b></div>
      <div className="report-paper-main"><small>{report.template_label??'Rapport analytique'}</small><h2>{report.title}</h2><p>{report.subtitle}</p></div>
      <div className="report-paper-meta"><div><span>Dataset</span><b>{report.dataset?.name}</b></div><div><span>Version</span><b>v{report.dataset?.version}</b></div><div><span>Date</span><b>{report.created_at?new Date(report.created_at).toLocaleDateString('fr-FR'):'—'}</b></div></div>
      <div className="report-paper-foot"><span>{report.organization||report.author||'DataVision AI'}</span><span>{report.generation_mode==='intelligent'?'Composition intelligente · vérifiable':'Rapport reproductible'}</span></div>
    </section>
    <section className="report-paper-page report-preview-toc"><small>SOMMAIRE</small><h3>Organisation du rapport</h3>{(report.section_outline??[]).map((x:AnyObj)=><div key={x.key}><span>{String(x.number).padStart(2,'0')}</span><b>{x.title}</b></div>)}</section>
    {blocks.slice(0,5).map((block:AnyObj,i:number)=><section className="report-paper-page" key={`${block.type}-${i}`}><div className="report-preview-heading"><span>{String(i+1).padStart(2,'0')}</span><div><small>SECTION</small><h3>{block.title}</h3></div></div>
      {block.type==='executive_summary'&&<><div className="report-preview-kpis">{(block.data?.kpis??[]).map((k:AnyObj)=><div key={k.label}><span>{k.label}</span><b>{formatNumber(k.value)}</b><small>{k.hint}</small></div>)}</div><div className="report-preview-insights">{(block.data?.highlights??[]).slice(0,4).map((h:AnyObj,ix:number)=><article key={ix} className={h.level}><b>{h.title}</b><p>{h.text}</p></article>)}</div></>}
      {block.type==='analytical_story'&&<><p className="report-story-opening">{block.data?.opening}</p><div className="report-story-list">{(block.data?.findings??[]).slice(0,5).map((f:AnyObj,ix:number)=><article key={ix} className={f.severity}><span>{String(f.rank??ix+1).padStart(2,'0')}</span><div><b>{f.title}</b><p>{f.statement}</p><small>{f.interpretation}</small></div></article>)}</div><div className="report-story-conclusion"><span>Conclusion</span><p>{block.data?.conclusion}</p></div></>}
      {block.type==='story_page'&&<><div className="story-preview-meta"><span>PAGE {String(block.data?.page_number??i+1).padStart(2,'0')}</span><span>{String(block.data?.role??'story').toUpperCase()}</span><span>preuve {Math.round(Number(block.data?.proof_coverage??0)*100)}%</span></div><p className="report-story-opening">{block.data?.summary}</p><div className="story-preview-claims">{(block.data?.claims??[]).slice(0,5).map((c:AnyObj,ix:number)=><article key={ix}><b>{c.text}</b><small>{(c.evidence_ids??[]).join(' · ')||'Aucune preuve liée'}</small></article>)}</div>{block.data?.takeaway&&<div className="report-story-conclusion"><span>À retenir</span><p>{block.data.takeaway}</p></div>}</>}
      {block.type==='overview'&&<div className="report-preview-kpis"><div><span>Observations</span><b>{formatNumber(block.data?.rows)}</b></div><div><span>Variables</span><b>{formatNumber(block.data?.columns)}</b></div><div><span>Doublons</span><b>{formatNumber(block.data?.duplicates)}</b></div><div><span>Qualité</span><b>{formatNumber(block.data?.quality_score)}/100</b></div></div>}
      {block.type==='quality'&&<div className="report-preview-quality"><div><b>{formatNumber(block.data?.score)}</b><span>/100</span></div><p>{block.data?.issues_count??0} problème(s) détecté(s), avec recommandations et niveau de sévérité.</p></div>}
      {block.type==='table'&&<div className="report-preview-table">{(block.rows??[]).slice(0,4).map((r:AnyObj,ix:number)=><div key={ix}><b>{String(r[(block.columns??[])[0]]??r.variable??`Ligne ${ix+1}`)}</b><span>{(block.columns??[]).slice(1,4).map((c:string)=>`${c}: ${String(r[c]??'—')}`).join(' · ')}</span></div>)}</div>}
      {block.type==='text'&&<p className="report-story-opening">{block.text}</p>}
      {block.type==='kpi'&&<div className="report-preview-kpis">{(block.items??[]).map((k:AnyObj)=><div key={k.label}><span>{k.label}</span><b>{String(k.value??'—')}</b><small>{k.hint}</small></div>)}</div>}
      {block.type==='insight'&&<article className={`report-preview-insight ${block.data?.severity??'info'}`}><b>{block.data?.title}</b><p>{block.data?.statement}</p><small>Priorité {block.data?.priority_score??'—'}/100 · méthode {block.data?.calculation?.method??'—'}</small></article>}
      {block.type==='model'&&<div className="report-preview-quality"><div><b>{block.data?.algorithm??'Modèle'}</b><span>{block.data?.task??''}</span></div><p>Cible : {block.data?.target??'—'} · ID {block.data?.model_id??'—'}</p></div>}
      {block.type==='code'&&<pre className="result-json"><code>{block.code}</code>{block.output&&`\n\n# Sortie\n${block.output}`}</pre>}
      {block.type==='visualizations'&&<div className="report-preview-figures">{(block.items??[]).slice(0,4).map((v:AnyObj)=><div key={v.id}><span>{v.source==='auto_report'?'FIGURE AUTO':'FIGURE'}</span><b>{v.title}</b><small>{v.visualization?.type}</small>{v.insight&&<p>{v.insight}</p>}</div>)}</div>}
      {block.type==='ai_analysis'&&<><div className="report-preview-question"><span>Question analytique</span><b>{block.data?.question}</b></div><p className="report-preview-answer">{block.data?.answer}</p></>}
      {block.type==='limitations'&&<div className="report-preview-limits">{(block.items??[]).slice(0,5).map((x:AnyObj,ix:number)=><article key={ix}><b>{x.title}</b><p>{x.text}</p><small>{x.mitigation}</small></article>)}</div>}
      {block.type==='methodology'&&<div className="report-preview-methods">{(block.items??[]).slice(0,5).map((x:string,ix:number)=><div key={ix}><span>{String(ix+1).padStart(2,'0')}</span><p>{x}</p></div>)}</div>}
      {block.type==='provenance'&&<div className="report-preview-provenance">{Object.entries(block.data??{}).slice(0,8).map(([k,v])=><div key={k}><span>{k}</span><b>{String(v??'—')}</b></div>)}</div>}
    </section>)}
    {blocks.length>5&&<div className="report-preview-more">+ {blocks.length-5} autres section(s) dans le rapport exporté</div>}
  </div>;
}


function dashboardId(){ return typeof crypto!=='undefined'&&'randomUUID' in crypto ? crypto.randomUUID() : `w-${Date.now()}-${Math.random().toString(16).slice(2)}`; }

function DashboardWidgetBody({item,onCrossFilter,onDrill}:{item:AnyObj;onCrossFilter:(ref:string,value:any,semantic?:boolean)=>void;onDrill:(widgetId:string,dimension:string,value:any,nextLevel:number)=>void}){
  if(item.status==='error') return <div className="widget-error">{item.error}</div>;
  const r=item.result;
  if(!r) return <div className="quiet-empty">Actualisez le dashboard.</div>;
  if(r.type==='kpi') return <div className={`dashboard-kpi-widget ${r.semantic?'semantic-kpi':''}`}><strong>{formatNumber(r.value,3)}{r.unit?` ${r.unit}`:''}</strong><span>{r.detail}</span>{r.semantic&&<small>◈ métrique gouvernée</small>}</div>;
  if(r.type==='text') return <div className="dashboard-text-widget">{r.text||'Texte libre'}</div>;
  if(r.type==='bar'){
    const vals=(r.data??[]).map((x:AnyObj)=>Number(x.value)||0),max=Math.max(1,...vals);
    const canDrill=!!(r.semantic&&r.drill?.next_dimension&&r.drill?.next_level!=null);
    return <div className="bar-chart interactive-bars">{(r.data??[]).map((x:AnyObj,i:number)=><button key={i} className="bar-row" onClick={()=>canDrill?onDrill(item.id,r.drill.dimension,x.label,Number(r.drill.next_level)):r.x&&onCrossFilter(r.x,x.label,!!r.semantic)} title={canDrill?`Drill-down vers ${r.drill.next_dimension}`:'Cliquer pour filtrer le dashboard'}><span>{String(x.label)}</span><div><i style={{width:`${Math.max(1,(Number(x.value)||0)/max*100)}%`}}/></div><b>{formatNumber(x.value,2)}</b></button>)}{r.semantic&&<small className="semantic-widget-foot">◈ {r.metric_label}{canDrill?` · drill → ${r.drill.next_dimension}`:''}</small>}</div>;
  }
  if((r.type==='line'||r.type==='area')&&r.semantic){
    return <div className="semantic-viz-wrap"><VizRenderer viz={r}/><small className="semantic-widget-foot">◈ {r.metric_label} · {r.query?.time_grain??'semantic'}</small></div>;
  }
  return <VizRenderer viz={r}/>;
}

function DashboardBuilder({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const cols=result?.profile?.columns??[];
  const rows=Number(result?.profile?.rows??0);
  const useful=cols.filter((c:AnyObj)=>!isLikelyIdentifier(c,rows));
  const nums=useful.filter(isNumeric);
  const cats=useful.filter((c:AnyObj)=>!isNumeric(c));
  const [semantic,setSemantic]=useState<AnyObj|null>(null);
  const [saved,setSaved]=useState<AnyObj[]>([]);
  const [currentId,setCurrentId]=useState('');
  const [name,setName]=useState('Dashboard analytique');
  const [description,setDescription]=useState('Vue décisionnelle interactive');
  const [filters,setFilters]=useState<AnyObj[]>([]);
  const [widgets,setWidgets]=useState<AnyObj[]>([]);
  const [preview,setPreview]=useState<AnyObj|null>(null);
  const [selectedId,setSelectedId]=useState('');
  const [busy,setBusy]=useState(false);
  const [dragId,setDragId]=useState('');
  const [fColumn,setFColumn]=useState('');
  const [fOperator,setFOperator]=useState('eq');
  const [fValue,setFValue]=useState('');
  const [fValue2,setFValue2]=useState('');

  const semanticMetrics=(semantic?.metrics??[]).filter((m:AnyObj)=>m.certified||semantic?.status==='governed');
  const semanticDims=(semantic?.dimensions??[]).filter((d:AnyObj)=>!d.hidden);
  const semanticHierarchies=semantic?.hierarchies??[];

  function defaults(semModel:AnyObj|null=semantic){
    const firstNum=nums[0]?.name??''; const secondNum=nums[1]?.name??''; const firstCat=cats[0]?.name??'';
    const dateGuess=useful.find((c:AnyObj)=>/date|time|timestamp|annee|year|mois|month/i.test(String(c.name)))?.name??'';
    const out:AnyObj[]=[
      {id:dashboardId(),title:'Observations',type:'kpi',size:'small',config:{metric:'rows'}},
      {id:dashboardId(),title:'Qualité',type:'kpi',size:'small',config:{metric:'quality_score'}},
    ];
    const sm=(semModel?.metrics??[]).filter((m:AnyObj)=>m.certified);
    const sd=(semModel?.dimensions??[]).filter((d:AnyObj)=>!d.hidden);
    if(sm[0]) out.push({id:dashboardId(),title:sm[0].label||sm[0].name||sm[0].id,type:'semantic_kpi',size:'small',config:{metric_id:sm[0].id}});
    if(sm[0]&&sd.find((d:AnyObj)=>d.kind!=='date')){const d=sd.find((x:AnyObj)=>x.kind!=='date');out.push({id:dashboardId(),title:`${sm[0].label||sm[0].id} par ${d.label||d.id}`,type:'semantic_chart',size:'medium',config:{metric_id:sm[0].id,dimension:d.id,chart_type:'bar',limit:30}});}
    out.push({id:dashboardId(),title:'Valeurs manquantes',type:'kpi',size:'small',config:{metric:'missing_cells'}});
    if(firstCat&&firstNum) out.push({id:dashboardId(),title:`${firstNum} par ${firstCat}`,type:'chart',size:'medium',config:{chart_type:'bar',x:firstCat,y:firstNum,aggregation:'mean',bins:20}});
    if(firstNum) out.push({id:dashboardId(),title:`Distribution de ${firstNum}`,type:'chart',size:'medium',config:{chart_type:'histogram',x:firstNum,y:null,aggregation:'none',bins:20}});
    if(dateGuess&&firstNum) out.push({id:dashboardId(),title:`Évolution de ${firstNum}`,type:'chart',size:'large',config:{chart_type:'line',x:dateGuess,y:firstNum,aggregation:'mean',bins:20}});
    return out;
  }

  async function loadList(){ if(!result)return; try{const r=await getDashboards(result.dataset.id);setSaved(r.dashboards??[]);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));} }
  async function refresh(nextFilters=filters,nextWidgets=widgets){ if(!result)return;setBusy(true);setError('');try{setPreview(await previewDashboard(result.dataset.id,{filters:nextFilters,widgets:nextWidgets}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);} }
  function startNew(){ const w=defaults();setCurrentId('');setName('Dashboard analytique');setDescription('Vue décisionnelle interactive');setFilters([]);setWidgets(w);setSelectedId(w[0]?.id??'');setPreview(null);if(result)setTimeout(()=>refresh([],w),0); }
  async function loadOne(id:string){ if(!result||!id)return;setBusy(true);try{const r=await getDashboardDefinition(result.dataset.id,id);const d=r.dashboard;setCurrentId(d.id);setName(d.name);setDescription(d.description??'');setFilters(d.filters??[]);setWidgets(d.widgets??[]);setSelectedId(d.widgets?.[0]?.id??'');await refresh(d.filters??[],d.widgets??[]);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);} }
  async function save(){ if(!result)return;setBusy(true);setError('');try{const r=await saveDashboardDefinition(result.dataset.id,{dashboard_id:currentId||null,name,description,filters,widgets});setCurrentId(r.dashboard.id);await loadList();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);} }
  async function removeDashboard(){ if(!result||!currentId)return;setBusy(true);try{await deleteDashboardDefinition(result.dataset.id,currentId);await loadList();startNew();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);} }

  useEffect(()=>{if(!result){setSaved([]);setWidgets([]);setPreview(null);setSemantic(null);return;}loadList();getSemanticModel(result.dataset.id).then(sem=>{setSemantic(sem);const dims=(sem.dimensions??[]).filter((d:AnyObj)=>!d.hidden);setFColumn(dims[0]?`sem::${dims[0].id}`:(useful[0]?.name??cols[0]?.name??''));const w=defaults(sem);setWidgets(w);setSelectedId(w[0]?.id??'');setFilters([]);setCurrentId('');setTimeout(()=>refresh([],w),0);}).catch(()=>{setSemantic(null);setFColumn(useful[0]?.name??cols[0]?.name??'');const w=defaults(null);setWidgets(w);setSelectedId(w[0]?.id??'');setTimeout(()=>refresh([],w),0);});},[result?.dataset?.id]);

  if(!result)return <EmptyState title="Dashboards" text="Chargez un dataset pour construire un tableau de bord interactif."/>;

  function addWidget(kind:string){
    const firstNum=nums[0]?.name??''; const secondNum=nums[1]?.name??''; const firstCat=cats[0]?.name??'';
    let w:AnyObj={id:dashboardId(),title:'Nouveau widget',type:'chart',size:'medium',config:{chart_type:kind,x:firstCat||firstNum,y:firstNum||null,aggregation:firstCat&&firstNum?'mean':'none',bins:20}};
    if(kind==='kpi') w={id:dashboardId(),title:'Indicateur',type:'kpi',size:'small',config:{metric:'rows'}};
    if(kind==='text') w={id:dashboardId(),title:'Note',type:'text',size:'medium',config:{text:'Ajoutez votre commentaire ou votre interprétation.'}};
    if(kind==='semantic_kpi'){const m=semanticMetrics[0];w={id:dashboardId(),title:m?.label??'Métrique métier',type:'semantic_kpi',size:'small',config:{metric_id:m?.id??''}};}
    if(kind==='semantic_chart'){const m=semanticMetrics[0],d=semanticDims.find((x:AnyObj)=>x.kind!=='date')??semanticDims[0];w={id:dashboardId(),title:`${m?.label??'Métrique'} par ${d?.label??'dimension'}`,type:'semantic_chart',size:'medium',config:{metric_id:m?.id??'',dimension:d?.id??'',chart_type:'bar',limit:30,hierarchy_id:'',hierarchy_level:0,comparison:'none',time_calculation:'none'}};}
    if(kind==='histogram') w.config={chart_type:'histogram',x:firstNum,y:null,aggregation:'none',bins:20};
    if(kind==='scatter') w.config={chart_type:'scatter',x:firstNum,y:secondNum,aggregation:'none',bins:20};
    if(kind==='heatmap') w.config={chart_type:'heatmap',x:null,y:null,aggregation:'none',bins:20};
    if(kind==='line') w.config={chart_type:'line',x:firstCat||firstNum,y:firstNum,aggregation:'mean',bins:20};
    const next=[...widgets,w];setWidgets(next);setSelectedId(w.id);setTimeout(()=>refresh(filters,next),0);
  }
  function patchWidget(id:string,patch:AnyObj){setWidgets(prev=>prev.map(w=>w.id===id?{...w,...patch}:w));}
  function patchConfig(id:string,patch:AnyObj){setWidgets(prev=>prev.map(w=>w.id===id?{...w,config:{...(w.config??{}),...patch}}:w));}
  function deleteWidget(id:string){const next=widgets.filter(w=>w.id!==id);setWidgets(next);if(selectedId===id)setSelectedId(next[0]?.id??'');setTimeout(()=>refresh(filters,next),0);}
  function dropOn(target:string){if(!dragId||dragId===target)return;const next=[...widgets];const a=next.findIndex(w=>w.id===dragId),b=next.findIndex(w=>w.id===target);if(a<0||b<0)return;const [m]=next.splice(a,1);next.splice(b,0,m);setWidgets(next);setDragId('');}
  function addFilter(){if(!fColumn)return;const semanticRef=fColumn.startsWith('sem::');const ref=semanticRef?fColumn.slice(5):fColumn;const f={id:dashboardId(),...(semanticRef?{dimension:ref,source:'semantic'}:{column:ref}),operator:fOperator,value:fValue,value2:fValue2};const next=[...filters,f];setFilters(next);setFValue('');setFValue2('');setTimeout(()=>refresh(next,widgets),0);}
  function removeFilter(id:string){const next=filters.filter(f=>f.id!==id);setFilters(next);setTimeout(()=>refresh(next,widgets),0);}
  function crossFilter(ref:string,value:any,isSemantic=false){const without=filters.filter(f=>!(f.source==='cross'&&((isSemantic&&f.dimension===ref)||(!isSemantic&&f.column===ref))));const next=[...without,{id:dashboardId(),source:'cross',...(isSemantic?{dimension:ref}:{column:ref}),operator:'eq',value}];setFilters(next);setTimeout(()=>refresh(next,widgets),0);}
  function drill(widgetId:string,dimension:string,value:any,nextLevel:number){const nextFilters=[...filters.filter(f=>!(f.source==='drill'&&f.dimension===dimension)),{id:dashboardId(),source:'drill',dimension,operator:'eq',value}];const nextWidgets=widgets.map(w=>w.id===widgetId?{...w,config:{...(w.config??{}),hierarchy_level:nextLevel}}:w);setFilters(nextFilters);setWidgets(nextWidgets);setTimeout(()=>refresh(nextFilters,nextWidgets),0);}
  function resetDrill(widgetId:string){const w=widgets.find(x=>x.id===widgetId);const hierarchyId=w?.config?.hierarchy_id;const h=semanticHierarchies.find((x:AnyObj)=>x.id===hierarchyId);const levels=h?.levels??[];const nextFilters=filters.filter(f=>!(f.source==='drill'&&levels.includes(f.dimension)));const nextWidgets=widgets.map(x=>x.id===widgetId?{...x,config:{...(x.config??{}),hierarchy_level:0}}:x);setFilters(nextFilters);setWidgets(nextWidgets);setTimeout(()=>refresh(nextFilters,nextWidgets),0);}
  const selected=widgets.find(w=>w.id===selectedId);
  const renderedById=new Map((preview?.widgets??[]).map((w:AnyObj)=>[w.id,w]));

  return <div className="page dashboard-builder-page"><div className="page-title"><div><span className="eyebrow">SEMANTIC DASHBOARD BUILDER · V2.4</span><h1>Tableau de bord gouverné</h1><p>Combinez KPI physiques et métriques métier multi-tables, filtres synchronisés et drill-down hiérarchique sans exposer les jointures.</p></div><div className="dashboard-semantic-badges"><span className="module-state implemented">cross-filter</span>{semantic?.status==='governed'&&<span className="module-state implemented">◈ semantic v{semantic.version}</span>}</div></div>
    <div className="dashboard-toolbar"><select value={currentId} onChange={e=>e.target.value?loadOne(e.target.value):startNew()}><option value="">Nouveau dashboard</option>{saved.map(d=><option key={d.id} value={d.id}>{d.name} · v{d.dataset_version}</option>)}</select><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nom du dashboard"/><input value={description} onChange={e=>setDescription(e.target.value)} placeholder="Description"/><button className="secondary-btn" onClick={startNew}>Nouveau</button><button className="primary-btn real-button" disabled={busy} onClick={save}>{busy?'Traitement…':'Enregistrer'}</button><button className="secondary-btn" disabled={!currentId||busy} onClick={removeDashboard}>Supprimer</button><button className="secondary-btn" disabled={busy} onClick={()=>refresh()}>↻ Actualiser</button></div>
    <div className="dashboard-filter-panel"><div className="dashboard-filter-head"><div><b>Filtres globaux</b><small>{preview?`${preview.rows_after}/${preview.rows_before} lignes de faits visibles · ${preview.semantic_widgets??0} widget(s) sémantique(s)`:'Tous les enregistrements'}</small></div><div className="dashboard-filter-form"><select value={fColumn} onChange={e=>setFColumn(e.target.value)}><optgroup label="Dimensions métier">{semanticDims.map((d:AnyObj)=><option key={d.id} value={`sem::${d.id}`}>◈ {d.label||d.id}</option>)}</optgroup><optgroup label="Colonnes physiques">{useful.map((c:AnyObj)=><option key={c.name} value={c.name}>{c.name}</option>)}</optgroup></select><select value={fOperator} onChange={e=>setFOperator(e.target.value)}><option value="eq">=</option><option value="neq">≠</option><option value="contains">contient</option><option value="gt">&gt;</option><option value="gte">≥</option><option value="lt">&lt;</option><option value="lte">≤</option><option value="between">entre</option><option value="is_null">est vide</option><option value="not_null">non vide</option></select>{!['is_null','not_null'].includes(fOperator)&&<input value={fValue} onChange={e=>setFValue(e.target.value)} placeholder="Valeur"/>}{fOperator==='between'&&<input value={fValue2} onChange={e=>setFValue2(e.target.value)} placeholder="Valeur 2"/>}<button onClick={addFilter}>＋ Filtrer</button></div></div><div className="filter-chips">{filters.map(f=><button key={f.id} onClick={()=>removeFilter(f.id)} title="Retirer le filtre"><b>{f.dimension?`◈ ${f.dimension}`:f.column}</b> {f.operator} {String(f.value??'')} {f.value2?`→ ${f.value2}`:''}<span>×</span></button>)}{!filters.length&&<small>Aucun filtre actif. Les dimensions liées peuvent filtrer tout le dashboard via la couche sémantique.</small>}</div></div>
    <div className="dashboard-builder-layout"><aside className="dashboard-builder-side"><Panel title="Ajouter un widget"><div className="widget-palette"><button className="semantic-palette" onClick={()=>addWidget('semantic_kpi')}>◈ <span>KPI métier</span></button><button className="semantic-palette" onClick={()=>addWidget('semantic_chart')}>◇ <span>Graphe métier</span></button><button onClick={()=>addWidget('kpi')}>123 <span>KPI brut</span></button><button onClick={()=>addWidget('bar')}>▥ <span>Barres</span></button><button onClick={()=>addWidget('line')}>⌁ <span>Courbe</span></button><button onClick={()=>addWidget('histogram')}>▤ <span>Histogramme</span></button><button onClick={()=>addWidget('scatter')}>⠿ <span>Scatter</span></button><button onClick={()=>addWidget('heatmap')}>▦ <span>Heatmap</span></button><button onClick={()=>addWidget('text')}>T <span>Texte</span></button></div></Panel>
      <Panel title="Propriétés">{!selected?<div className="quiet-empty">Sélectionnez un widget.</div>:<div className="widget-properties"><label>Titre<input value={selected.title??''} onChange={e=>patchWidget(selected.id,{title:e.target.value})}/></label><label>Taille<select value={selected.size??'medium'} onChange={e=>patchWidget(selected.id,{size:e.target.value})}><option value="small">Petite</option><option value="medium">Moyenne</option><option value="large">Large</option><option value="full">Pleine largeur</option></select></label>{selected.type==='semantic_kpi'&&<label>Métrique métier<select value={selected.config?.metric_id??''} onChange={e=>patchConfig(selected.id,{metric_id:e.target.value})}>{semanticMetrics.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.certified?'✓ ':''}{m.label||m.name||m.id}</option>)}</select></label>}{selected.type==='semantic_chart'&&<><label>Métrique métier<select value={selected.config?.metric_id??''} onChange={e=>patchConfig(selected.id,{metric_id:e.target.value})}>{semanticMetrics.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.certified?'✓ ':''}{m.label||m.id}</option>)}</select></label><label>Hiérarchie<select value={selected.config?.hierarchy_id??''} onChange={e=>patchConfig(selected.id,{hierarchy_id:e.target.value,hierarchy_level:0})}><option value="">Aucune</option>{semanticHierarchies.map((h:AnyObj)=><option key={h.id} value={h.id}>{h.name}</option>)}</select></label>{!selected.config?.hierarchy_id&&<label>Dimension<select value={selected.config?.dimension??''} onChange={e=>patchConfig(selected.id,{dimension:e.target.value})}>{semanticDims.map((d:AnyObj)=><option key={d.id} value={d.id}>{d.label||d.id}</option>)}</select></label>}{selected.config?.hierarchy_id&&<button className="secondary-btn" onClick={()=>resetDrill(selected.id)}>↺ Revenir au niveau 1</button>}<label>Graphique<select value={selected.config?.chart_type??'bar'} onChange={e=>patchConfig(selected.id,{chart_type:e.target.value})}><option value="bar">Barres</option><option value="line">Courbe</option><option value="area">Aire</option></select></label><label>Dimension temporelle<select value={selected.config?.date_dimension??''} onChange={e=>patchConfig(selected.id,{date_dimension:e.target.value})}><option value="">Aucune</option>{semanticDims.filter((d:AnyObj)=>d.kind==='date').map((d:AnyObj)=><option key={d.id} value={d.id}>{d.label||d.id}</option>)}</select></label>{selected.config?.date_dimension&&<><label>Grain<select value={selected.config?.time_grain??'month'} onChange={e=>patchConfig(selected.id,{time_grain:e.target.value})}><option value="day">Jour</option><option value="week">Semaine</option><option value="month">Mois</option><option value="quarter">Trimestre</option><option value="year">Année</option></select></label><label>Comparaison<select value={selected.config?.comparison??'none'} onChange={e=>patchConfig(selected.id,{comparison:e.target.value})}><option value="none">Aucune</option><option value="previous_period">Période précédente</option><option value="yoy">YoY</option></select></label></>}</>}{selected.type==='kpi'&&<><label>Métrique<select value={selected.config?.metric??'rows'} onChange={e=>patchConfig(selected.id,{metric:e.target.value})}><option value="rows">Nombre de lignes</option><option value="quality_score">Score qualité</option><option value="missing_cells">Cellules manquantes</option><option value="duplicates">Doublons</option><option value="mean">Moyenne</option><option value="sum">Somme</option><option value="median">Médiane</option><option value="nunique">Valeurs uniques</option><option value="missing_pct">% manquant</option></select></label>{!['rows','quality_score','missing_cells','duplicates'].includes(selected.config?.metric??'rows')&&<label>Colonne<select value={selected.config?.column??nums[0]?.name??''} onChange={e=>patchConfig(selected.id,{column:e.target.value})}>{useful.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}</>}{selected.type==='chart'&&<><label>Graphique<select value={selected.config?.chart_type??'bar'} onChange={e=>patchConfig(selected.id,{chart_type:e.target.value})}><option value="bar">Barres</option><option value="line">Courbe</option><option value="area">Aire</option><option value="histogram">Histogramme</option><option value="density">Densité</option><option value="scatter">Scatter</option><option value="box">Boxplot</option><option value="heatmap">Heatmap</option></select></label>{!['heatmap'].includes(selected.config?.chart_type)&&<label>Axe X<select value={selected.config?.x??''} onChange={e=>patchConfig(selected.id,{x:e.target.value})}><option value="">—</option>{useful.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}{!['histogram','density','heatmap'].includes(selected.config?.chart_type)&&<label>Axe Y<select value={selected.config?.y??''} onChange={e=>patchConfig(selected.id,{y:e.target.value||null})}><option value="">—</option>{useful.map((c:AnyObj)=><option key={c.name}>{c.name}</option>)}</select></label>}{['bar','line','area'].includes(selected.config?.chart_type)&&<label>Agrégation<select value={selected.config?.aggregation??'none'} onChange={e=>patchConfig(selected.id,{aggregation:e.target.value})}><option value="count">Count</option><option value="mean">Moyenne</option><option value="sum">Somme</option><option value="median">Médiane</option><option value="min">Minimum</option><option value="max">Maximum</option></select></label>}</>}{selected.type==='text'&&<label>Texte<textarea value={selected.config?.text??''} onChange={e=>patchConfig(selected.id,{text:e.target.value})}/></label>}<div className="button-row"><button className="secondary-btn" onClick={()=>refresh()}>Appliquer</button><button className="danger-btn" onClick={()=>deleteWidget(selected.id)}>Supprimer</button></div></div>}</Panel></aside>
      <section className="dashboard-canvas"><div className="dashboard-canvas-head"><div><b>{name}</b><span>{description}</span></div><small>Les widgets ◈ utilisent le modèle sémantique · clic sur une hiérarchie = drill-down</small></div><div className="dashboard-widget-grid">{widgets.map(w=>{const rendered=renderedById.get(w.id) as AnyObj|undefined;return <article key={w.id} draggable onDragStart={()=>setDragId(w.id)} onDragOver={e=>e.preventDefault()} onDrop={()=>dropOn(w.id)} className={`dashboard-widget size-${w.size??'medium'} ${selectedId===w.id?'selected':''} ${w.type.startsWith('semantic_')?'semantic-widget':''}`} onClick={()=>setSelectedId(w.id)}><header><div><span className="widget-grip">⠿</span><b>{w.title}</b></div><small>{w.type.startsWith('semantic_')?'◈ métier':w.type==='chart'?(w.config?.chart_type??'chart'):w.type}</small></header><div className="dashboard-widget-body"><DashboardWidgetBody item={rendered??{...w,status:'pending'}} onCrossFilter={crossFilter} onDrill={drill}/></div></article>})}</div></section></div>
  </div>;
}

function ReportView({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const [title,setTitle]=useState('Rapport DataVision');
  const [subtitle,setSubtitle]=useState('Analyse de données et aide à la décision');
  const [author,setAuthor]=useState('DataVision AI');
  const [organization,setOrganization]=useState('');
  const [template,setTemplate]=useState<'executive'|'analytical'|'technical'>('analytical');
  const [sections,setSections]=useState<string[]>(['executive_summary','analytical_story','overview','quality','descriptive','visualizations','ai_analysis','limitations','methodology','provenance']);
  const [autoStory,setAutoStory]=useState(true); const [autoVisuals,setAutoVisuals]=useState(true); const [maxVisuals,setMaxVisuals]=useState(6);
  const [analyses,setAnalyses]=useState<AnyObj[]>([]); const [analysisId,setAnalysisId]=useState(''); const [reports,setReports]=useState<AnyObj[]>([]); const [savedVisuals,setSavedVisuals]=useState<AnyObj[]>([]); const [visualIds,setVisualIds]=useState<string[]>([]); const [created,setCreated]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false);
  const [customBlocks,setCustomBlocks]=useState<AnyObj[]>([]); const [validation,setValidation]=useState<AnyObj|null>(null);
  const [storyAudience,setStoryAudience]=useState<'executive'|'operations'|'analyst'|'general'>('executive');
  const [storyObjective,setStoryObjective]=useState('Comprendre les faits saillants et soutenir une décision traçable.');
  const [storyTone,setStoryTone]=useState<'concise'|'balanced'|'detailed'>('balanced'); const [storyMaxPages,setStoryMaxPages]=useState(6); const [storyPreview,setStoryPreview]=useState<AnyObj|null>(null);
  const [publication,setPublication]=useState<AnyObj|null>(null); const [publishVisibility,setPublishVisibility]=useState<'private'|'workspace'|'external'>('workspace');
  const choices=[['executive_summary','Synthèse exécutive'],['analytical_story','Résultats clés & lecture'],['overview','Vue d’ensemble'],['quality','Qualité des données'],['descriptive','Statistiques descriptives'],['visualizations','Analyses visuelles'],['ai_analysis','AI Analyst'],['limitations','Limites & précautions'],['methodology','Méthodologie'],['provenance','Provenance']];
  const templates:{key:'executive'|'analytical'|'technical';title:string;text:string;sections:string[]}[]=[
    {key:'executive',title:'Exécutif',text:'Court, orienté décision, résultats clés et graphiques essentiels.',sections:['executive_summary','analytical_story','visualizations','limitations','methodology','provenance']},
    {key:'analytical',title:'Analytique',text:'Complet, narratif, équilibré entre statistiques, graphiques et interprétation.',sections:['executive_summary','analytical_story','overview','quality','descriptive','visualizations','ai_analysis','limitations','methodology','provenance']},
    {key:'technical',title:'Technique',text:'Détaillé, orienté audit, limites, méthodes et reproductibilité.',sections:['overview','quality','descriptive','visualizations','ai_analysis','analytical_story','limitations','methodology','provenance']},
  ];
  async function refresh(){if(!result)return; try{const [a,r,v]=await Promise.all([getAIHistory(result.dataset.id),getReports(result.dataset.id),getSavedVisualizations(result.dataset.id)]);setAnalyses(a.analyses??[]);setReports(r.reports??[]);const current=(v.visualizations??[]).filter((x:AnyObj)=>Number(x.dataset_version)===Number(result.dataset.version??1));setSavedVisuals(current);setVisualIds(prev=>prev.length?prev:current.map((x:AnyObj)=>x.id));if(!analysisId&&a.analyses?.[0]?.session_id)setAnalysisId(a.analyses[0].session_id);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  useEffect(()=>{setCreated(null);setPublication(null);setStoryPreview(null);setVisualIds([]);refresh();},[result?.dataset?.id]);
  if(!result)return <EmptyState title="Rapports" text="Chargez un dataset pour construire un rapport reproductible."/>;
  function chooseTemplate(next:'executive'|'analytical'|'technical'){setTemplate(next);const t=templates.find(x=>x.key===next);if(t)setSections(t.sections);}
  function addReportBlock(type:string){const id=`custom:${Date.now()}-${Math.random().toString(36).slice(2,7)}`;const defaults:Record<string,AnyObj>={text:{text:'Ajoutez votre commentaire métier.'},kpi:{items:[{label:'KPI',value:0,hint:''}]},table:{columns:['indicateur','valeur'],rows:[{indicateur:'Exemple',valeur:0}]},insight:{insight_id:''},model:{model_id:''},code:{language:'python',code:'# Code documenté, non exécuté par le Report Builder',output:''},methodology:{items:['Décrire ici la méthode ou l’hypothèse.']},visualization:{visualization_id:savedVisuals[0]?.id??''}};setCustomBlocks(prev=>[...prev,{id,type,title:type==='kpi'?'Indicateurs':type==='insight'?'Insight':type==='model'?'Modèle':type==='code'?'Code':type==='methodology'?'Méthodologie':type==='visualization'?'Figure':'Texte',payload:JSON.stringify(defaults[type]??{},null,2)}]);}
  function patchReportBlock(id:string,patch:AnyObj){setCustomBlocks(prev=>prev.map(b=>b.id===id?{...b,...patch}:b));}
  function moveReportBlock(id:string,delta:number){setCustomBlocks(prev=>{const next=[...prev];const i=next.findIndex(b=>b.id===id);const j=i+delta;if(i<0||j<0||j>=next.length)return prev;[next[i],next[j]]=[next[j],next[i]];return next;});}
  function removeReportBlock(id:string){setCustomBlocks(prev=>prev.filter(b=>b.id!==id));}
  async function previewStory(){if(!result)return;setBusy(true);setError('');try{setStoryPreview(await previewStorytelling(result.dataset.id,{audience:storyAudience,objective:storyObjective,tone:storyTone,max_pages:storyMaxPages,analysis_session_id:analysisId||null,visualization_ids:visualIds}));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function publishCurrent(){if(!result||!created)return;setBusy(true);setError('');try{const pub=await publishReport(result.dataset.id,created.id,{visibility:publishVisibility,channel:'report_studio'});setPublication(pub);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function create(){setBusy(true);setError('');try{const parsed=customBlocks.map(b=>{let cfg:AnyObj={};try{cfg=JSON.parse(b.payload||'{}');}catch{throw new Error(`Configuration JSON invalide pour le bloc ${b.title}`);}return {id:b.id,type:b.type,title:b.title,...cfg};});const order=[...sections.map(x=>`section:${x}`),...customBlocks.map(x=>x.id)];const r=await createReport(result!.dataset.id,{title,subtitle,author,organization,template,sections,analysis_session_id:analysisId||null,visualization_ids:visualIds,auto_story:autoStory,auto_visualizations:autoVisuals,max_visualizations:maxVisuals,story_audience:storyAudience,story_objective:storyObjective,story_tone:storyTone,story_max_pages:storyMaxPages,custom_blocks:parsed,block_order:order});setCreated(r);setPublication(await getReportPublication(result!.dataset.id,r.id));setStoryPreview(r.story_blueprint??storyPreview);setValidation(await validateReport(result!.dataset.id,r.id));await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
  async function dl(reportId:string,format:'pdf'|'docx'|'html'|'md'){try{await downloadReport(result!.dataset.id,reportId,format);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  return <div className="page report-studio"><div className="page-title"><div><span className="eyebrow">PROFESSIONAL REPORT STUDIO</span><h1>Rapports</h1><p>Composez un rapport narratif, hiérarchisé et vérifiable, avec sélection intelligente des graphiques et limites explicites.</p></div><span className="module-state implemented">Report Intelligence</span></div>
    <div className="report-studio-grid">
      <div className="report-config-column">
        <Panel title="1 · Modèle de rapport"><div className="report-template-grid">{templates.map(t=><button key={t.key} className={template===t.key?'active':''} onClick={()=>chooseTemplate(t.key)}><span>{t.key==='executive'?'◫':t.key==='analytical'?'▥':'⌘'}</span><div><b>{t.title}</b><small>{t.text}</small></div>{template===t.key&&<i>✓</i>}</button>)}</div></Panel>
        <Panel title="2 · Identité du document"><div className="stack-form report-identity"><label>Titre<input value={title} onChange={e=>setTitle(e.target.value)}/></label><label>Sous-titre<input value={subtitle} onChange={e=>setSubtitle(e.target.value)}/></label><div className="form-row"><label>Auteur<input value={author} onChange={e=>setAuthor(e.target.value)}/></label><label>Organisation<input value={organization} onChange={e=>setOrganization(e.target.value)} placeholder="Optionnel"/></label></div><label>Session AI Analyst<select value={analysisId} onChange={e=>setAnalysisId(e.target.value)}><option value="">Aucune</option>{analyses.map((a:AnyObj)=><option key={a.session_id} value={a.session_id}>{a.intent} · {a.question.slice(0,70)}</option>)}</select></label></div></Panel>
        <Panel title="3 · Organisation des sections"><div className="report-section-list">{choices.map(([key,label],index)=><label key={key} className={sections.includes(key)?'selected':''}><span>{String(index+1).padStart(2,'0')}</span><input type="checkbox" checked={sections.includes(key)} onChange={e=>setSections(e.target.checked?[...sections,key]:sections.filter(x=>x!==key))}/><b>{label}</b><small>{key==='executive_summary'?'KPI, constats et recommandations':key==='visualizations'?'Graphiques épinglés avec légendes':key==='provenance'?'Version, lineage et horodatage':'Section du rapport'}</small></label>)}</div></Panel>
        <Panel title="4 · Data Storytelling avancé" action={<button className="secondary-btn" disabled={!autoStory||busy} onClick={previewStory}>Prévisualiser la trame</button>}><div className="report-intelligence-grid"><label className={autoStory?'selected':''}><input type="checkbox" checked={autoStory} onChange={e=>setAutoStory(e.target.checked)}/><div><b>Storytelling multi-page automatique</b><small>Structure une narration en pages avec claims, preuves liées, limites et conclusion gouvernée.</small></div></label><label className={autoVisuals?'selected':''}><input type="checkbox" checked={autoVisuals} onChange={e=>setAutoVisuals(e.target.checked)}/><div><b>Sélection intelligente des graphiques</b><small>Complète les graphiques épinglés avec des figures adaptées au dataset, sans inventer de données.</small></div></label><label className="report-visual-limit"><span>Nombre maximal de figures</span><input type="number" min={1} max={10} value={maxVisuals} onChange={e=>setMaxVisuals(Math.max(1,Math.min(10,Number(e.target.value)||1)))}/></label></div>{autoStory&&<div className="story-config-grid"><label>Audience<select value={storyAudience} onChange={e=>setStoryAudience(e.target.value as any)}><option value="executive">Direction / décideurs</option><option value="operations">Opérations</option><option value="analyst">Analystes / data</option><option value="general">Audience générale</option></select></label><label>Ton<select value={storyTone} onChange={e=>setStoryTone(e.target.value as any)}><option value="concise">Concis</option><option value="balanced">Équilibré</option><option value="detailed">Détaillé</option></select></label><label>Pages<input type="number" min={3} max={8} value={storyMaxPages} onChange={e=>setStoryMaxPages(Math.max(3,Math.min(8,Number(e.target.value)||6)))}/></label><label className="story-objective">Objectif narratif<textarea value={storyObjective} onChange={e=>setStoryObjective(e.target.value)} maxLength={500}/></label></div>}{storyPreview&&<div className="story-blueprint-preview"><header><div><b>Trame {storyPreview.page_count} pages</b><small>{storyPreview.audience_label} · {storyPreview.tone}</small></div><span>{Math.round(Number(storyPreview.proof_coverage??0)*100)}% preuves liées</span></header><div>{(storyPreview.pages??[]).map((p:AnyObj)=><article key={p.page_number}><span>{String(p.page_number).padStart(2,'0')}</span><div><b>{p.headline}</b><small>{(p.claims??[]).length} claim(s) · {Math.round(Number(p.proof_coverage??0)*100)}% couverture</small></div></article>)}</div></div>}</Panel>
        <Panel title="5 · Visualisations à publier" action={<span className="quiet">{visualIds.length}/{savedVisuals.length} épinglée(s){autoVisuals?' + auto':''}</span>}>{savedVisuals.length?<div className="report-visual-picks">{savedVisuals.map((v:AnyObj)=><label key={v.id} className={visualIds.includes(v.id)?'selected':''}><input type="checkbox" checked={visualIds.includes(v.id)} onChange={e=>setVisualIds(e.target.checked?[...visualIds,v.id]:visualIds.filter(x=>x!==v.id))}/><div><b>{v.title}</b><small>{v.visualization?.type} · dataset v{v.dataset_version}</small></div></label>)}</div>:<div className="quiet-empty">Aucune visualisation épinglée. Avec le mode intelligent, DataVision peut générer les figures pertinentes automatiquement.</div>}</Panel>
        <Panel title="6 · Blocs composables" action={<span className="quiet">{customBlocks.length} bloc(s)</span>}><div className="report-block-palette">{['text','kpi','table','insight','model','code','methodology','visualization'].map(t=><button key={t} className="secondary-btn" onClick={()=>addReportBlock(t)}>＋ {t}</button>)}</div>{customBlocks.length?<div className="report-custom-blocks">{customBlocks.map((b:AnyObj,i:number)=><article key={b.id} className="report-custom-block"><header><span>{String(i+1).padStart(2,'0')}</span><input value={b.title} onChange={e=>patchReportBlock(b.id,{title:e.target.value})}/><code>{b.type}</code><button disabled={i===0} onClick={()=>moveReportBlock(b.id,-1)}>↑</button><button disabled={i===customBlocks.length-1} onClick={()=>moveReportBlock(b.id,1)}>↓</button><button className="danger-btn" onClick={()=>removeReportBlock(b.id)}>×</button></header><textarea value={b.payload} onChange={e=>patchReportBlock(b.id,{payload:e.target.value})} spellCheck={false}/><small>Configuration JSON du bloc. Les références Insight / Modèle / Visualisation sont vérifiées côté serveur et doivent appartenir au dataset/version active.</small></article>)}</div>:<div className="quiet-empty">Ajoutez du texte métier, KPI, tables, insights, modèles, code documenté, méthodologie ou figures. Chaque bloc sera exporté avec sa provenance.</div>}</Panel>
        <Panel title="7 · Générer"><div className="report-generate-row"><RunButton busy={busy} label="Générer le rapport professionnel" busyLabel="Composition…" onClick={create}/><div><b>{result.dataset.name}</b><span>Version {result.dataset.version??1} verrouillée · {sections.length+customBlocks.length} bloc(s) · {autoStory||autoVisuals?'mode intelligent':'mode manuel'}</span>{validation&&<small className={validation.status==='pass'?'ok':'bad'}>Validation {validation.status==='pass'?'✓':'!'} · hash {String(validation.content_hash??'').slice(0,12)}…</small>}</div></div></Panel>
      </div>
      <aside className="report-preview-column"><div className="report-preview-head"><div><span>APERÇU</span><b>{created?'Rapport généré':'Aperçu de composition'}</b></div>{created&&<div className="button-row"><button onClick={()=>dl(created.id,'pdf')}>PDF</button><button onClick={()=>dl(created.id,'docx')}>DOCX</button><button onClick={()=>dl(created.id,'html')}>HTML</button><button onClick={()=>dl(created.id,'md')}>MD</button></div>}</div>
        {created?<><ReportPreview report={created}/><div className="report-publication-box"><div><span>PUBLICATION GOUVERNÉE</span><b>{publication?.status==='published'?'Publié':'Brouillon validé'}</b><small>{publication?.status==='published'?`Reçu ${String(publication.receipt_hash??'').slice(0,12)}…`:'Validation d’intégrité + Data Reliability Gate avant diffusion.'}</small></div>{publication?.status!=='published'&&<div className="report-publication-actions"><select value={publishVisibility} onChange={e=>setPublishVisibility(e.target.value as any)}><option value="private">Privé</option><option value="workspace">Workspace</option><option value="external">Externe</option></select><button className="primary-btn real-button" disabled={busy||validation?.status!=='pass'} onClick={publishCurrent}>Publier</button></div>}</div></>:<div className="report-empty-preview"><div className="mini-report-cover"><span>DV</span><small>{templates.find(x=>x.key===template)?.title}</small><h3>{title||'Rapport DataVision'}</h3><p>{subtitle}</p><div><b>{result.dataset.name}</b><span>v{result.dataset.version??1}</span></div></div><p>Générez le rapport pour obtenir l’aperçu structuré complet.</p></div>}
      </aside>
    </div>
    <Panel title="Historique des rapports" action={<span className="quiet">{reports.length} rapport(s)</span>}>{reports.length?<div className="report-list enhanced">{reports.map((r:AnyObj)=><div key={r.id}><div className="report-history-icon">▧</div><div><b>{r.title}</b><small>{r.template??'analytical'} · v{r.dataset_version} · {r.story_page_count?`${r.story_page_count} pages · `:''}{r.publication_status==='published'?'Publié · ':''}{r.created_at?new Date(r.created_at).toLocaleString('fr-FR'):''}</small></div><div className="button-row"><button onClick={()=>dl(r.id,'pdf')}>PDF</button><button onClick={()=>dl(r.id,'docx')}>DOCX</button><button onClick={()=>dl(r.id,'html')}>HTML</button><button onClick={()=>dl(r.id,'md')}>MD</button></div></div>)}</div>:<div className="quiet-empty">Aucun rapport généré pour cette version.</div>}</Panel>
  </div>;
}

function CollaborationCenter({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [token,setToken]=useState('');
  const [workspaceId,setWorkspaceId]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspace,setWorkspace]=useState<AnyObj|null>(null);
  const [summary,setSummary]=useState<AnyObj|null>(null);
  const [reviews,setReviews]=useState<AnyObj[]>([]);
  const [selected,setSelected]=useState<AnyObj|null>(null);
  const [notifications,setNotifications]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [statusFilter,setStatusFilter]=useState('all');
  const [scope,setScope]=useState('all');
  const [composeOpen,setComposeOpen]=useState(false);
  const [resourceType,setResourceType]=useState('dataset');
  const [resourceId,setResourceId]=useState(result?.dataset?.id??'');
  const [title,setTitle]=useState(result?`Revue · ${result.dataset.name}`:'');
  const [description,setDescription]=useState('');
  const [priority,setPriority]=useState('normal');
  const [reviewerId,setReviewerId]=useState('');
  const [ownerId,setOwnerId]=useState('');
  const [dueAt,setDueAt]=useState('');
  const [comment,setComment]=useState('');
  const [decisionNote,setDecisionNote]=useState('');
  const [resources,setResources]=useState<AnyObj>({metrics:[],dashboards:[],reports:[]});
  const [assignOwner,setAssignOwner]=useState('');
  const [assignReviewer,setAssignReviewer]=useState('');
  const [certifications,setCertifications]=useState<AnyObj[]>([]);
  const [certValidUntil,setCertValidUntil]=useState('');
  const [certNotes,setCertNotes]=useState('');
  const [teams,setTeams]=useState<AnyObj[]>([]);
  const [shares,setShares]=useState<AnyObj[]>([]);
  const [decisions,setDecisions]=useState<AnyObj[]>([]);
  const [reviewDiff,setReviewDiff]=useState<AnyObj|null>(null);
  const [realtimeState,setRealtimeState]=useState<'off'|'connecting'|'live'>('off');
  const [teamName,setTeamName]=useState('');
  const [teamMembers,setTeamMembers]=useState<string[]>([]);
  const [shareRecipientType,setShareRecipientType]=useState<'user'|'team'>('user');
  const [shareRecipient,setShareRecipient]=useState('');
  const [sharePermission,setSharePermission]=useState('view');
  const [shareNote,setShareNote]=useState('');
  const realtimeRef=useRef<WebSocket|null>(null);

  async function refresh(nextToken=token,nextWs=workspaceId,keepSelection=true){
    if(!nextToken||!nextWs)return;
    setBusy(true);
    try{
      const [w,s,r,n,c,t,sh,d]=await Promise.all([
        getEnterpriseWorkspace(nextToken,nextWs),getReviewSummary(nextToken,nextWs),getReviews(nextToken,nextWs,statusFilter,scope),getCollaborationNotifications(nextToken,nextWs),getCertifications(nextToken,nextWs,'active'),getCollaborationTeams(nextToken,nextWs),getCollaborationShares(nextToken,nextWs,'received'),getCollaborationDecisions(nextToken,nextWs)
      ]);
      setWorkspace(w);setSummary(s);setReviews(r.reviews??[]);setNotifications(n.notifications??[]);setCertifications(c.certifications??[]);setTeams(t.teams??[]);setShares(sh.shares??[]);setDecisions(d.decisions??[]);
      if(keepSelection&&selected?.id){
        const d=await getReviewDetail(nextToken,nextWs,selected.id);setSelected(d.review);setAssignOwner(d.review.owner_user_id??'');setAssignReviewer(d.review.reviewer_user_id??'');
      }
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }
  useEffect(()=>{
    if(typeof window==='undefined')return;
    const t=sessionStorage.getItem('dv_enterprise_token')||'';const ws=localStorage.getItem('dv_enterprise_workspace')||'';
    setToken(t);setWorkspaceId(ws);
    if(t){getEnterpriseSession(t).then(s=>{setSession(s);const active=ws||s.workspaces?.[0]?.id||'';setWorkspaceId(active);if(active)refresh(t,active,false);}).catch(()=>setSession(null));}
  },[]);
  useEffect(()=>{if(token&&workspaceId)refresh(token,workspaceId,false);},[statusFilter,scope]);
  useEffect(()=>{
    if(!token||!workspaceId||typeof window==='undefined')return;
    let stopped=false;let timer:number|undefined;
    async function connect(){
      setRealtimeState('connecting');
      try{
        const ticket=await createCollaborationRealtimeTicket(token,workspaceId);
        if(stopped)return;
        const socket=new WebSocket(collaborationWebSocketUrl(workspaceId,ticket.ticket));realtimeRef.current=socket;
        socket.onopen=()=>{if(!stopped)setRealtimeState('live')};
        socket.onmessage=(ev)=>{try{const msg=JSON.parse(String(ev.data||'{}'));if(msg.type==='collaboration.activity'&&Array.isArray(msg.items)&&msg.items.length){refresh(token,workspaceId,true);}else if(msg.summary){setSummary((prev:AnyObj)=>({...prev,...msg.summary}));}}catch{}};
        socket.onclose=()=>{if(stopped)return;setRealtimeState('off');timer=window.setTimeout(connect,2500)};
        socket.onerror=()=>socket.close();
      }catch{if(!stopped){setRealtimeState('off');timer=window.setTimeout(connect,5000)}}
    }
    connect();
    return()=>{stopped=true;if(timer)window.clearTimeout(timer);realtimeRef.current?.close();realtimeRef.current=null;};
  },[token,workspaceId]);
  useEffect(()=>{
    if(!result){setResources({metrics:[],dashboards:[],reports:[]});return;}
    Promise.all([getSemanticModel(result.dataset.id),getDashboards(result.dataset.id),getReports(result.dataset.id)]).then(([sem,dash,reps])=>setResources({metrics:sem.metrics??[],dashboards:dash.dashboards??[],reports:reps.reports??[]})).catch(()=>setResources({metrics:[],dashboards:[],reports:[]}));
    if(resourceType==='dataset'){setResourceId(result.dataset.id);setTitle(`Revue · ${result.dataset.name}`)}
  },[result?.dataset?.id]);

  const members=workspace?.members??[];
  const currentRole=(session?.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId)?.role??workspace?.workspace?.role??'';
  const canManage=['owner','admin'].includes(currentRole);
  const unread=notifications.filter((n:AnyObj)=>!n.is_read).length;
  const candidateOptions=resourceType==='semantic_metric'?(resources.metrics??[]).map((x:AnyObj)=>({id:x.id,label:x.label||x.name||x.id,version:`semantic-v${x.semantic_version??''}`})):
    resourceType==='dashboard'?(resources.dashboards??[]).map((x:AnyObj)=>({id:x.id,label:x.name||x.title||x.id})):
    resourceType==='report'?(resources.reports??[]).map((x:AnyObj)=>({id:x.id||x.report_id,label:x.title||x.name||x.id||x.report_id})):
    resourceType==='dataset'&&result?[{id:result.dataset.id,label:`${result.dataset.name} · v${result.dataset.version??1}`}]:[];

  function changeResourceType(next:string){
    setResourceType(next);
    if(next==='dataset'&&result){setResourceId(result.dataset.id);setTitle(`Revue · ${result.dataset.name}`)}
    else{const opts=next==='semantic_metric'?resources.metrics:next==='dashboard'?resources.dashboards:next==='report'?resources.reports:[];const first=opts?.[0];setResourceId(first?.id||first?.report_id||'');setTitle(first?`Revue · ${first.label||first.name||first.title||first.id}`:'');}
  }
  async function create(){
    if(!token||!workspaceId||!resourceId||!title.trim())return;
    setBusy(true);setError('');
    try{
      const payload:AnyObj={resource_type:resourceType,resource_id:resourceId,title:title.trim(),description,priority,reviewer_user_id:reviewerId||null,owner_user_id:ownerId||session?.user?.id||null,due_at:dueAt||null,dataset_id:result?.dataset?.id||null,resource_version:result?`v${result.dataset.version??1}`:null,snapshot:{dataset_name:result?.dataset?.name??null,dataset_version:result?.dataset?.version??null,resource:resourceType==='semantic_metric'?(resources.metrics??[]).find((x:AnyObj)=>x.id===resourceId)??null:resourceType==='dashboard'?(resources.dashboards??[]).find((x:AnyObj)=>x.id===resourceId)??null:resourceType==='report'?(resources.reports??[]).find((x:AnyObj)=>(x.id||x.report_id)===resourceId)??null:resourceType==='dataset'?{name:result?.dataset?.name??null,version:result?.dataset?.version??null,rows:result?.profile?.rows??null,columns:(result?.profile?.columns??[]).map((c:AnyObj)=>({name:c.name,dtype:c.dtype,missing:c.missing}))}:null}};
      const r=await createReview(token,workspaceId,payload);setSelected(r.review);setComposeOpen(false);setDescription('');setDecisionNote('');await refresh(token,workspaceId,false);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function openReview(id:string){try{const [r,d]=await Promise.all([getReviewDetail(token,workspaceId,id),getReviewDiff(token,workspaceId,id).catch(()=>({diff:null}))]);setSelected(r.review);setReviewDiff(d.diff??null);setAssignOwner(r.review.owner_user_id??'');setAssignReviewer(r.review.reviewer_user_id??'');}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function transition(action:string){if(!selected)return;setBusy(true);try{const r=await transitionReview(token,workspaceId,selected.id,action,decisionNote);setSelected(r.review);setDecisionNote('');await refresh(token,workspaceId,false);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function postComment(){if(!selected||!comment.trim())return;setBusy(true);try{const r=await addReviewComment(token,workspaceId,selected.id,comment);setSelected(r.review);setComment('');await refresh(token,workspaceId,false);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function toggleComment(c:AnyObj){if(!selected)return;try{const r=await resolveReviewComment(token,workspaceId,selected.id,c.id,!c.resolved);setSelected(r.review);await refresh(token,workspaceId,false);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function reassign(){if(!selected)return;setBusy(true);try{const r=await assignReview(token,workspaceId,selected.id,{owner_user_id:assignOwner||null,reviewer_user_id:assignReviewer||null});setSelected(r.review);await refresh(token,workspaceId,false);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function certifySelected(){if(!selected)return;setBusy(true);try{await certifyReview(token,workspaceId,selected.id,{valid_until:certValidUntil||null,notes:certNotes});setCertNotes('');await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function revokeCert(id:string){try{await revokeCertification(token,workspaceId,id,'Révocation depuis Review Center');await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function readNotification(n:AnyObj){if(n.is_read)return;try{await markCollaborationNotificationRead(token,workspaceId,n.id);if(n.review_id)await openReview(n.review_id);await refresh(token,workspaceId,false);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function readAllNotifications(){try{await markAllCollaborationNotificationsRead(token,workspaceId);await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function createTeam(){if(!teamName.trim())return;setBusy(true);try{await createCollaborationTeam(token,workspaceId,{name:teamName.trim(),member_user_ids:teamMembers});setTeamName('');setTeamMembers([]);await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function shareCurrent(){const rtype=selected?.resource_type??(result?'dataset':'');const rid=selected?.resource_id??result?.dataset?.id;if(!rtype||!rid||!shareRecipient)return;setBusy(true);try{await createCollaborationShare(token,workspaceId,{resource_type:rtype,resource_id:rid,resource_version:selected?.resource_version??(result?`v${result.dataset.version??1}`:null),recipient_user_id:shareRecipientType==='user'?shareRecipient:null,recipient_team_id:shareRecipientType==='team'?shareRecipient:null,permission:sharePermission,note:shareNote});setShareNote('');await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function revokeShare(id:string){try{await revokeCollaborationShare(token,workspaceId,id);await refresh(token,workspaceId,true);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}

  if(!session||!token||!workspaceId)return <div className="page review-center"><div className="page-title"><div><span className="eyebrow">COLLABORATION & REVIEW</span><h1>Review Center</h1><p>Transformez une analyse en décision gouvernée : propriétaire, reviewer, commentaires, demandes de changement, approbation et historique immuable.</p></div><span className="module-state implemented">v2.6</span></div><div className="collab-auth-empty"><span>◎</span><div><h3>Session Entreprise requise</h3><p>Les workflows de revue sont liés à un workspace et à une identité afin de conserver une piste d’audit fiable.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;

  const byStatus=summary?.by_status??{};
  return <div className="page review-center">
    <div className="page-title"><div><span className="eyebrow">COLLABORATION & REVIEW · V2.6</span><h1>Review Center</h1><p>Un workflow de validation professionnel pour les métriques, analyses, dashboards, modèles et rapports avant publication ou prise de décision.</p></div><div className="review-head-actions"><span className={`review-realtime ${realtimeState}`}><i/> {realtimeState==='live'?'Temps réel':realtimeState==='connecting'?'Connexion…':'Hors ligne'}</span><span className="review-workspace">{workspace?.workspace?.name??'Workspace'} · {currentRole}</span><button className="secondary-btn" onClick={()=>refresh()} disabled={busy}>↻ Actualiser</button><button className="primary-btn" onClick={()=>setComposeOpen(v=>!v)}>+ Nouvelle revue</button></div></div>
    <div className="review-scorecards"><Stat label="À revoir" value={summary?.assigned_to_me??0} detail="Assignées à moi"/><Stat label="En revue" value={byStatus.in_review??0} detail="Workflow actif"/><Stat label="Corrections" value={byStatus.changes_requested??0} detail="Changes requested"/><Stat label="Approuvées" value={byStatus.approved??0} detail="Décisions validées"/><Stat label="En retard" value={summary?.overdue??0} detail="Échéance dépassée"/><Stat label="Notifications" value={unread} detail="Non lues"/></div>
    {composeOpen&&<Panel title="Créer une demande de revue" action={<button className="ghost-btn" onClick={()=>setComposeOpen(false)}>Fermer</button>}><div className="review-compose-grid"><label>Ressource<select value={resourceType} onChange={e=>changeResourceType(e.target.value)}><option value="dataset">Dataset</option><option value="semantic_metric">Métrique sémantique</option><option value="dashboard">Dashboard</option><option value="report">Rapport</option><option value="analysis">Analyse / session</option><option value="model">Modèle</option><option value="visualization">Visualisation</option></select></label><label>Élément{candidateOptions.length?<select value={resourceId} onChange={e=>{setResourceId(e.target.value);const x=candidateOptions.find((o:AnyObj)=>o.id===e.target.value);if(x)setTitle(`Revue · ${x.label}`)}}>{candidateOptions.map((x:AnyObj)=><option key={x.id} value={x.id}>{x.label}</option>)}</select>:<input value={resourceId} onChange={e=>setResourceId(e.target.value)} placeholder="ID de la ressource"/>}</label><label className="span-2">Titre<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Objet de la revue"/></label><label>Priorité<select value={priority} onChange={e=>setPriority(e.target.value)}><option value="low">Basse</option><option value="normal">Normale</option><option value="high">Haute</option><option value="critical">Critique</option></select></label><label>Reviewer<select value={reviewerId} onChange={e=>setReviewerId(e.target.value)}><option value="">À affecter plus tard</option>{members.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.display_name} · {m.role}</option>)}</select></label><label>Propriétaire<select value={ownerId} onChange={e=>setOwnerId(e.target.value)}><option value="">Moi</option>{members.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.display_name} · {m.role}</option>)}</select></label><label>Échéance<input type="date" value={dueAt} onChange={e=>setDueAt(e.target.value)}/></label><label className="span-2">Contexte<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Ce que le reviewer doit vérifier, hypothèses, risques, critères d’acceptation…"/></label><div className="span-2 review-compose-actions"><small>La revue conserve un snapshot de la version active afin de rendre la décision traçable.</small><RunButton busy={busy} label="Créer la revue" busyLabel="Création…" onClick={create}/></div></div></Panel>}
    <div className="collaboration-workspace-grid"><Panel title="Équipes" action={<span className="quiet">{teams.length} équipe(s)</span>}><div className="collaboration-team-list">{teams.map((t:AnyObj)=><div key={t.id}><b>{t.name}</b><small>{t.member_count} membre(s) · {(t.members??[]).map((m:AnyObj)=>m.display_name).join(', ')||'vide'}</small></div>)}</div>{canManage&&<details><summary>Créer une équipe</summary><div className="collaboration-team-create"><input value={teamName} onChange={e=>setTeamName(e.target.value)} placeholder="Nom de l’équipe"/><div className="collaboration-member-picks">{members.map((m:AnyObj)=><label key={m.id}><input type="checkbox" checked={teamMembers.includes(m.id)} onChange={e=>setTeamMembers(e.target.checked?[...teamMembers,m.id]:teamMembers.filter(x=>x!==m.id))}/>{m.display_name}</label>)}</div><button className="secondary-btn" onClick={createTeam} disabled={!teamName.trim()||busy}>Créer</button></div></details>}</Panel><Panel title="Partager un artefact" action={<span className="quiet">RBAC conservé</span>}><div className="collaboration-share-form"><div className="form-row"><select value={shareRecipientType} onChange={e=>{setShareRecipientType(e.target.value as 'user'|'team');setShareRecipient('')}}><option value="user">Membre</option><option value="team">Équipe</option></select><select value={shareRecipient} onChange={e=>setShareRecipient(e.target.value)}><option value="">Choisir…</option>{shareRecipientType==='user'?members.filter((m:AnyObj)=>m.id!==session?.user?.id).map((m:AnyObj)=><option key={m.id} value={m.id}>{m.display_name} · {m.role}</option>):teams.map((t:AnyObj)=><option key={t.id} value={t.id}>{t.name}</option>)}</select><select value={sharePermission} onChange={e=>setSharePermission(e.target.value)}><option value="view">Voir</option><option value="comment">Commenter</option><option value="review">Revoir</option></select></div><input value={shareNote} onChange={e=>setShareNote(e.target.value)} placeholder="Note de partage (optionnel)"/><button className="secondary-btn" onClick={shareCurrent} disabled={!shareRecipient||busy}>Partager {selected?'la ressource sélectionnée':'le dataset actif'}</button><small>Le partage n’accorde jamais plus de droits que le rôle workspace et les politiques d’accès existantes.</small></div></Panel></div>
    <div className="review-layout">
      <section className="review-queue"><div className="review-toolbar"><div><select value={scope} onChange={e=>setScope(e.target.value)}><option value="all">Toutes les revues</option><option value="assigned">Assignées à moi</option><option value="owned">Mes ressources</option><option value="created">Créées par moi</option></select><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option value="all">Tous statuts</option><option value="draft">Brouillon</option><option value="in_review">En revue</option><option value="changes_requested">Corrections</option><option value="approved">Approuvée</option><option value="archived">Archivée</option></select></div><small>{reviews.length} revue(s)</small></div><div className="review-list">{reviews.length?reviews.map((r:AnyObj)=><button key={r.id} className={`review-card ${selected?.id===r.id?'active':''}`} onClick={()=>openReview(r.id)}><div className="review-card-top"><span className={`review-status ${r.status}`}>{String(r.status).replaceAll('_',' ')}</span><span className={`review-priority ${r.priority}`}>{r.priority}</span></div><b>{r.title}</b><p>{r.resource_type} · {String(r.resource_id).slice(0,28)}</p><div className="review-meta"><span>{r.reviewer?.display_name?`Reviewer · ${r.reviewer.display_name}`:'Reviewer non affecté'}</span><span>{r.comment_count??0} commentaire(s)</span></div>{r.due_at&&<small>Échéance · {new Date(r.due_at).toLocaleDateString('fr-FR')}</small>}</button>):<div className="quiet-empty review-empty">Aucune revue dans ce filtre.</div>}</div></section>
      <section className="review-detail">{selected?<><div className="review-detail-head"><div><div className="review-detail-tags"><span className={`review-status ${selected.status}`}>{String(selected.status).replaceAll('_',' ')}</span><span className={`review-priority ${selected.priority}`}>{selected.priority}</span><span>{selected.resource_type}</span></div><h2>{selected.title}</h2><p>{selected.description||'Aucune consigne particulière.'}</p></div><div className="review-ownership"><small>OWNER</small><b>{selected.owner?.display_name??'—'}</b><small>REVIEWER</small><b>{selected.reviewer?.display_name??'Non affecté'}</b></div></div>
        <div className="review-proofbar"><div><span>Ressource</span><b>{selected.resource_id}</b></div><div><span>Version</span><b>{selected.resource_version??'—'}</b></div><div><span>Créée</span><b>{selected.created_at?new Date(selected.created_at).toLocaleDateString('fr-FR'):'—'}</b></div><div><span>Commentaires ouverts</span><b>{selected.unresolved_comment_count??0}</b></div></div>
        {reviewDiff&&<div className={`review-diff ${reviewDiff.changed?'changed':'stable'}`}><div><b>Diff de version</b><span>{reviewDiff.baseline_review_id?`${reviewDiff.from_version??'ancienne version'} → ${reviewDiff.to_version??'version courante'}`:'Première revue de cette ressource'}</span></div><strong>{reviewDiff.change_count??0} changement(s)</strong>{reviewDiff.changed&&<details><summary>Voir les changements</summary><div className="review-diff-list">{(reviewDiff.changes??[]).slice(0,30).map((x:AnyObj)=><div key={x.path}><code>{x.path}</code><span className={x.kind}>{x.kind}</span><small>{String(x.before??'∅')} → {String(x.after??'∅')}</small></div>)}</div></details>}</div>}
        {canManage&&<details className="review-assignment"><summary>Affectation & ownership</summary><div><label>Owner<select value={assignOwner} onChange={e=>setAssignOwner(e.target.value)}><option value="">—</option>{members.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.display_name}</option>)}</select></label><label>Reviewer<select value={assignReviewer} onChange={e=>setAssignReviewer(e.target.value)}><option value="">—</option>{members.map((m:AnyObj)=><option key={m.id} value={m.id}>{m.display_name} · {m.role}</option>)}</select></label><button className="secondary-btn" onClick={reassign}>Mettre à jour</button></div></details>}
        <div className="review-decision-zone"><textarea value={decisionNote} onChange={e=>setDecisionNote(e.target.value)} placeholder="Note de décision / critères vérifiés…"/><div className="review-actions">{['draft','changes_requested'].includes(selected.status)&&<button className="primary-btn" disabled={busy} onClick={()=>transition('submit')}>Soumettre à revue</button>}{selected.status==='in_review'&&<><button className="approve-btn" disabled={busy} onClick={()=>transition('approve')}>✓ Approuver</button><button className="changes-btn" disabled={busy} onClick={()=>transition('request_changes')}>↺ Demander des corrections</button></>}{['approved','changes_requested'].includes(selected.status)&&<button className="secondary-btn" disabled={busy} onClick={()=>transition('reopen')}>Rouvrir la revue</button>}{canManage&&selected.status!=='archived'&&<button className="ghost-btn" disabled={busy} onClick={()=>transition('archive')}>Archiver</button>}</div></div>
        {selected.status==='approved'&&<div className="review-cert-zone"><div><b>Certification de confiance</b><small>Une certification active signale qu’une ressource approuvée reste la référence gouvernée jusqu’à expiration ou révocation.</small></div>{canManage?<><input type="date" value={certValidUntil} onChange={e=>setCertValidUntil(e.target.value)}/><input value={certNotes} onChange={e=>setCertNotes(e.target.value)} placeholder="Note de certification"/><button className="approve-btn" onClick={certifySelected} disabled={busy}>Certifier</button></>:<span className="quiet">Owner/Admin requis</span>}</div>}
        <div className="review-detail-grid"><Panel title="Discussion" action={<span className="quiet">@mention supportée</span>}><div className="review-comments">{(selected.comments??[]).length?(selected.comments??[]).map((c:AnyObj)=><article key={c.id} className={c.resolved?'resolved':''}><div className="member-avatar">{String(c.display_name||c.email).slice(0,2).toUpperCase()}</div><div><header><b>{c.display_name||c.email}</b><small>{new Date(c.created_at).toLocaleString('fr-FR')}</small>{c.resolved&&<span>RÉSOLU</span>}</header><p>{c.body}</p><button className="link-btn" onClick={()=>toggleComment(c)}>{c.resolved?'Rouvrir':'Marquer résolu'}</button></div></article>):<div className="quiet-empty">Aucun commentaire. Utilisez la discussion pour documenter les points de contrôle.</div>}</div><div className="review-comment-box"><textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Commenter… Utilisez @email ou @nom pour mentionner un membre."/><button className="primary-btn" onClick={postComment} disabled={!comment.trim()||busy}>Commenter</button></div></Panel><Panel title="Historique de décision"><div className="review-timeline">{(selected.events??[]).map((e:AnyObj)=><div key={e.id}><span/><div><b>{e.action.replaceAll('_',' ')}</b><small>{e.display_name||e.email} · {new Date(e.created_at).toLocaleString('fr-FR')}</small>{e.from_status!==e.to_status&&<em>{e.from_status||'—'} → {e.to_status||'—'}</em>}</div></div>)}</div></Panel></div>
      </>:<div className="review-detail-empty"><span>◎</span><h3>Sélectionnez une revue</h3><p>La fiche regroupe contexte, ownership, discussion, décision et piste d’audit.</p></div>}</section>
      <aside className="review-notifications"><div className="review-notif-head"><div><b>Notifications</b><small>{unread} non lue(s)</small></div>{unread>0&&<button className="link-btn" onClick={readAllNotifications}>Tout lire</button>}</div><div className="review-notif-list">{notifications.slice(0,14).map((n:AnyObj)=><button key={n.id} className={!n.is_read?'unread':''} onClick={()=>readNotification(n)}><span>{n.notification_type==='mention'?'@':'◎'}</span><div><b>{n.message}</b><small>{new Date(n.created_at).toLocaleString('fr-FR')}</small></div></button>)}{!notifications.length&&<div className="quiet-empty">Aucune notification.</div>}</div><div className="review-cert-list"><div className="review-notif-head"><div><b>Certifications actives</b><small>{certifications.length}</small></div></div>{certifications.slice(0,8).map((c:AnyObj)=><div className="review-cert-card" key={c.id}><div><b>{c.resource_id}</b><small>{c.resource_type}{c.valid_until?` · expire ${new Date(c.valid_until).toLocaleDateString('fr-FR')}`:''}</small></div>{canManage&&<button className="ghost-btn" onClick={()=>revokeCert(c.id)}>Révoquer</button>}</div>)}</div><div className="review-side-section"><div className="review-notif-head"><div><b>Partagés avec moi</b><small>{shares.filter((x:AnyObj)=>x.active).length}</small></div></div>{shares.filter((x:AnyObj)=>x.active).slice(0,6).map((sh:AnyObj)=><div className="review-share-card" key={sh.id}><b>{sh.resource_type} · {String(sh.resource_id).slice(0,22)}</b><small>{sh.permission} · par {sh.created_by_user?.display_name??sh.created_by_user?.email??'membre'}</small></div>)}{!shares.filter((x:AnyObj)=>x.active).length&&<div className="quiet-empty">Aucun partage reçu.</div>}</div><div className="review-side-section"><div className="review-notif-head"><div><b>Décisions récentes</b><small>{decisions.length}</small></div></div>{decisions.slice(0,6).map((d:AnyObj)=><div className="review-decision-card" key={d.id}><span className={d.action==='approve'||d.action==='certified'?'ok':'warn'}>{d.action==='approve'?'✓':d.action==='request_changes'?'↺':'◆'}</span><div><b>{d.title}</b><small>{d.display_name||d.email} · {new Date(d.created_at).toLocaleString('fr-FR')}</small></div></div>)}</div><div className="review-governance-note"><b>Approval gate</b><p>Une approbation appartient à un reviewer identifié. Toutes les transitions sont auditées et conservées séparément du contenu analytique.</p></div></aside>
    </div>
  </div>;
}


function ReliabilityLineageCenter({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [summary,setSummary]=useState<AnyObj|null>(null);
  const [contracts,setContracts]=useState<AnyObj[]>([]);
  const [runs,setRuns]=useState<AnyObj[]>([]);
  const [lineage,setLineage]=useState<AnyObj>({nodes:[],edges:[]});
  const [catalogAssets,setCatalogAssets]=useState<AnyObj[]>([]);
  const [catalogSummary,setCatalogSummary]=useState<AnyObj|null>(null);
  const [catalogQuery,setCatalogQuery]=useState('');
  const [catalogType,setCatalogType]=useState('');
  const [catalogSelected,setCatalogSelected]=useState<AnyObj|null>(null);
  const [catalogDraft,setCatalogDraft]=useState<AnyObj>({title:'',description:'',business_domain:'',owner_user_id:'',steward_user_id:'',tags:'',certification_status:'unreviewed'});
  const [gate,setGate]=useState<AnyObj|null>(null);
  const [impact,setImpact]=useState<AnyObj|null>(null);
  const [selectedRun,setSelectedRun]=useState<AnyObj|null>(null);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [compose,setCompose]=useState(false);
  const [name,setName]=useState('Contrat de qualité');
  const [mode,setMode]=useState('warn');
  const [ruleType,setRuleType]=useState('required_columns');
  const [ruleColumn,setRuleColumn]=useState('');
  const [ruleThreshold,setRuleThreshold]=useState('0');
  const [draftRules,setDraftRules]=useState<AnyObj[]>([]);
  const activeDatasetId=String(result?.dataset?.id??'');
  const activeWorkspace=(session?.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId);
  const role=activeWorkspace?.role??'';
  const canManage=['owner','admin','data_scientist'].includes(role);

  async function load(t=token,ws=workspaceId){
    if(!t||!ws)return;
    setBusy(true);
    try{
      const [s,c,r,l,cat,catSummary]=await Promise.all([
        getReliabilitySummary(t,ws,activeDatasetId||undefined),getDataContracts(t,ws,activeDatasetId||undefined),getContractRuns(t,ws,undefined,activeDatasetId||undefined),getLineageGraph(t,ws,activeDatasetId||undefined),getDataCatalogAssets(t,ws),getDataCatalogSummary(t,ws)
      ]);
      setSummary(s);setContracts(c.contracts??[]);setRuns(r.runs??[]);setLineage(l);setCatalogAssets(cat.assets??[]);setCatalogSummary(catSummary);
      if(activeDatasetId){try{setGate(await getPublicationGate(t,ws,activeDatasetId));}catch{setGate(null)}}else setGate(null);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }
  useEffect(()=>{
    if(typeof window==='undefined')return;
    const t=sessionStorage.getItem('dv_enterprise_token')||''; const stored=localStorage.getItem('dv_enterprise_workspace')||'';setToken(t);
    if(!t)return;
    getEnterpriseSession(t).then(s=>{setSession(s);setWorkspaceId(stored||s.workspaces?.[0]?.id||'')}).catch(()=>{setToken('');setSession(null)});
  },[]);
  useEffect(()=>{if(token&&workspaceId)load(token,workspaceId);},[token,workspaceId,activeDatasetId]);
  useEffect(()=>{if(result?.profile?.columns?.length&&!ruleColumn)setRuleColumn(String(result.profile.columns[0].name));},[result?.dataset?.id]);

  function changeWorkspace(id:string){setWorkspaceId(id);setImpact(null);setSelectedRun(null);if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',id);window.dispatchEvent(new Event('datavision-enterprise-session'));}}
  function addRule(){
    const severity=ruleType==='required_columns'||ruleType==='unique'?'critical':'high';
    let rule:AnyObj={type:ruleType,severity};
    if(ruleType==='required_columns')rule.columns=(result?.profile?.columns??[]).map((c:AnyObj)=>c.name);
    else if(ruleType==='row_count')rule.min=Math.max(1,Number(ruleThreshold)||1);
    else if(ruleType==='missing_pct'){rule.column=ruleColumn;rule.max=Math.max(0,Number(ruleThreshold)||0)}
    else if(ruleType==='unique'){rule.column=ruleColumn;rule.max_duplicate_pct=Math.max(0,Number(ruleThreshold)||0)}
    else if(ruleType==='range'){rule.column=ruleColumn;rule.min=0;rule.max=Number(ruleThreshold)||100}
    else if(ruleType==='distribution_drift'){rule.column=ruleColumn;if((result?.profile?.columns??[]).find((c:AnyObj)=>c.name===ruleColumn&&isNumeric(c)))rule.max_ks=Number(ruleThreshold)||.2;else rule.max_tvd=Number(ruleThreshold)||.2}
    setDraftRules(x=>[...x,rule]);
  }
  function recommendedRules(){
    if(!result)return;
    const rows=Number(result.profile.rows||0); const cols=result.profile.columns??[];
    const rules:AnyObj[]=[{type:'required_columns',columns:cols.map((c:AnyObj)=>c.name),severity:'critical',blocking:true},{type:'row_count',min:Math.max(1,Math.floor(rows*.8)),severity:'high',blocking:true}];
    cols.slice(0,12).forEach((c:AnyObj)=>{const current=rows?Number(c.missing||0)/rows*100:0;rules.push({type:'missing_pct',column:c.name,max:Math.min(100,Math.max(2,Math.ceil(current+5))),severity:'high',blocking:false});if(isLikelyIdentifier(c,rows))rules.push({type:'unique',column:c.name,max_duplicate_pct:0,severity:'critical',blocking:true});});
    const numeric=cols.find((c:AnyObj)=>isNumeric(c)&&!isLikelyIdentifier(c,rows)); if(numeric)rules.push({type:'distribution_drift',column:numeric.name,max_ks:.2,severity:'medium',blocking:false});
    setDraftRules(rules);setName(`Contrat — ${result.dataset.name}`);setCompose(true);
  }
  async function saveContract(){
    if(!activeDatasetId||!workspaceId||!token||!draftRules.length)return;
    setBusy(true);try{await saveDataContract(token,workspaceId,{dataset_id:activeDatasetId,name,description:'Contrat créé depuis Data Reliability Center',rules:draftRules,enforcement_mode:mode,enabled:true});setNotice('Data contract enregistré. Exécutez-le pour établir le statut courant.');setCompose(false);setDraftRules([]);await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function runContract(c:AnyObj){setBusy(true);try{const r=await runDataContract(token,workspaceId,c.id,activeDatasetId||c.dataset_id);setSelectedRun(r.run);setNotice(`Contrat exécuté · ${r.run.status} · score ${r.run.score}/100`);await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function removeContract(c:AnyObj){if(!confirm(`Supprimer le contrat « ${c.name} » ?`))return;setBusy(true);try{await deleteDataContract(token,workspaceId,c.id);await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function inspectImpact(n:AnyObj){setBusy(true);try{setImpact(await getImpactAnalysis(token,workspaceId,n.type,n.resource_id,8));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  function editCatalogAsset(asset:AnyObj){setCatalogSelected(asset);setCatalogDraft({title:asset.title??'',description:asset.description??'',business_domain:asset.business_domain??'',owner_user_id:asset.owner_user_id??'',steward_user_id:asset.steward_user_id??'',tags:(asset.tags??[]).join(', '),certification_status:asset.certification_status??'unreviewed'});}
  async function saveCatalogMetadata(){if(!catalogSelected)return;setBusy(true);try{await saveDataCatalogAsset(token,workspaceId,catalogSelected.resource_type,catalogSelected.resource_id,{...catalogDraft,tags:String(catalogDraft.tags||'').split(',').map((x:string)=>x.trim()).filter(Boolean),glossary:catalogSelected.glossary??{}});setNotice('Documentation métier enregistrée dans le Data Catalog.');setCatalogSelected(null);await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}

  if(!token||!session)return <div className="page reliability-page"><div className="page-title"><div><span className="eyebrow">DATA RELIABILITY · CONTRACTS · LINEAGE</span><h1>Fiabilité & Lineage</h1><p>Définissez ce qu'une donnée fiable signifie, détectez les ruptures et mesurez l'impact avant publication.</p></div><span className="module-state implemented">v2.8</span></div><div className="collab-auth-empty"><span>◫</span><div><h3>Session Entreprise requise</h3><p>Les contrats et le lineage sont isolés par workspace et s'appuient sur la gouvernance tenant-aware.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;

  const status=summary?.contract_status??{}; const nodes=lineage?.nodes??[]; const sources=nodes.filter((n:AnyObj)=>n.type==='source'); const datasets=nodes.filter((n:AnyObj)=>n.type==='dataset'); const outputs=nodes.filter((n:AnyObj)=>!['source','dataset'].includes(n.type));
  const catalogFiltered=catalogAssets.filter((a:AnyObj)=>(!catalogType||a.resource_type===catalogType)&&(!catalogQuery||[a.title,a.technical_name,a.description,a.business_domain,...(a.tags??[])].join(' ').toLowerCase().includes(catalogQuery.toLowerCase())));
  return <div className="page reliability-page">
    <div className="page-title"><div><span className="eyebrow">DATA RELIABILITY & LINEAGE · V2.8</span><h1>Fiabilité & Lineage</h1><p>Data contracts exécutables, dérive de distribution, lineage de bout en bout, analyse d'impact et gate de publication.</p></div><div className="reliability-head-actions"><label>Workspace<select value={workspaceId} onChange={e=>changeWorkspace(e.target.value)}>{(session.workspaces??[]).map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><button className="secondary-btn" onClick={()=>load()} disabled={busy}>↻ Actualiser</button>{activeDatasetId&&canManage&&<button className="primary-btn" onClick={recommendedRules}>+ Contrat recommandé</button>}</div></div>
    {notice&&<div className="source-notice"><span>✓</span><p>{notice}</p><button onClick={()=>setNotice('')}>×</button></div>}
    <div className="reliability-scorecards"><Stat label="Reliability" value={summary?.reliability_score==null?'—':`${summary.reliability_score}/100`} detail="contrats exécutés"/><Stat label="Contrats" value={summary?.contracts??0} detail={`${status.healthy??0} healthy · ${status.critical??0} critical`}/><Stat label="Incidents ouverts" value={summary?.open_event_count??0} detail="signaux de qualité"/><Stat label="Lineage" value={summary?.lineage?.nodes??0} detail={`${summary?.lineage?.edges??0} dépendances`}/><Stat label="Publication gate" value={!activeDatasetId?'—':gate?.allowed?'OPEN':'BLOCKED'} detail={!activeDatasetId?'Activez un dataset':`${gate?.blockers?.length??0} bloqueur(s)`}/></div>

    {activeDatasetId&&gate&&<div className={`publication-gate ${gate.allowed?'open':'blocked'}`}><div className="gate-icon">{gate.allowed?'✓':'!'}</div><div><span>PUBLICATION GATE</span><h3>{gate.allowed?'Prêt pour revue / publication':'Publication bloquée'}</h3><p>{gate.allowed?'Aucun contrat en mode block n’est actuellement en échec.':`${gate.blockers.length} contrat(s) bloquant(s) doivent être corrigés avant certification.`}</p></div><div className="gate-meta"><b>Dataset v{gate.dataset_version}</b><small>{gate.warnings?.length??0} avertissement(s)</small></div></div>}

    {compose&&<Panel title="Nouveau Data Contract" action={<button className="text-btn" onClick={()=>setCompose(false)}>Fermer</button>}><div className="contract-compose"><label>Nom<input value={name} onChange={e=>setName(e.target.value)}/></label><label>Enforcement<select value={mode} onChange={e=>setMode(e.target.value)}><option value="monitor">Monitor</option><option value="warn">Warn</option><option value="block">Block</option></select></label><div className="rule-builder"><label>Règle<select value={ruleType} onChange={e=>setRuleType(e.target.value)}><option value="required_columns">Colonnes requises</option><option value="row_count">Volume minimum</option><option value="missing_pct">% manquant max</option><option value="unique">Unicité</option><option value="range">Plage numérique</option><option value="distribution_drift">Distribution drift</option></select></label>{!['required_columns','row_count'].includes(ruleType)&&<label>Colonne<select value={ruleColumn} onChange={e=>setRuleColumn(e.target.value)}>{(result?.profile?.columns??[]).map((c:AnyObj)=><option key={c.name} value={c.name}>{c.name}</option>)}</select></label>}<label>Seuil<input value={ruleThreshold} onChange={e=>setRuleThreshold(e.target.value)} placeholder="0"/></label><button className="secondary-btn" onClick={addRule}>+ Ajouter</button></div><div className="draft-rules">{draftRules.map((r,i)=><div key={i}><b>{r.type}</b><span>{r.column??(r.columns?`${r.columns.length} colonnes`:'dataset')}</span><small>{r.severity}{r.blocking?' · bloquant':''}</small><button onClick={()=>setDraftRules(x=>x.filter((_,j)=>j!==i))}>×</button></div>)}</div><div className="contract-compose-actions"><small>Les règles sont exécutées par le moteur déterministe. Le mode <b>block</b> peut empêcher la certification d'une ressource liée au dataset.</small><button className="primary-btn" disabled={busy||!draftRules.length} onClick={saveContract}>Enregistrer le contrat</button></div></div></Panel>}

    <div className="reliability-grid">
      <section className="reliability-card"><div className="reliability-section-head"><div><span>DATA CONTRACTS</span><h3>Contrats & derniers contrôles</h3></div>{activeDatasetId&&canManage&&<button className="secondary-btn" onClick={()=>setCompose(v=>!v)}>+ Manuel</button>}</div>{contracts.length?<div className="contract-list">{contracts.map(c=><article key={c.id} className={`contract-card ${c.status}`}><div className="contract-status"><i/><span>{c.status}</span></div><div className="contract-main"><div><b>{c.name}</b><small>{c.rules?.length??0} règle(s) · {c.enforcement_mode}</small></div><strong>{c.last_score==null?'—':`${formatNumber(c.last_score,1)}/100`}</strong></div><div className="contract-actions"><button onClick={()=>runContract(c)} disabled={busy||!canManage}>▶ Exécuter</button><button onClick={()=>{const r=runs.find((x:AnyObj)=>x.contract_id===c.id);if(r)setSelectedRun(r)}}>Détails</button>{canManage&&<button className="danger-link" onClick={()=>removeContract(c)}>Supprimer</button>}</div></article>)}</div>:<div className="quiet-empty">{activeDatasetId?'Aucun data contract pour cette lignée.':'Activez un dataset pour afficher ses contrats.'}</div>}</section>
      <section className="reliability-card"><div className="reliability-section-head"><div><span>QUALITY EVENTS</span><h3>Signaux à investiguer</h3></div><small>{summary?.open_event_count??0} ouvert(s)</small></div><div className="reliability-events">{(summary?.open_events??[]).slice(0,8).map((e:AnyObj)=><div key={e.id} className={`reliability-event ${e.severity}`}><span>{String(e.severity).toUpperCase()}</span><div><b>{e.title}</b><small>{String(e.created_at??'').replace('T',' ').slice(0,16)}</small></div></div>)}{!(summary?.open_events??[]).length&&<div className="quiet-empty">Aucun incident ouvert.</div>}</div></section>
    </div>

    {selectedRun&&<Panel title={`Résultat du contrat · ${selectedRun.status}`} action={<button className="text-btn" onClick={()=>setSelectedRun(null)}>Fermer</button>}><div className="contract-run-summary"><Stat label="Score" value={`${selectedRun.score}/100`}/><Stat label="Pass" value={selectedRun.checks_passed}/><Stat label="Fail" value={selectedRun.checks_failed}/><Stat label="Bloquants" value={selectedRun.blocking_failures}/></div><div className="contract-checks">{(selectedRun.results??[]).map((r:AnyObj)=><div key={r.rule_id} className={r.status}><span>{r.status==='pass'?'✓':'!'}</span><div><b>{r.label}</b><p>{r.message}</p></div><small>{r.severity}{r.blocking?' · block':''}</small></div>)}</div></Panel>}

    <section className="lineage-shell"><div className="reliability-section-head"><div><span>DATA CATALOG · V2.68</span><h3>Discovery & documentation métier</h3></div><small>{catalogSummary?.assets??catalogAssets.length} actifs · {catalogSummary?.certified??0} certifié(s)</small></div><div className="catalog-discovery-toolbar"><input value={catalogQuery} onChange={e=>setCatalogQuery(e.target.value)} placeholder="Rechercher dataset, domaine, tag, rapport…"/><select value={catalogType} onChange={e=>setCatalogType(e.target.value)}><option value="">Tous les types</option>{Array.from(new Set(catalogAssets.map((a:AnyObj)=>a.resource_type))).sort().map((t:any)=><option key={String(t)} value={String(t)}>{String(t)}</option>)}</select></div><div className="catalog-summary-strip"><Stat label="Documentés" value={catalogSummary?.documented??0}/><Stat label="Owner/Steward" value={catalogSummary?.owned??0}/><Stat label="Taggés" value={catalogSummary?.tagged??0}/><Stat label="Résultats" value={catalogFiltered.length}/></div><div className="catalog-asset-list">{catalogFiltered.slice(0,80).map((a:AnyObj)=><article key={a.id}><div><span className="catalog-type-pill">{a.resource_type}</span><b>{a.title}</b><small>{a.business_domain||'Domaine non documenté'} · ↑{a.lineage?.upstream??0} ↓{a.lineage?.downstream??0}</small><p>{a.description||'Ajoutez une description métier, un owner et des tags.'}</p><div className="catalog-tags">{(a.tags??[]).slice(0,6).map((tag:string)=><i key={tag}>{tag}</i>)}</div></div><div className="catalog-asset-actions"><span className={`catalog-cert ${a.certification_status}`}>{a.certification_status}</span>{canManage&&<button className="secondary-btn" onClick={()=>editCatalogAsset(a)}>Documenter</button>}<button className="text-btn" onClick={()=>inspectImpact({type:a.resource_type,resource_id:a.resource_id})}>Impact</button></div></article>)}{!catalogFiltered.length&&<div className="quiet-empty">Aucun actif ne correspond à cette recherche.</div>}</div>{catalogSelected&&<div className="catalog-editor"><div className="reliability-section-head"><div><span>DOCUMENTATION MÉTIER</span><h3>{catalogSelected.technical_name}</h3></div><button className="text-btn" onClick={()=>setCatalogSelected(null)}>Fermer</button></div><div className="catalog-editor-grid"><label>Titre métier<input value={catalogDraft.title} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,title:e.target.value}))}/></label><label>Domaine<input value={catalogDraft.business_domain} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,business_domain:e.target.value}))}/></label><label>Owner<input value={catalogDraft.owner_user_id} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,owner_user_id:e.target.value}))} placeholder="user id ou équipe"/></label><label>Steward<input value={catalogDraft.steward_user_id} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,steward_user_id:e.target.value}))}/></label><label>Tags<input value={catalogDraft.tags} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,tags:e.target.value}))} placeholder="finance, ventes, certifié"/></label><label>Statut<select value={catalogDraft.certification_status} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,certification_status:e.target.value}))}><option value="unreviewed">Non revu</option><option value="draft">Brouillon</option><option value="certified">Certifié</option><option value="deprecated">Déprécié</option></select></label><label className="catalog-editor-description">Description<textarea value={catalogDraft.description} onChange={e=>setCatalogDraft((d:AnyObj)=>({...d,description:e.target.value}))} rows={4}/></label></div><button className="primary-btn" onClick={saveCatalogMetadata} disabled={busy}>Enregistrer la documentation</button></div>}</section>

    <section className="lineage-shell"><div className="reliability-section-head"><div><span>END-TO-END LINEAGE</span><h3>Source → Dataset → Analyse → Modèle → Dashboard → Rapport</h3></div><small>{lineage?.node_count??0} nœuds · {lineage?.edge_count??0} liens</small></div><div className="lineage-flow"><div className="lineage-column"><span>SOURCES</span>{sources.map((n:AnyObj)=><button key={n.id} onClick={()=>inspectImpact(n)}><i>DB</i><div><b>{n.label}</b><small>source</small></div></button>)}</div><div className="lineage-arrow">→</div><div className="lineage-column"><span>DATASETS</span>{datasets.slice(0,12).map((n:AnyObj)=><button key={n.id} onClick={()=>inspectImpact(n)}><i>v{n.version??'•'}</i><div><b>{n.label}</b><small>{String(n.resource_id).slice(0,8)}</small></div></button>)}</div><div className="lineage-arrow">→</div><div className="lineage-column"><span>CONSOMMATEURS</span>{outputs.slice(0,18).map((n:AnyObj)=><button key={n.id} onClick={()=>inspectImpact(n)}><i>{n.type==='model'?'ML':n.type==='dashboard'?'BI':n.type==='report'?'RP':n.type==='metric'?'KPI':'AN'}</i><div><b>{n.label}</b><small>{n.type}</small></div></button>)}</div></div></section>

    {impact&&<section className="impact-panel"><div className="reliability-section-head"><div><span>IMPACT ANALYSIS</span><h3>{impact.resource?.label}</h3></div><button className="text-btn" onClick={()=>setImpact(null)}>Fermer</button></div><div className="impact-kpis"><Stat label="Ressources impactées" value={impact.impact_count}/>{Object.entries(impact.by_type??{}).map(([k,v])=><Stat key={k} label={k} value={String(v)}/>)}</div><div className="impact-list">{(impact.impacted??[]).map((n:AnyObj)=><div key={n.id}><span>+{n.depth}</span><div><b>{n.label??n.id}</b><small>{n.type} · via {n.via}</small></div></div>)}</div></section>}
  </div>;
}

function SourcesRefreshCenter({setError,setView,onActivate}:{setError:(s:string)=>void;setView:(v:View)=>void;onActivate:(id:string)=>void}){
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [overview,setOverview]=useState<AnyObj>({connectors:[],sources:[],schedules:[]});
  const [connectorCatalog,setConnectorCatalog]=useState<AnyObj[]>([]);
  const [health,setHealth]=useState<AnyObj|null>(null);
  const [runs,setRuns]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [showConnectorForm,setShowConnectorForm]=useState(false);
  const [showSourceForm,setShowSourceForm]=useState(false);
  const [connectorName,setConnectorName]=useState('Warehouse principal');
  const [connectorType,setConnectorType]=useState('postgresql');
  const [connectorHost,setConnectorHost]=useState('');
  const [connectorPort,setConnectorPort]=useState('5432');
  const [connectorDb,setConnectorDb]=useState('');
  const [connectorUser,setConnectorUser]=useState('');
  const [connectorPassword,setConnectorPassword]=useState('');
  const [connectorSsl,setConnectorSsl]=useState('require');
  const [connectorOptionsText,setConnectorOptionsText]=useState('{}');
  const [selectedConnector,setSelectedConnector]=useState('');
  const [discovery,setDiscovery]=useState<AnyObj|null>(null);
  const [sourceName,setSourceName]=useState('');
  const [sourceKind,setSourceKind]=useState('table');
  const [tableName,setTableName]=useState('');
  const [sourceQuery,setSourceQuery]=useState('');
  const [refreshMode,setRefreshMode]=useState('full');
  const [incrementalColumn,setIncrementalColumn]=useState('');
  const [slaMinutes,setSlaMinutes]=useState('1440');
  const [driftPolicy,setDriftPolicy]=useState('warn');
  const [sourceOptionsText,setSourceOptionsText]=useState('{}');
  const [preview,setPreview]=useState<AnyObj|null>(null);
  const [previewTitle,setPreviewTitle]=useState('');
  const [runFilter,setRunFilter]=useState('');

  const activeWorkspace=(session?.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId);
  const role=activeWorkspace?.role??'';
  const canManage=['owner','admin'].includes(role);
  const canRefresh=['owner','admin','data_scientist'].includes(role);
  const connectorSpec=connectorCatalog.find((c:AnyObj)=>c.key===connectorType)??null;
  const connectorOptions=connectorSpec?.options??[];
  const selectedConnectorRecord=(overview.connectors??[]).find((c:AnyObj)=>c.id===selectedConnector);
  const selectedConnectorType=selectedConnectorRecord?.connector_type??'';
  const connectorLogo=(type:string)=>({postgresql:'PG',mysql:'MY',mariadb:'MA',sqlite:'SQ',sqlserver:'MS',oracle:'OR',redshift:'RS',snowflake:'SF',databricks:'DB',bigquery:'BQ',mongodb:'MO',s3:'S3',gcs:'GS',azure_blob:'AZ'} as AnyObj)[type]??String(type||'?').slice(0,2).toUpperCase();

  async function load(t=token,ws=workspaceId){
    if(!t||!ws)return;
    setBusy(true);
    try{
      const [catalog,o,h,r]=await Promise.all([getConnectorCatalog(t,ws),getConnectorOverview(t,ws),getConnectorHealth(t,ws),getRefreshRuns(t,ws,runFilter||undefined)]);
      setConnectorCatalog(catalog.connectors??[]);setOverview(o);setHealth(h);setRuns(r.runs??[]);
      if(!selectedConnector&&o.connectors?.[0]?.id)setSelectedConnector(o.connectors[0].id);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }
  useEffect(()=>{
    if(typeof window==='undefined')return;
    const t=sessionStorage.getItem('dv_enterprise_token')||'';
    const stored=localStorage.getItem('dv_enterprise_workspace')||'';
    setToken(t);
    if(!t)return;
    getEnterpriseSession(t).then(s=>{setSession(s);const ws=stored||s.workspaces?.[0]?.id||'';setWorkspaceId(ws);}).catch(()=>{setToken('');setSession(null);});
  },[]);
  useEffect(()=>{if(token&&workspaceId)load(token,workspaceId);},[token,workspaceId,runFilter]);

  function changeWorkspace(id:string){
    setWorkspaceId(id);setDiscovery(null);setPreview(null);setRunFilter('');
    if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',id);window.dispatchEvent(new Event('datavision-enterprise-session'));}
  }
  function changeConnectorType(type:string){
    setConnectorType(type);
    const spec=connectorCatalog.find((c:AnyObj)=>c.key===type);
    setConnectorPort(String(spec?.default_port??''));
    setConnectorHost('');
    setConnectorDb('');
    setConnectorUser('');
    setConnectorPassword('');
    const options:AnyObj={};
    for(const key of (spec?.options??[]))options[key]='';
    setConnectorOptionsText(JSON.stringify(options,null,2));
    setConnectorSsl(type==='sqlite'||type==='bigquery'?'prefer':'require');
  }

  async function createConnector(){
    if(!token||!workspaceId)return;
    setBusy(true);setNotice('');
    try{
      let options:AnyObj={};
      try{options=connectorOptionsText.trim()?JSON.parse(connectorOptionsText):{};}catch{throw new Error('Options JSON invalides.');}
      if(connectorSpec?.host_required&&!connectorHost.trim())throw new Error(`Hôte requis pour ${connectorSpec.label}.`);
      if(connectorSpec?.database_required&&!connectorDb.trim())throw new Error(`Base / projet requis pour ${connectorSpec.label}.`);
      if(connectorSpec?.username_required&&!connectorUser.trim())throw new Error(`Utilisateur requis pour ${connectorSpec.label}.`);
      if(connectorSpec?.secret_required&&!connectorPassword)throw new Error(`${connectorSpec.secret_label} requis.`);
      const r=await createDataConnector(token,workspaceId,{
        name:connectorName,connector_type:connectorType,host:connectorHost,
        port:Number(connectorPort)||Number(connectorSpec?.default_port??0)||null,
        database:connectorDb,username:connectorUser,password:connectorPassword,
        ssl_mode:connectorSsl,options,
      });
      setConnectorPassword('');setSelectedConnector(r.connector.id);setShowConnectorForm(false);
      setNotice('Connecteur enregistré. Testez la connexion avant de créer une source.');
      await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function testConnector(id:string){
    setBusy(true);setNotice('');
    try{const r=await testDataConnector(token,workspaceId,id);setNotice(r.ok?'Connexion validée.':`Échec de connexion : ${r.error??'erreur inconnue'}`);await load();}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function discoverConnector(id:string){
    setBusy(true);setNotice('');
    try{const r=await discoverDataConnector(token,workspaceId,id);setSelectedConnector(id);setDiscovery(r);setNotice(`${r.tables?.length??0} objets découverts.`);}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  function useTable(table:AnyObj){
    setSelectedConnector(discovery?.connector?.id??selectedConnector);setSourceKind(table.kind==='collection'?'collection':table.kind==='object'?'object':'table');setTableName(table.qualified_name);setSourceName(table.name);setShowSourceForm(true);
    const candidate=(table.columns??[]).find((c:AnyObj)=>/(updated|created|date|time|timestamp|id)$/i.test(String(c.name)))?.name??'';
    setIncrementalColumn(candidate);
  }
  async function createSource(){
    if(!token||!workspaceId||!selectedConnector||!sourceName)return;
    setBusy(true);setNotice('');
    try{
      const objectStorage=['s3','gcs','azure_blob'].includes(selectedConnectorType);
      const effectiveSourceKind=objectStorage?'object':selectedConnectorType==='mongodb'?'collection':sourceKind;
      let sourceOptions:AnyObj={};
      try{sourceOptions=sourceOptionsText.trim()?JSON.parse(sourceOptionsText):{};}catch{throw new Error('Options source JSON invalides.');}
      if(refreshMode==='cdc'&&!sourceOptions.primary_key)throw new Error('Le mode CDC requiert source_options.primary_key, par ex. {"primary_key":["id"]}.');
      await createConnectorSource(token,workspaceId,{connector_id:selectedConnector,name:sourceName,source_kind:effectiveSourceKind,table_name:effectiveSourceKind==='query'?null:tableName,query:effectiveSourceKind==='query'?sourceQuery:null,refresh_mode:objectStorage?'full':refreshMode,incremental_column:refreshMode==='incremental'?incrementalColumn:null,freshness_sla_minutes:Number(slaMinutes)||1440,schema_drift_policy:driftPolicy,source_options:sourceOptions});
      setShowSourceForm(false);setSourceName('');setTableName('');setSourceQuery('');setSourceOptionsText('{}');setNotice(refreshMode==='cdc'?'Source CDC créée. Envoyez les événements log-based sur son endpoint CDC.':'Source créée. Lancez le premier refresh pour matérialiser le dataset.');await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function refreshSource(source:AnyObj){
    if(!canRefresh)return;
    setBusy(true);setNotice('');
    try{const r=await refreshConnectorSource(token,workspaceId,source.id,true);setNotice(`Refresh placé en file${r.job?.id?` · job ${String(r.job.id).slice(0,8)}`:''}. Le worker créera une nouvelle version immuable.`);await load();}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function previewSource(source:AnyObj){
    setBusy(true);
    try{setPreview(await previewConnectorSource(token,workspaceId,source.id,25));setPreviewTitle(source.name);}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function setSchedule(source:AnyObj,minutes:number){
    if(!canManage)return;
    setBusy(true);
    try{await saveConnectorSchedule(token,workspaceId,source.id,minutes>0,minutes>0?minutes:1440);setNotice(minutes>0?`Refresh planifié toutes les ${minutes} minutes.`:'Planification désactivée.');await load();}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  async function removeSource(source:AnyObj){
    if(!canManage||!confirm(`Supprimer la source « ${source.name} » ? Les datasets déjà matérialisés restent immuables.`))return;
    setBusy(true);try{await deleteConnectorSource(token,workspaceId,source.id);setNotice('Source supprimée.');await load();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }

  if(!token||!session)return <div className="page sources-page"><div className="page-title"><div><span className="eyebrow">DATA SOURCES · CLOUD · CDC · OBSERVABILITY</span><h1>Sources & Refresh</h1><p>Connecteurs gouvernés, object storage cloud, CDC log-based, refresh incrémental et surveillance de fraîcheur.</p></div><span className="module-state implemented">v2.7</span></div><div className="collab-auth-empty"><span>↻</span><div><h3>Session Entreprise requise</h3><p>Les credentials et les planifications sont isolés par workspace et nécessitent une identité auditée.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;

  const sources=overview.sources??[],connectors=overview.connectors??[];
  const fresh=health?.freshness?.fresh??0,stale=(health?.freshness?.stale??0)+(health?.freshness?.error??0);
  return <div className="page sources-page">
    <div className="page-title"><div><span className="eyebrow">DATA SOURCES & REFRESH · V2.75</span><h1>Sources & Refresh</h1><p>Centralisez SQL, warehouses et object storage, matérialisez des versions immuables et reprenez les flux CDC depuis leurs checkpoints.</p></div><div className="sources-head-actions"><label>Workspace<select value={workspaceId} onChange={e=>changeWorkspace(e.target.value)}>{(session.workspaces??[]).map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><button className="secondary-btn" onClick={()=>load()} disabled={busy}>↻ Actualiser</button>{canManage&&<button className="primary-btn" onClick={()=>setShowConnectorForm(v=>!v)}>+ Connecteur</button>}</div></div>
    {notice&&<div className="source-notice"><span>◎</span><p>{notice}</p><button onClick={()=>setNotice('')}>×</button></div>}
    <div className="sources-scorecards"><Stat label="Connecteurs" value={health?.connectors??0} detail={`${health?.connector_errors??0} en erreur`}/><Stat label="Sources" value={health?.sources??0} detail={`${health?.scheduled??0} planifiée(s)`}/><Stat label="Fraîches" value={fresh} detail={`${stale} stale / erreur`}/><Stat label="Succès refresh" value={health?.success_rate==null?'—':`${health.success_rate}%`} detail={`${health?.runs_considered??0} exécution(s)`}/><Stat label="Lignes ingérées" value={formatNumber(health?.rows_fetched??0,0)} detail={health?.avg_duration_seconds==null?'Durée n/a':`Ø ${formatNumber(health.avg_duration_seconds,1)} s`}/></div>

    {showConnectorForm&&<Panel title="Nouveau connecteur sécurisé" action={<span className="quiet">Le secret est chiffré avant stockage. Les options JSON ne doivent jamais contenir de secret.</span>}><div className="connector-form-grid"><label>Nom<input value={connectorName} onChange={e=>setConnectorName(e.target.value)}/></label><label>Moteur<select value={connectorType} onChange={e=>changeConnectorType(e.target.value)}>{(connectorCatalog.length?connectorCatalog:[{key:'postgresql',label:'PostgreSQL',default_port:5432,driver_available:true},{key:'mysql',label:'MySQL',default_port:3306,driver_available:true}]).map((spec:AnyObj)=><option key={spec.key} value={spec.key}>{spec.label}{spec.driver_available===false?' · driver absent':''}</option>)}</select></label>{(connectorSpec?.host_required!==false||connectorType==='s3')&&<label>Hôte / compte<input value={connectorHost} onChange={e=>setConnectorHost(e.target.value)} placeholder={connectorType==='snowflake'?'org-account':connectorType==='databricks'?'dbc-xxxx.cloud.databricks.com':connectorType==='s3'?'https://minio.company.internal (optionnel)':connectorType==='azure_blob'?'https://account.blob.core.windows.net':'db.company.internal'}/></label>}{(connectorSpec?.default_port??0)>0&&<label>Port<input value={connectorPort} onChange={e=>setConnectorPort(e.target.value)}/></label>}<label>{connectorType==='bigquery'?'Projet':connectorType==='s3'||connectorType==='gcs'?'Bucket':connectorType==='azure_blob'?'Container':connectorType==='sqlite'?'Fichier SQLite':connectorType==='databricks'?'Catalog (optionnel)':'Base'}<input value={connectorDb} onChange={e=>setConnectorDb(e.target.value)} placeholder={connectorType==='sqlite'?'warehouse.db':connectorType==='bigquery'?'my-gcp-project':connectorType==='s3'||connectorType==='gcs'?'analytics-bucket':connectorType==='azure_blob'?'analytics-container':''}/></label>{(connectorSpec?.username_required!==false||connectorType==='s3')&&<label>Utilisateur<input value={connectorUser} onChange={e=>setConnectorUser(e.target.value)}/></label>}{connectorType!=='sqlite'&&<label>{connectorSpec?.secret_label??'Secret'}<textarea className={connectorType==='bigquery'?'connector-secret-json':''} value={connectorPassword} onChange={e=>setConnectorPassword(e.target.value)} placeholder={connectorType==='bigquery'?'JSON service account ou vide pour ADC':''}/></label>}{!['sqlite','bigquery'].includes(connectorType)&&<label>TLS<select value={connectorSsl} onChange={e=>setConnectorSsl(e.target.value)}><option value="require">Require</option><option value="prefer">Prefer</option><option value="disable">Disable</option></select></label>}{connectorOptions.length>0&&<label className="span-2">Options non secrètes JSON<textarea value={connectorOptionsText} onChange={e=>setConnectorOptionsText(e.target.value)} spellCheck={false}/><small>{connectorOptions.join(' · ')}</small></label>}<div className="connector-form-actions"><button className="secondary-btn" onClick={()=>setShowConnectorForm(false)}>Annuler</button><button className="primary-btn" onClick={createConnector} disabled={busy}>Enregistrer</button></div></div>{connectorSpec&&<div className="connector-driver-note"><b>{connectorSpec.label}</b><span>{connectorSpec.docs_hint}</span><em className={connectorSpec.driver_available?'available':'missing'}>{connectorSpec.driver_available?'driver disponible':'driver absent dans ce runtime'}</em></div>}</Panel>}

    <div className="sources-main-grid">
      <section className="source-column">
        <div className="source-section-head"><div><span>CONNEXIONS</span><h3>Connecteurs</h3></div><small>{connectors.length} configuré(s)</small></div>
        <div className="connector-list">{connectors.map((c:AnyObj)=><article key={c.id} className={`connector-card ${selectedConnector===c.id?'selected':''}`} onClick={()=>setSelectedConnector(c.id)}><div className="connector-logo">{connectorLogo(c.connector_type)}</div><div className="connector-copy"><div><b>{c.name}</b><span className={`connector-status ${c.status}`}>{c.status}</span></div><p>{c.host?`${c.host}${c.port?`:${c.port}`:''} · ${c.database_name||'—'}`:c.database_name||'Connexion gouvernée'}</p><small>{c.connector_type}{c.username?` · ${c.username}`:''}{c.ssl_mode?` · TLS ${c.ssl_mode}`:''}{c.last_tested_at?` · testé ${new Date(c.last_tested_at).toLocaleString('fr-FR')}`:''}</small>{c.last_error&&<em>{c.last_error}</em>}</div><div className="connector-actions">{canManage&&<button onClick={e=>{e.stopPropagation();testConnector(c.id)}} disabled={busy}>Tester</button>}<button onClick={e=>{e.stopPropagation();discoverConnector(c.id)}} disabled={busy}>Explorer</button></div></article>)}{!connectors.length&&<div className="quiet-empty">Aucun connecteur. Ajoutez une base SQL/NoSQL, un cloud warehouse ou un object storage.</div>}</div>

        {discovery&&<div className="discovery-panel"><div className="source-section-head"><div><span>CATALOGUE SOURCE</span><h3>{discovery.connector?.name}</h3></div><button className="ghost-btn" onClick={()=>setDiscovery(null)}>Fermer</button></div><div className="discovered-tables">{(discovery.tables??[]).map((t:AnyObj)=><button key={t.qualified_name} onClick={()=>useTable(t)}><span>▦</span><div><b>{t.qualified_name}</b><small>{t.columns?.length??0} colonnes · {(t.columns??[]).slice(0,4).map((c:AnyObj)=>c.name).join(', ')}</small></div><i>+ Source</i></button>)}</div></div>}
      </section>

      <section className="source-column source-wide">
        <div className="source-section-head"><div><span>DATA PRODUCTS</span><h3>Sources matérialisées</h3></div>{canManage&&<button className="secondary-btn" onClick={()=>setShowSourceForm(v=>!v)} disabled={!connectors.length}>+ Nouvelle source</button>}</div>
        {showSourceForm&&<div className="source-compose"><div className="source-compose-grid"><label>Connecteur<select value={selectedConnector} onChange={e=>setSelectedConnector(e.target.value)}>{connectors.map((c:AnyObj)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Nom logique<input value={sourceName} onChange={e=>setSourceName(e.target.value)} placeholder="Ventes quotidiennes"/></label><label>Source<select value={['s3','gcs','azure_blob'].includes(selectedConnectorType)?'object':selectedConnectorType==='mongodb'?'collection':sourceKind} onChange={e=>setSourceKind(e.target.value)} disabled={selectedConnectorType==='mongodb'||['s3','gcs','azure_blob'].includes(selectedConnectorType)}>{['s3','gcs','azure_blob'].includes(selectedConnectorType)?<option value="object">Objet cloud</option>:selectedConnectorType==='mongodb'?<option value="collection">Collection MongoDB</option>:<><option value="table">Table</option><option value="query">Requête SQL read-only</option></>}</select></label>{sourceKind==='query'&&selectedConnectorType!=='mongodb'&&!['s3','gcs','azure_blob'].includes(selectedConnectorType)?<label className="span-2">Requête<textarea value={sourceQuery} onChange={e=>setSourceQuery(e.target.value)} placeholder="SELECT ..."/></label>:<label>{['s3','gcs','azure_blob'].includes(selectedConnectorType)?'Clé objet':selectedConnectorType==='mongodb'?'Collection':'Table qualifiée'}<input value={tableName} onChange={e=>setTableName(e.target.value)} placeholder={['s3','gcs','azure_blob'].includes(selectedConnectorType)?'exports/sales.parquet':selectedConnectorType==='mongodb'?'orders':'public.sales'}/></label>}<label>Refresh<select value={['s3','gcs','azure_blob'].includes(selectedConnectorType)?'full':refreshMode} onChange={e=>setRefreshMode(e.target.value)} disabled={['s3','gcs','azure_blob'].includes(selectedConnectorType)}><option value="full">Full refresh</option>{!['s3','gcs','azure_blob'].includes(selectedConnectorType)&&<><option value="incremental">Incremental</option><option value="cdc">CDC log-based</option></>}</select></label>{refreshMode==='incremental'&&<label>Colonne watermark<input value={incrementalColumn} onChange={e=>setIncrementalColumn(e.target.value)} placeholder="updated_at ou id"/></label>}<label>SLA fraîcheur<select value={slaMinutes} onChange={e=>setSlaMinutes(e.target.value)}><option value="60">1 heure</option><option value="360">6 heures</option><option value="720">12 heures</option><option value="1440">24 heures</option><option value="10080">7 jours</option></select></label><label>Schema drift<select value={driftPolicy} onChange={e=>setDriftPolicy(e.target.value)}><option value="warn">Avertir</option><option value="fail">Bloquer changements destructifs</option></select></label><label className="span-2">Options source JSON<textarea value={sourceOptionsText} onChange={e=>setSourceOptionsText(e.target.value)} spellCheck={false} placeholder={refreshMode==='cdc'?'{"primary_key":["id"]}':sourceKind==='object'?'{"format":"parquet"}':'{}'}/><small>CDC : primary_key obligatoire · Object storage : format/delimiter/sheet_name optionnels.</small></label></div><div className="source-compose-actions"><small>Chaque refresh ou lot CDC crée une nouvelle version immuable. Les flux CDC reprennent depuis un checkpoint par partition et dédupliquent les event_id.</small><button className="primary-btn" onClick={createSource} disabled={busy||!selectedConnector}>Créer la source</button></div></div>}
        <div className="source-list">{sources.map((src:AnyObj)=>{const f=src.freshness??{};const sch=src.schedule;return <article key={src.id} className="source-card"><div className="source-card-head"><div><span className={`freshness-dot ${f.status}`}/><div><b>{src.name}</b><small>{src.refresh_mode==='cdc'?'CDC log-based':src.refresh_mode==='incremental'?`Incremental · ${src.incremental_column}`:'Full refresh'} · SLA {f.sla_minutes} min</small></div></div><span className={`freshness-pill ${f.status}`}>{f.status}</span></div><div className="source-card-metrics"><div><span>Dataset actif</span><b>{src.dataset_id?String(src.dataset_id).slice(0,8):'Non matérialisé'}</b></div><div><span>Dernier succès</span><b>{src.last_success_at?new Date(src.last_success_at).toLocaleString('fr-FR'):'Jamais'}</b></div><div><span>Âge</span><b>{f.age_minutes==null?'—':`${f.age_minutes} min`}</b></div><div><span>Lignes dernier run</span><b>{formatNumber(src.last_rows_fetched??0,0)}</b></div></div>{src.schema_drift?.detected&&<div className="schema-drift-note">Schema drift détecté lors du dernier refresh.</div>}{src.last_error&&<div className="source-error">{src.last_error}</div>}<div className="source-card-actions">{canManage&&src.refresh_mode!=='cdc'&&<button onClick={()=>previewSource(src)} disabled={busy}>Aperçu source</button>}{src.dataset_id&&<button onClick={()=>onActivate(src.dataset_id)}>Ouvrir dataset</button>}{canRefresh&&src.refresh_mode!=='cdc'&&<button className="accent-action" onClick={()=>refreshSource(src)} disabled={busy}>↻ Refresh</button>}{src.refresh_mode==='cdc'&&<span className="cdc-source-badge">CDC PUSH · checkpointed</span>}{canManage&&src.refresh_mode!=='cdc'&&<label>Planification<select value={sch?.enabled?String(sch.interval_minutes):'0'} onChange={e=>setSchedule(src,Number(e.target.value))}><option value="0">Désactivée</option><option value="60">Toutes les heures</option><option value="360">Toutes les 6 h</option><option value="720">Toutes les 12 h</option><option value="1440">Quotidienne</option><option value="10080">Hebdomadaire</option></select></label>}{canManage&&<button className="danger-link" onClick={()=>removeSource(src)}>Supprimer</button>}</div></article>})}{!sources.length&&<div className="quiet-empty source-empty">Aucune source matérialisée. Explorez un connecteur, choisissez une table puis créez une source.</div>}</div>
      </section>
    </div>

    <div className="source-observability-grid"><Panel title="Observabilité des refresh" action={<select value={runFilter} onChange={e=>setRunFilter(e.target.value)}><option value="">Toutes les sources</option>{sources.map((s:AnyObj)=><option key={s.id} value={s.id}>{s.name}</option>)}</select>}><div className="refresh-run-table"><div className="refresh-run-row header"><span>Statut</span><span>Source</span><span>Mode</span><span>Lignes</span><span>Déclencheur</span><span>Début</span><span>Durée</span></div>{runs.slice(0,30).map((r:AnyObj)=>{const a=r.started_at?new Date(r.started_at).getTime():0,b=r.finished_at?new Date(r.finished_at).getTime():0;const source=sources.find((x:AnyObj)=>x.id===r.source_id);return <div className="refresh-run-row" key={r.id}><span><i className={`run-status ${r.status}`}/>{r.status}</span><span>{source?.name??String(r.source_id).slice(0,8)}</span><span>{r.mode}</span><span>{formatNumber(r.rows_fetched??0,0)}</span><span>{r.trigger_type}</span><span>{r.started_at?new Date(r.started_at).toLocaleString('fr-FR'):'—'}</span><span>{a&&b?`${Math.max(0,(b-a)/1000).toFixed(1)} s`:'—'}</span>{r.error&&<em>{r.error}</em>}</div>})}{!runs.length&&<div className="quiet-empty">Aucun refresh exécuté.</div>}</div></Panel><Panel title="Contrats de fraîcheur"><div className="freshness-contracts"><div><b>Fresh</b><p>Dernier succès dans le SLA déclaré.</p></div><div><b>Warning</b><p>Plus de 80 % du SLA consommé.</p></div><div><b>Stale</b><p>Le SLA est dépassé : le dataset peut être obsolète.</p></div><div><b>Error</b><p>Le dernier refresh a échoué. La dernière version valide reste disponible.</p></div><small>Le scheduler du worker revendique atomiquement les échéances avant de soumettre un job Redis afin d’éviter les doubles déclenchements entre workers.</small></div></Panel></div>

    {preview&&<div className="source-preview-overlay" onMouseDown={e=>{if(e.target===e.currentTarget)setPreview(null)}}><div className="source-preview-modal"><div className="source-section-head"><div><span>APERÇU READ-ONLY</span><h3>{previewTitle}</h3></div><button className="ghost-btn" onClick={()=>setPreview(null)}>Fermer</button></div><div className="table-wrap"><table><thead><tr>{(preview.columns??[]).map((c:string)=><th key={c}>{c}</th>)}</tr></thead><tbody>{(preview.rows??[]).map((row:AnyObj,i:number)=><tr key={i}>{(preview.columns??[]).map((c:string)=><td key={c}>{row[c]==null?'—':String(row[c])}</td>)}</tr>)}</tbody></table></div></div></div>}
  </div>;
}

function OperationalIntelligenceCenter({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [overview,setOverview]=useState<AnyObj|null>(null);
  const [sre,setSre]=useState<AnyObj|null>(null);
  const [performance,setPerformance]=useState<AnyObj|null>(null);
  const [usage,setUsage]=useState<AnyObj|null>(null);
  const [events,setEvents]=useState<AnyObj[]>([]);
  const [suites,setSuites]=useState<AnyObj[]>([]);
  const [activeSuite,setActiveSuite]=useState<AnyObj|null>(null);
  const [latestRun,setLatestRun]=useState<AnyObj|null>(null);
  const [busy,setBusy]=useState(false);
  const [hours,setHours]=useState(24);
  const [suiteName,setSuiteName]=useState('Régression AI Analyst');
  const [question,setQuestion]=useState('Analyse ce dataset et résume les principaux constats.');
  const [expectedIntent,setExpectedIntent]=useState('overview');
  const [requiredTools,setRequiredTools]=useState('profile, quality');
  const [answerContains,setAnswerContains]=useState('');
  const [minFindings,setMinFindings]=useState('1');

  async function refresh(t=token,ws=workspaceId){
    if(!t||!ws)return;setBusy(true);
    try{
      const [o,s,p,u,e,ev]=await Promise.all([getOperationalOverview(t,ws,hours),getSREStatus(t,ws,hours),getPerformanceEvidence(t,ws),getOperationalUsage(t,ws,720),getOperationalTelemetry(t,ws,hours,80),getEvaluationSuites(t,ws)]);
      setOverview(o);setSre(s);setPerformance(p);setUsage(u);setEvents(e.events??[]);setSuites(ev.suites??[]);
      if(activeSuite?.id){try{const detail=await getEvaluationSuite(t,ws,activeSuite.id);setActiveSuite(detail.suite);}catch{setActiveSuite(null)}}
    }catch(err:unknown){setError(err instanceof Error?err.message:String(err));}finally{setBusy(false)}
  }
  useEffect(()=>{if(typeof window==='undefined')return;const t=sessionStorage.getItem('dv_enterprise_token')||'';const stored=localStorage.getItem('dv_enterprise_workspace')||'';if(!t)return;setToken(t);getEnterpriseSession(t).then(s=>{setSession(s);const ws=stored||s.workspaces?.[0]?.id||'';setWorkspaceId(ws);if(ws)refresh(t,ws)}).catch(()=>setSession(null));},[]);
  useEffect(()=>{if(token&&workspaceId)refresh(token,workspaceId);},[hours]);
  async function changeWorkspace(ws:string){setWorkspaceId(ws);setActiveSuite(null);setLatestRun(null);if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',ws);window.dispatchEvent(new Event('datavision-enterprise-session'));}await refresh(token,ws)}
  async function createSuite(){if(!result||!token||!workspaceId)return;setBusy(true);try{const r=await createEvaluationSuite(token,workspaceId,{dataset_id:result.dataset.id,name:suiteName,description:'Suite de non-régression créée depuis Operational Intelligence'});setActiveSuite(r.suite);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function selectSuite(id:string){if(!token||!workspaceId)return;try{const r=await getEvaluationSuite(token,workspaceId,id);setActiveSuite(r.suite);const lr=r.suite?.latest_run;if(lr?.id){try{const rr=await getEvaluationRun(token,workspaceId,lr.id);setLatestRun(rr.run);}catch{setLatestRun(lr)}}else setLatestRun(null);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function addCase(){if(!activeSuite||!token||!workspaceId||!question.trim())return;setBusy(true);try{const expectations:AnyObj={};if(expectedIntent.trim())expectations.expected_intent=expectedIntent.trim();const tools=requiredTools.split(',').map(x=>x.trim()).filter(Boolean);if(tools.length)expectations.required_tools=tools;const words=answerContains.split(',').map(x=>x.trim()).filter(Boolean);if(words.length)expectations.answer_contains=words;if(minFindings.trim())expectations.min_findings=Math.max(0,Number(minFindings)||0);await addEvaluationCase(token,workspaceId,activeSuite.id,{question,expectations});await selectSuite(activeSuite.id);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function runSuite(){if(!activeSuite||!token||!workspaceId)return;setBusy(true);try{const r=await runEvaluationSuite(token,workspaceId,activeSuite.id);setLatestRun(r.run);await selectSuite(activeSuite.id);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function evaluateSRE(){if(!token||!workspaceId)return;setBusy(true);try{const r=await emitSREAlerts(token,workspaceId,hours);setSre(r);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function runPerformanceSmoke(){if(!token||!workspaceId)return;setBusy(true);try{const r=await runLocalPerformanceBenchmark(token,workspaceId,{profile:'local_smoke',rows:20000,samples:8});setPerformance(r.status);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  if(!session||!token)return <div className="page operational-page"><div className="page-title"><div><span className="eyebrow">OBSERVABILITY · EVALUATION · SLO</span><h1>Operational Intelligence</h1><p>Mesurez la santé réelle de DataVision, les fonctions effectivement utilisées et la stabilité de l’AI Analyst.</p></div><span className="module-state implemented">v2.9</span></div><div className="collab-auth-empty"><span>◉</span><div><h3>Session Entreprise requise</h3><p>La télémétrie et les évaluations sont isolées par workspace et nécessitent une identité auditée.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;
  const slo=overview?.slo?.indicators??{};const features=usage?.features??[];const currentRole=(session.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId)?.role??'viewer';
  return <div className="page operational-page">
    <div className="page-title"><div><span className="eyebrow">OPERATIONAL INTELLIGENCE · PERFORMANCE & SLO V2.77</span><h1>Observabilité & Evaluation</h1><p>SLO, budgets d’erreur, preuves de charge, sauvegardes, restore drills et tests de non-régression dans un même cockpit gouverné.</p></div><div className="operations-head-actions"><label>Workspace<select value={workspaceId} onChange={e=>changeWorkspace(e.target.value)}>{(session.workspaces??[]).map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><label>Fenêtre<select value={hours} onChange={e=>setHours(Number(e.target.value))}><option value={6}>6 h</option><option value={24}>24 h</option><option value={168}>7 j</option><option value={720}>30 j</option></select></label><button className="secondary-btn" onClick={()=>refresh()} disabled={busy}>↻ Actualiser</button></div></div>
    <div className="operations-scorecards"><Stat label="API availability" value={overview?.api?.availability_pct==null?'—':`${formatNumber(overview.api.availability_pct,2)}%`} detail={`${overview?.api?.requests??0} requêtes`}/><Stat label="P95 API" value={overview?.api?.p95_latency_ms==null?'—':`${formatNumber(overview.api.p95_latency_ms,0)} ms`} detail={`objectif ≤ ${slo.api_p95_latency?.target??750} ms`}/><Stat label="Job success" value={overview?.jobs?.success_rate_pct==null?'—':`${formatNumber(overview.jobs.success_rate_pct,1)}%`} detail={`${overview?.jobs?.retry_wait??0} en retry`}/><Stat label="Refresh success" value={overview?.refresh?.success_rate_pct==null?'—':`${formatNumber(overview.refresh.success_rate_pct,1)}%`} detail={`${overview?.refresh?.runs??0} exécution(s)`}/><Stat label="AI Eval" value={overview?.evaluation?.score==null?'—':`${formatNumber(overview.evaluation.score,0)}/100`} detail={overview?.evaluation?.status??'aucun benchmark'}/></div>
    <div className="operations-slo-strip"><div><span className={`ops-health ${overview?.slo?.status??'neutral'}`}/><b>SLO {overview?.slo?.status==='healthy'?'sains':'à surveiller'}</b><small>{overview?.slo?.met??0}/{overview?.slo?.total??4} objectifs respectés sur la fenêtre sélectionnée.</small></div>{Object.entries(slo).map(([key,v]:[string,any])=><span key={key} className={v.met?'slo-chip ok':'slo-chip warn'}>{v.met?'✓':'!'} {key.replaceAll('_',' ')} · {v.value==null?'—':formatNumber(v.value,2)} {v.unit}</span>)}</div>
    <div className="sre-operations-grid"><Panel title="Posture SRE" action={<button className="secondary-btn" onClick={evaluateSRE} disabled={busy||!['owner','admin'].includes(currentRole)}>Évaluer & notifier</button>}><div className="sre-status-head"><span className={`ops-health ${sre?.status==='healthy'?'healthy':'attention'}`}/><div><b>{sre?.status==='healthy'?'Plateforme dans les objectifs':'Attention SRE requise'}</b><small>{sre?.alerts?.length??0} alerte(s) active(s)</small></div></div><div className="sre-kpi-grid"><div><span>Budget d’erreur restant</span><b>{sre?.error_budget?.remaining_bad_minutes==null?'—':`${formatNumber(sre.error_budget.remaining_bad_minutes,1)} min`}</b><small>burn {sre?.error_budget?.burn_rate==null?'—':`${formatNumber(sre.error_budget.burn_rate,2)}×`}</small></div><div><span>File jobs</span><b>{sre?.queue?.queue_depth??'—'}</b><small>{sre?.autoscaling?.worker_mode??'cpu'} · seuil {sre?.autoscaling?.queue_alert_depth??25}</small></div><div><span>Dernier backup</span><b>{sre?.backup?.status??'absent'}</b><small>{sre?.backup?.age_hours==null?'—':`${formatNumber(sre.backup.age_hours,1)} h`}</small></div><div><span>Restore drill</span><b>{sre?.restore_drill?.status??'absent'}</b><small>{sre?.restore_drill?.age_hours==null?'—':`${formatNumber(sre.restore_drill.age_hours,1)} h`}</small></div></div><div className="sre-alert-list">{(sre?.alerts??[]).slice(0,6).map((a:AnyObj)=><div key={a.code} className={`sre-alert ${a.severity}`}><b>{a.title}</b><span>{a.detail}</span></div>)}{!(sre?.alerts??[]).length&&<div className="quiet-empty">Aucune alerte SRE active sur cette fenêtre.</div>}</div></Panel><Panel title="Sauvegarde & exploitation"><div className="sre-ops-list"><div><span>Stockage objet</span><b>{sre?.object_store?.enabled?(sre?.object_store?.configured?'S3-compatible prêt':'configuration incomplète'):'désactivé'}</b><small>{sre?.object_store?.bucket??'backup local conservé'}</small></div><div><span>Autoscaling worker</span><b>{sre?.autoscaling?.worker_mode??'cpu'}</b><small>{sre?.autoscaling?.queue_name??'datavision:jobs'}</small></div><div><span>Chaos contrôlé</span><b>{sre?.chaos?.enabled?'activé':'désactivé par défaut'}</b><small>maximum {sre?.chaos?.max_probe_jobs??20} probes</small></div></div></Panel></div>
    <div className="performance-evidence-grid"><Panel title="Performance & SLO Evidence" action={<button className="secondary-btn" onClick={runPerformanceSmoke} disabled={busy||!['owner','admin'].includes(currentRole)}>Exécuter benchmark local</button>}><div className="performance-evidence-head"><span className={`ops-health ${performance?.production_evidence_status==='passed'?'healthy':'attention'}`}/><div><b>Preuve production : {performance?.production_evidence_status??'not_evidenced'}</b><small>Le benchmark local valide la non-régression mais ne remplace jamais une mesure sur cible production.</small></div></div><div className="sre-kpi-grid"><div><span>Local smoke</span><b>{performance?.latest_local?.status??'non exécuté'}</b><small>{performance?.latest_local?.metrics?.dataframe_groupby_p95_ms==null?'—':`groupby p95 ${formatNumber(performance.latest_local.metrics.dataframe_groupby_p95_ms,1)} ms`}</small></div><div><span>Production target</span><b>{performance?.latest_production?.status??'aucune preuve'}</b><small>{performance?.latest_production?.metrics?.request_p95_ms==null?'import requis':`p95 ${formatNumber(performance.latest_production.metrics.request_p95_ms,0)} ms`}</small></div><div><span>Débit cible</span><b>{performance?.latest_production?.metrics?.throughput_rps==null?'—':`${formatNumber(performance.latest_production.metrics.throughput_rps,1)} req/s`}</b><small>profil production_standard</small></div><div><span>Intégrité</span><b>{performance?.latest_production?.artifact_sha256?`${String(performance.latest_production.artifact_sha256).slice(0,12)}…`:'—'}</b><small>SHA-256 de la preuve gouvernée</small></div></div><div className="performance-budget-list">{((performance?.profiles?.production_standard?.budgets??[]) as AnyObj[]).map((b:AnyObj)=><span key={b.metric}>{b.metric} {b.operator} {b.threshold} {b.unit}</span>)}</div></Panel></div>
    <div className="two-col operations-grid"><Panel title="Fonctionnalités réellement utilisées" action={<span className="quiet">30 jours · {usage?.total_events??0} événements</span>}>{features.length?<BarChart rows={features.slice(0,10).map((x:AnyObj)=>({...x,label:x.feature}))} valueKey="uses" labelKey="label"/>:<div className="quiet-empty">La télémétrie se remplira à mesure que le workspace est utilisé.</div>}<div className="feature-usage-list">{features.slice(0,8).map((x:AnyObj)=><div key={x.feature}><b>{x.feature}</b><span>{x.uses} usages · {x.users} utilisateur(s)</span><small>{formatNumber(x.share_pct,1)}% du trafic instrumenté · {formatNumber(x.avg_latency_ms??0,0)} ms moyen</small></div>)}</div></Panel><Panel title="Usage IA & coûts instrumentés"><div className="ai-ops-card"><span>INPUT TOKENS</span><b>{formatNumber(overview?.ai_usage?.input_tokens??0,0)}</b><span>OUTPUT TOKENS</span><b>{formatNumber(overview?.ai_usage?.output_tokens??0,0)}</b><span>COÛT ESTIMÉ</span><b>${formatNumber(overview?.ai_usage?.estimated_cost_usd??0,6)}</b><p>{overview?.ai_usage?.note}</p></div><div className="ops-principle"><b>Principe</b><p>Les calculs statistiques restent déterministes. Tokens et coûts ne sont comptabilisés que lorsqu’un fournisseur LLM instrumenté les rapporte ; zéro n’est pas transformé en estimation fictive.</p></div></Panel></div>
    <Panel title="AI Analyst Evaluation Lab" action={<span className="role-pill">{currentRole}</span>}><div className="evaluation-layout"><aside className="eval-suite-list"><div className="eval-create"><input value={suiteName} onChange={e=>setSuiteName(e.target.value)} placeholder="Nom de la suite"/><button className="primary-btn" disabled={!result||busy||!['owner','admin','data_scientist'].includes(currentRole)} onClick={createSuite}>+ Suite sur dataset actif</button>{!result&&<small>Activez un dataset pour créer une suite.</small>}</div>{suites.map((s:AnyObj)=><button key={s.id} className={activeSuite?.id===s.id?'active':''} onClick={()=>selectSuite(s.id)}><div><b>{s.name}</b><small>{s.cases_count??0} cas · {String(s.dataset_id).slice(0,10)}…</small></div><span>{s.latest_run?.score??''}</span></button>)}{!suites.length&&<div className="quiet-empty">Aucune suite d’évaluation.</div>}</aside><section className="eval-workbench">{activeSuite?<><div className="eval-suite-head"><div><span>EVALUATION SUITE</span><h3>{activeSuite.name}</h3><p>{activeSuite.description||'Cas de non-régression de l’AI Analyst.'}</p></div><button className="primary-btn" disabled={busy||!['owner','admin','data_scientist'].includes(currentRole)} onClick={runSuite}>▶ Exécuter {activeSuite.cases?.length??0} cas</button></div><div className="eval-case-compose"><label>Question<input value={question} onChange={e=>setQuestion(e.target.value)}/></label><label>Intent attendu<input value={expectedIntent} onChange={e=>setExpectedIntent(e.target.value)} placeholder="overview, quality, forecast…"/></label><label>Outils requis<input value={requiredTools} onChange={e=>setRequiredTools(e.target.value)} placeholder="profile, quality"/></label><label>Réponse contient<input value={answerContains} onChange={e=>setAnswerContains(e.target.value)} placeholder="termes séparés par virgule"/></label><label>Min findings<input type="number" min="0" value={minFindings} onChange={e=>setMinFindings(e.target.value)}/></label><button className="secondary-btn" disabled={busy||!['owner','admin','data_scientist'].includes(currentRole)} onClick={addCase}>Ajouter le cas</button></div><div className="eval-cases">{(activeSuite.cases??[]).map((c:AnyObj)=><article key={c.id}><div><b>{c.question}</b><small>{Object.entries(c.expectations??{}).map(([k,v])=>`${k}: ${Array.isArray(v)?v.join('|'):String(v)}`).join(' · ')}</small></div><span>enabled</span></article>)}</div>{latestRun&&<div className={`eval-run-result ${latestRun.status}`}><div><span>DERNIER RUN</span><b>{formatNumber(latestRun.score,0)}/100</b><small>{latestRun.cases_passed}/{latestRun.cases_total} cas validés · {formatNumber(latestRun.duration_ms,0)} ms</small></div><div className="eval-results-mini">{(latestRun.results??[]).map((r:AnyObj)=><div key={r.id??r.case_id} className={r.status}><b>{r.status==='passed'?'✓':'!'}</b><span>{r.question??r.case_id}</span><em>{formatNumber(r.score,0)}</em></div>)}</div></div>}</>:<div className="quiet-empty">Sélectionnez une suite pour inspecter ses cas et exécuter un benchmark reproductible.</div>}</section></div></Panel>
    <Panel title="Télémétrie récente" action={<span className="quiet">{events.length} événement(s)</span>}><div className="telemetry-table"><div className="telemetry-row header"><span>Statut</span><span>Feature</span><span>Événement</span><span>Latence</span><span>Heure</span></div>{events.slice(0,40).map((e:AnyObj)=><div className="telemetry-row" key={e.id}><span><i className={`telemetry-status ${String(e.status).startsWith('2')||e.status==='completed'?'ok':'warn'}`}/>{e.status}</span><span>{e.feature??'Platform'}</span><span title={e.name}>{e.name}</span><span>{e.latency_ms==null?'—':`${formatNumber(e.latency_ms,0)} ms`}</span><span>{e.created_at?new Date(e.created_at).toLocaleTimeString('fr-FR'):'—'}</span></div>)}</div></Panel>
  </div>;
}


function GovernedActionsCenter({result,setError,setView}:{result:AnyObj|null;setError:(s:string)=>void;setView:(v:View)=>void}){
  const [token,setToken]=useState(''); const [session,setSession]=useState<AnyObj|null>(null); const [workspaceId,setWorkspaceId]=useState('');
  const [summary,setSummary]=useState<AnyObj|null>(null); const [destinations,setDestinations]=useState<AnyObj[]>([]); const [rules,setRules]=useState<AnyObj[]>([]); const [runs,setRuns]=useState<AnyObj[]>([]);
  const [selectedRun,setSelectedRun]=useState<AnyObj|null>(null); const [busy,setBusy]=useState(false); const [showDest,setShowDest]=useState(false); const [showRule,setShowRule]=useState(false);
  const [destName,setDestName]=useState('Canal décisionnel'); const [destKind,setDestKind]=useState('webhook'); const [destUrl,setDestUrl]=useState('https://example.com/datavision'); const [destAuth,setDestAuth]=useState('hmac');
  const [destSecret,setDestSecret]=useState(''); const [destUser,setDestUser]=useState(''); const [destChannel,setDestChannel]=useState(''); const [destProject,setDestProject]=useState('DATA'); const [destIssueType,setDestIssueType]=useState('Task');
  const [smtpHost,setSmtpHost]=useState('smtp.example.com'); const [smtpPort,setSmtpPort]=useState(587); const [mailFrom,setMailFrom]=useState('datavision@example.com'); const [mailTo,setMailTo]=useState('');
  const [oauthClientId,setOauthClientId]=useState(''); const [oauthTokenUrl,setOauthTokenUrl]=useState(''); const [oauthScope,setOauthScope]=useState('');
  const [ruleName,setRuleName]=useState('Alerte critique → action'); const [eventType,setEventType]=useState('proactive_alert'); const [approvalMode,setApprovalMode]=useState('always'); const [destinationId,setDestinationId]=useState('');
  const [approvalRole1,setApprovalRole1]=useState('data_scientist'); const [approvalRole2,setApprovalRole2]=useState('admin');
  const [conditionField,setConditionField]=useState('severity'); const [conditionOp,setConditionOp]=useState('eq'); const [conditionValue,setConditionValue]=useState('critical'); const [throttle,setThrottle]=useState(30); const [dedupe,setDedupe]=useState(1440);
  const [quietEnabled,setQuietEnabled]=useState(true); const [quietStart,setQuietStart]=useState('22:00'); const [quietEnd,setQuietEnd]=useState('07:00'); const [quietTz,setQuietTz]=useState('UTC');
  const [messageTemplate,setMessageTemplate]=useState('DataVision: {{event.metric_label}} · {{event.severity}} · {{event.evidence}}'); const [manualSeverity,setManualSeverity]=useState('critical'); const [decisionNote,setDecisionNote]=useState('Validé depuis Actions Center'); const [testMessage,setTestMessage]=useState('');

  async function refresh(t=token,ws=workspaceId){if(!t||!ws)return;setBusy(true);try{const [sm,d,r,ru]=await Promise.all([getActionSummary(t,ws),getActionDestinations(t,ws),getActionRules(t,ws),getActionRuns(t,ws,'all',150)]);setSummary(sm);setDestinations(d.destinations??[]);setRules(r.rules??[]);setRuns(ru.runs??[]);if(!destinationId&&(d.destinations??[])[0])setDestinationId(d.destinations[0].id);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  useEffect(()=>{if(typeof window==='undefined')return;const t=sessionStorage.getItem('dv_enterprise_token')||'';const stored=localStorage.getItem('dv_enterprise_workspace')||'';if(!t)return;setToken(t);getEnterpriseSession(t).then(s=>{setSession(s);const ws=stored||s.workspaces?.[0]?.id||'';setWorkspaceId(ws);if(ws)refresh(t,ws)}).catch(()=>setSession(null));},[]);
  async function changeWorkspace(ws:string){setWorkspaceId(ws);setSelectedRun(null);if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',ws);window.dispatchEvent(new Event('datavision-enterprise-session'));}await refresh(token,ws)}
  const role=(session?.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId)?.role??'viewer'; const canManage=['owner','admin'].includes(role); const canApprove=['owner','admin','data_scientist'].includes(role); const canTrigger=['owner','admin','data_scientist','analyst'].includes(role);
  function applyKind(kind:string){setDestKind(kind);setTestMessage('');if(kind==='webhook'){setDestAuth('hmac');setDestUrl('https://example.com/datavision');}else if(kind==='slack'){setDestAuth('none');setDestUrl('https://hooks.slack.com/services/...');}else if(kind==='teams'){setDestAuth('none');setDestUrl('https://...logic.azure.com/...');}else if(kind==='jira'){setDestAuth('basic');setDestUrl('https://your-domain.atlassian.net');}else if(kind==='email'){setDestAuth('smtp');setDestUrl('');}}
  async function createDestination(){if(!token||!workspaceId)return;setBusy(true);try{
    const credential:AnyObj={}; const oauth:AnyObj={}; const config:AnyObj={}; let url=destUrl; let secret='';
    if(destAuth==='hmac')secret=destSecret;
    if(destAuth==='bearer')credential.token=destSecret;
    if(destAuth==='basic'){credential.username=destUser;credential.api_token=destSecret;}
    if(destAuth==='smtp'){credential.username=destUser;credential.password=destSecret;}
    if(destAuth==='oauth2_client_credentials'){credential.client_id=oauthClientId;credential.client_secret=destSecret;oauth.token_url=oauthTokenUrl;oauth.scope=oauthScope;}
    if(destKind==='slack'){config.mode=['bearer','oauth2_client_credentials'].includes(destAuth)?'api':'webhook';config.channel=destChannel;}
    if(destKind==='jira'){config.project_key=destProject;config.issue_type=destIssueType;}
    if(destKind==='email'){config.smtp_host=smtpHost;config.smtp_port=smtpPort;config.from_email=mailFrom;config.to=mailTo.split(',').map(x=>x.trim()).filter(Boolean);config.starttls=true;url='';}
    await createActionDestination(token,workspaceId,{name:destName,kind:destKind,webhook_url:url,secret,headers:{},config,credential_type:destAuth==='hmac'?'hmac':destAuth,credential,oauth,enabled:true});setShowDest(false);setDestSecret('');setTestMessage('');await refresh();
  }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function testDest(id:string){setBusy(true);try{const out=await testActionDestination(token,workspaceId,id);setTestMessage(`${out.kind}: ${out.ok?'connexion OK':'échec'} · ${out.response_code}`);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function createRule(){if(!token||!workspaceId||!destinationId)return;setBusy(true);try{const value=['gt','gte','lt','lte'].includes(conditionOp)?Number(conditionValue):conditionValue;const chain=approvalMode==='chain'?[{label:'Revue technique',role:approvalRole1},{label:'Validation finale',role:approvalRole2}]:[];await saveActionRule(token,workspaceId,{name:ruleName,description:'Règle gouvernée créée depuis Actions Center',event_type:eventType,dataset_id:result?.dataset?.id??null,destination_id:destinationId,conditions:conditionField.trim()?[{field:conditionField.trim(),operator:conditionOp,value}]:[],approval_mode:approvalMode,approval_chain:chain,throttle_minutes:throttle,dedupe_minutes:dedupe,quiet_hours:quietEnabled?{enabled:true,start:quietStart,end:quietEnd,timezone:quietTz}:null,payload_template:{message:messageTemplate,severity:'${event.severity}',source_event:'${meta.event_type}'},enabled:true,max_retries:2,retry_backoff_seconds:15});setShowRule(false);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function triggerManual(){if(!canTrigger)return;setBusy(true);try{await dispatchActionEvent(token,workspaceId,{event_type:'manual',event_id:`manual-${Date.now()}`,dataset_id:result?.dataset?.id??null,payload:{severity:manualSeverity,title:'Test gouverné',message:'Événement manuel depuis Actions Center'}});await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function decide(id:string,action:'approve'|'reject'|'replay'){setBusy(true);try{const r=action==='approve'?await approveActionRun(token,workspaceId,id,decisionNote):action==='reject'?await rejectActionRun(token,workspaceId,id,decisionNote):await replayActionRun(token,workspaceId,id);setSelectedRun(r.run);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function inspect(id:string){try{const r=await getActionRun(token,workspaceId,id);setSelectedRun(r.run);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  if(!session||!token)return <div className="page actions-page"><div className="page-title"><div><span className="eyebrow">ENTERPRISE ACTION CONNECTORS · V2.11</span><h1>Actions & Automation</h1><p>Connecteurs natifs, credentials gouvernés et approbations multi-étapes.</p></div><span className="module-state implemented">v2.11</span></div><div className="collab-auth-empty"><span>⚡</span><div><h3>Session Entreprise requise</h3><p>Les actions externes exigent une identité, un workspace et une piste d’audit.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;
  return <div className="page actions-page">
    <div className="page-title"><div><span className="eyebrow">ENTERPRISE ACTION CONNECTORS · V2.11</span><h1>Actions & Automation</h1><p>Détecter → contrôler → approuver en plusieurs étapes → agir dans les outils métier → auditer.</p></div><div className="actions-head"><label>Workspace<select value={workspaceId} onChange={e=>changeWorkspace(e.target.value)}>{(session.workspaces??[]).map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><button className="secondary-btn" onClick={()=>refresh()} disabled={busy}>↻ Actualiser</button>{canManage&&<button className="primary-btn" onClick={()=>setShowRule(v=>!v)}>+ Règle</button>}</div></div>
    <div className="actions-scorecards"><Stat label="Connecteurs" value={summary?.destinations??0} detail="Slack · Teams · Jira · Email"/><Stat label="Règles actives" value={summary?.active_rules??0} detail={`${summary?.staged_approval_rules??0} chaîne(s) multi-étapes`}/><Stat label="Approbations" value={summary?.pending_approval??0} detail="human-in-the-loop"/><Stat label="Planifiées" value={summary?.scheduled??0} detail="quiet hours"/><Stat label="Livraison" value={summary?.delivery_success_pct==null?'—':`${formatNumber(summary.delivery_success_pct,1)}%`} detail={`${summary?.failed??0} échec(s)`}/></div>
    <div className="action-principles"><div><b>Native connectors</b><span>Slack, Teams, Jira, email et webhook générique dans le même moteur.</span></div><div><b>Credential vault</b><span>Tokens, mots de passe et secrets sont chiffrés et jamais renvoyés par l’API.</span></div><div><b>Approval chain</b><span>Les actions sensibles peuvent exiger plusieurs validations ordonnées par rôle.</span></div><div><b>Delivery safety</b><span>Idempotence, throttling, quiet hours, SSRF guard et retries restent actifs.</span></div></div>
    <div className="two-col actions-config-grid"><Panel title="Connecteurs d’action" action={canManage?<button className="secondary-btn" onClick={()=>setShowDest(v=>!v)}>+ Connecteur</button>:undefined}>{showDest&&<div className="action-form"><label>Type<select value={destKind} onChange={e=>applyKind(e.target.value)}><option value="webhook">Webhook</option><option value="slack">Slack</option><option value="teams">Microsoft Teams</option><option value="jira">Jira</option><option value="email">Email SMTP</option></select></label><label>Nom<input value={destName} onChange={e=>setDestName(e.target.value)}/></label>{destKind!=='email'&&<label>{destKind==='jira'?'URL Jira':'Endpoint HTTPS'}<input value={destUrl} onChange={e=>setDestUrl(e.target.value)}/></label>}{destKind==='slack'&&<label>Canal (mode API)<input value={destChannel} onChange={e=>setDestChannel(e.target.value)} placeholder="C0123456789"/></label>}{destKind==='jira'&&<div className="action-number-row"><label>Projet<input value={destProject} onChange={e=>setDestProject(e.target.value)}/></label><label>Type<input value={destIssueType} onChange={e=>setDestIssueType(e.target.value)}/></label></div>}{destKind==='email'&&<><div className="action-number-row"><label>SMTP<input value={smtpHost} onChange={e=>setSmtpHost(e.target.value)}/></label><label>Port<input type="number" value={smtpPort} onChange={e=>setSmtpPort(Number(e.target.value)||587)}/></label></div><label>De<input value={mailFrom} onChange={e=>setMailFrom(e.target.value)}/></label><label>À<input value={mailTo} onChange={e=>setMailTo(e.target.value)} placeholder="ops@example.com, finance@example.com"/></label></>}<label>Authentification<select value={destAuth} onChange={e=>setDestAuth(e.target.value)}><option value="none">Aucune</option><option value="hmac">Secret HMAC</option><option value="bearer">Bearer token</option><option value="basic">Basic / API token</option><option value="smtp">SMTP login</option><option value="oauth2_client_credentials">OAuth2 client credentials</option></select></label>{['basic','smtp'].includes(destAuth)&&<label>Utilisateur<input value={destUser} onChange={e=>setDestUser(e.target.value)}/></label>}{destAuth==='oauth2_client_credentials'&&<><label>Client ID<input value={oauthClientId} onChange={e=>setOauthClientId(e.target.value)}/></label><label>Token URL<input value={oauthTokenUrl} onChange={e=>setOauthTokenUrl(e.target.value)}/></label><label>Scope<input value={oauthScope} onChange={e=>setOauthScope(e.target.value)}/></label></>}{destAuth!=='none'&&<label>Secret / token<input type="password" value={destSecret} onChange={e=>setDestSecret(e.target.value)} placeholder="stocké chiffré"/></label>}<button className="primary-btn" onClick={createDestination} disabled={busy}>Enregistrer le connecteur</button></div>}<div className="destination-list">{destinations.map((d:AnyObj)=><article key={d.id}><div><b><span className="connector-kind">{String(d.kind||'webhook').toUpperCase()}</span> {d.name}</b><small>{d.webhook_url}</small><span>{d.credential_type&&d.credential_type!=='none'?`✓ ${d.credential_type}`:(d.has_secret?'✓ signé':'sans credential')} · {d.enabled?'actif':'désactivé'}</span></div>{canManage&&<div className="destination-actions"><button onClick={()=>testDest(d.id)}>Tester</button><button onClick={async()=>{try{await deleteActionDestination(token,workspaceId,d.id);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}}>×</button></div>}</article>)}{testMessage&&<div className="success-box compact-success">✓ {testMessage}</div>}{!destinations.length&&<div className="quiet-empty">Ajoutez Slack, Teams, Jira, email ou un webhook générique.</div>}</div></Panel>
    <Panel title="Règles gouvernées">{showRule&&<div className="action-rule-form"><label>Nom<input value={ruleName} onChange={e=>setRuleName(e.target.value)}/></label><label>Événement<select value={eventType} onChange={e=>setEventType(e.target.value)}><option value="proactive_alert">Alerte proactive</option><option value="reliability_failure">Data contract en échec</option><option value="review_approved">Revue approuvée</option><option value="review_submitted">Revue soumise</option><option value="review_changes_requested">Corrections demandées</option><option value="review_assigned">Revue assignée</option><option value="review_comment">Nouveau commentaire</option><option value="review_mention">Mention @</option><option value="artifact_shared">Artefact partagé</option><option value="certification_created">Certification créée</option><option value="manual">Événement manuel</option></select></label><label>Destination<select value={destinationId} onChange={e=>setDestinationId(e.target.value)}>{destinations.map((d:AnyObj)=><option key={d.id} value={d.id}>{d.name} · {d.kind}</option>)}</select></label><label>Approbation<select value={approvalMode} onChange={e=>setApprovalMode(e.target.value)}><option value="always">Une validation requise</option><option value="chain">Chaîne multi-étapes</option><option value="critical_only">Seulement critical</option><option value="none">Automatique</option></select></label>{approvalMode==='chain'&&<div className="approval-chain-builder"><div><span>1</span><label>Revue technique<select value={approvalRole1} onChange={e=>setApprovalRole1(e.target.value)}>{['data_scientist','admin','owner'].map(x=><option key={x}>{x}</option>)}</select></label></div><i>→</i><div><span>2</span><label>Validation finale<select value={approvalRole2} onChange={e=>setApprovalRole2(e.target.value)}>{['admin','owner','data_scientist'].map(x=><option key={x}>{x}</option>)}</select></label></div></div>}<div className="action-condition-row"><input value={conditionField} onChange={e=>setConditionField(e.target.value)} placeholder="severity"/><select value={conditionOp} onChange={e=>setConditionOp(e.target.value)}><option value="eq">=</option><option value="neq">≠</option><option value="contains">contient</option><option value="gt">&gt;</option><option value="gte">≥</option><option value="lt">&lt;</option><option value="lte">≤</option></select><input value={conditionValue} onChange={e=>setConditionValue(e.target.value)}/></div><div className="action-number-row"><label>Throttle min<input type="number" min="0" value={throttle} onChange={e=>setThrottle(Number(e.target.value))}/></label><label>Dedupe min<input type="number" min="0" value={dedupe} onChange={e=>setDedupe(Number(e.target.value))}/></label></div><label className="checkbox-line"><input type="checkbox" checked={quietEnabled} onChange={e=>setQuietEnabled(e.target.checked)}/> Quiet hours</label>{quietEnabled&&<div className="action-number-row"><input value={quietStart} onChange={e=>setQuietStart(e.target.value)}/><input value={quietEnd} onChange={e=>setQuietEnd(e.target.value)}/><input value={quietTz} onChange={e=>setQuietTz(e.target.value)} placeholder="UTC"/></div>}<label>Message / contenu<textarea value={messageTemplate} onChange={e=>setMessageTemplate(e.target.value)}/></label><button className="primary-btn" onClick={createRule} disabled={busy||!destinations.length}>Enregistrer la règle</button></div>}<div className="action-rule-list">{rules.map((r:AnyObj)=><article key={r.id}><span className={`rule-live ${r.enabled?'on':'off'}`}/><div><b>{r.name}</b><small>{r.event_type} · approval {r.approval_mode}{(r.approval_chain??[]).length?` · ${(r.approval_chain??[]).length} étapes`:''}</small><span>{(r.conditions??[]).map((c:AnyObj)=>`${c.field} ${c.operator} ${c.value}`).join(' · ')||'sans condition'} · throttle {r.throttle_minutes} min</span></div>{canManage&&<button onClick={async()=>{try{await deleteActionRule(token,workspaceId,r.id);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}}>×</button>}</article>)}{!rules.length&&<div className="quiet-empty">Aucune règle active. Commencez par un connecteur puis créez une règle.</div>}</div></Panel></div>
    <Panel title="Action approval queue" action={<div className="manual-action-test"><select value={manualSeverity} onChange={e=>setManualSeverity(e.target.value)}><option>critical</option><option>high</option><option>medium</option><option>low</option></select><button className="secondary-btn" onClick={triggerManual} disabled={!canTrigger||busy}>Déclencher test manuel</button></div>}><div className="action-run-table"><div className="action-run-row header"><span>Statut</span><span>Règle / événement</span><span>Créé</span><span>Delivery</span><span>Action</span></div>{runs.slice(0,60).map((r:AnyObj)=>{const rule=rules.find((x:AnyObj)=>x.id===r.rule_id);const pending=(r.approval_steps??[]).find((x:AnyObj)=>x.status==='pending');return <div className="action-run-row" key={r.id} onClick={()=>inspect(r.id)}><span><i className={`action-status ${r.status}`}/>{r.status}</span><span><b>{rule?.name??String(r.rule_id).slice(0,8)}</b><small>{r.event_type} · {r.event_id}{pending?` · prochaine: ${pending.label}`:''}</small></span><span>{r.created_at?new Date(r.created_at).toLocaleString('fr-FR'):'—'}</span><span>{r.last_response_code??(r.scheduled_for?'planifiée':'—')}</span><span>{r.status==='pending_approval'&&canApprove?<><button onClick={e=>{e.stopPropagation();decide(r.id,'approve')}}>Approuver</button><button className="danger-link" onClick={e=>{e.stopPropagation();decide(r.id,'reject')}}>Rejeter</button></>:r.status==='failed'&&canApprove?<button onClick={e=>{e.stopPropagation();decide(r.id,'replay')}}>Replay</button>:<button onClick={e=>{e.stopPropagation();inspect(r.id)}}>Détails</button>}</span></div>})}{!runs.length&&<div className="quiet-empty">Aucune action déclenchée.</div>}</div></Panel>
    {selectedRun&&<Panel title="Détail d’exécution" action={<button className="secondary-btn" onClick={()=>setSelectedRun(null)}>Fermer</button>}><div className="action-detail"><div className="action-detail-meta"><div><span>Run</span><b>{selectedRun.id}</b></div><div><span>Statut</span><b>{selectedRun.status}</b></div><div><span>Event</span><b>{selectedRun.event_type}</b></div><div><span>Attempts</span><b>{selectedRun.attempt_count??0}</b></div></div>{(selectedRun.approval_steps??[]).length>0&&<div className="approval-stepper">{(selectedRun.approval_steps??[]).map((st:AnyObj)=><div key={st.id} className={`approval-step ${st.status}`}><span>{st.step_order}</span><div><b>{st.label}</b><small>{st.required_role||st.required_user_id} · {st.status}</small></div></div>)}</div>}{selectedRun.status==='pending_approval'&&canApprove&&<div className="approval-bar"><input value={decisionNote} onChange={e=>setDecisionNote(e.target.value)}/><button className="primary-btn" onClick={()=>decide(selectedRun.id,'approve')}>Valider l’étape</button><button className="secondary-btn" onClick={()=>decide(selectedRun.id,'reject')}>Rejeter</button></div>}<div className="two-col"><div><h4>Payload gouverné</h4><pre>{JSON.stringify(selectedRun.rendered_payload??{},null,2)}</pre></div><div><h4>Delivery attempts</h4><div className="action-attempts">{(selectedRun.attempts??[]).map((a:AnyObj)=><div key={a.id}><b>#{a.attempt_number} · {a.status}</b><span>{a.response_code??'—'} · {a.latency_ms==null?'—':`${formatNumber(a.latency_ms,0)} ms`}</span>{a.error&&<small>{a.error}</small>}</div>)}{!(selectedRun.attempts??[]).length&&<div className="quiet-empty">Aucune tentative de livraison.</div>}</div></div></div></div></Panel>}
  </div>;
}

function IdentitySecurityCenter({ setError, setView }: { setError:(s:string)=>void; setView:(v:View)=>void }) {
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [providers,setProviders]=useState<AnyObj[]>([]);
  const [secrets,setSecrets]=useState<AnyObj[]>([]);
  const [sessions,setSessions]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [oidcName,setOidcName]=useState('Corporate SSO');
  const [issuer,setIssuer]=useState('');
  const [clientId,setClientId]=useState('');
  const [clientSecret,setClientSecret]=useState('');
  const [authEndpoint,setAuthEndpoint]=useState('');
  const [tokenEndpoint,setTokenEndpoint]=useState('');
  const [jwksUri,setJwksUri]=useState('');
  const [domains,setDomains]=useState('');
  const [defaultRole,setDefaultRole]=useState('viewer');
  const [secretName,setSecretName]=useState('');
  const [secretProvider,setSecretProvider]=useState('local_encrypted');
  const [secretValue,setSecretValue]=useState('');
  const [envVariable,setEnvVariable]=useState('');
  const [vaultUrl,setVaultUrl]=useState('');
  const [vaultMount,setVaultMount]=useState('secret');
  const [vaultPath,setVaultPath]=useState('');
  const [vaultField,setVaultField]=useState('value');
  const [rotateTarget,setRotateTarget]=useState('');
  const [rotateValue,setRotateValue]=useState('');
  const [message,setMessage]=useState('');
  const [mfa,setMfa]=useState<AnyObj|null>(null);

  async function refresh(nextToken=token,nextWs=workspaceId){
    if(!nextToken)return;
    const s=await getEnterpriseSession(nextToken); setSession(s);
    const stored=typeof window!=='undefined'?localStorage.getItem('dv_enterprise_workspace')||'':'';
    const ws=nextWs||stored||s.workspaces?.[0]?.id||''; setWorkspaceId(ws);
    if(typeof window!=='undefined'&&ws)localStorage.setItem('dv_enterprise_workspace',ws);
    const [auth,mfaStatus]=await Promise.all([getEnterpriseAuthSessions(nextToken),getEnterpriseMFAStatus(nextToken)]); setSessions(auth.sessions??[]); setMfa(mfaStatus);
    if(ws){
      const role=s.workspaces?.find((x:AnyObj)=>x.id===ws)?.role;
      if(['owner','admin'].includes(role)){
        const [p,sec]=await Promise.all([getWorkspaceOIDCProviders(nextToken,ws),getWorkspaceSecrets(nextToken,ws)]);
        setProviders(p.providers??[]); setSecrets(sec.secrets??[]);
      }else{setProviders([]);setSecrets([]);}
    }
  }
  useEffect(()=>{if(typeof window==='undefined')return;const t=sessionStorage.getItem('dv_enterprise_token')||'';setToken(t);if(t)refresh(t).catch(e=>setError(e instanceof Error?e.message:String(e)));},[]);
  async function changeWorkspace(ws:string){setWorkspaceId(ws);if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',ws);window.dispatchEvent(new Event('datavision-enterprise-session'));}await refresh(token,ws);}
  async function createProvider(){if(!token||!workspaceId)return;setBusy(true);setMessage('');try{await createWorkspaceOIDCProvider(token,workspaceId,{name:oidcName,issuer,client_id:clientId,client_secret:clientSecret,authorization_endpoint:authEndpoint||null,token_endpoint:tokenEndpoint||null,jwks_uri:jwksUri||null,allowed_domains:domains.split(',').map(x=>x.trim()).filter(Boolean),default_role:defaultRole,scopes:['openid','profile','email'],enabled:true});setClientSecret('');setMessage('Fournisseur SSO enregistré.');await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function createSecretItem(){if(!token||!workspaceId)return;setBusy(true);setMessage('');try{const reference=secretProvider==='env'?{variable:envVariable}:secretProvider==='vault_kv2'?{url:vaultUrl,mount:vaultMount,path:vaultPath,field:vaultField}:{};await createWorkspaceSecret(token,workspaceId,{name:secretName,provider:secretProvider,value:secretValue,reference});setSecretName('');setSecretValue('');setMessage('Secret enregistré sans exposition de sa valeur.');await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function rotateSecretNow(){if(!rotateTarget||!rotateValue)return;setBusy(true);try{await rotateWorkspaceSecret(token,workspaceId,rotateTarget,rotateValue);setRotateTarget('');setRotateValue('');setMessage('Nouvelle version du secret activée.');await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function testSecretNow(id:string){try{const r=await testWorkspaceSecret(token,workspaceId,id);setMessage(`Secret résolu sans exposition · longueur ${r.length} · checksum ${r.checksum}`);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function revokeSessionNow(id:string){try{await revokeEnterpriseAuthSession(token,id);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}
  async function closeOtherSessions(){try{const r=await logoutAllEnterpriseSessions(token);setMessage(`${r.revoked??0} autres sessions révoquées.`);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}

async function enrollPasskey(){
  if(!token||typeof navigator==='undefined'||!navigator.credentials){setError('WebAuthn n’est pas disponible dans ce navigateur.');return;}
  setBusy(true);setMessage('');
  try{
    const options=await beginEnterpriseWebAuthnRegistration(token);
    const credential=await navigator.credentials.create({publicKey:publicKeyOptionsFromJSON(options.publicKey) as PublicKeyCredentialCreationOptions});
    if(!credential)throw new Error('Création de passkey annulée.');
    const status=await verifyEnterpriseWebAuthnRegistration(token,{challenge_id:options.challenge_id,credential:publicKeyCredentialToJSON(credential),label:'Passkey DataVision'});
    setMfa(status);setMessage('Passkey WebAuthn enregistrée.');
  }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
}
async function disablePasskey(id:string){
  try{const status=await disableEnterpriseWebAuthnCredential(token,id);setMfa(status);setMessage('Passkey désactivée.');}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
}

  if(!token||!session)return <div className="page identity-page"><div className="page-title"><div><span className="eyebrow">IDENTITY · MFA · SECRET MANAGEMENT · V2.31</span><h1>Identité & Secrets</h1><p>SSO, sessions révocables et coffre de secrets versionné nécessitent une session Entreprise.</p></div></div><div className="collab-auth-empty"><span>◈</span><div><h3>Session Entreprise requise</h3><p>Connectez-vous ou initialisez l’organisation depuis Gouvernance.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;
  const workspaces=session.workspaces??[]; const active=workspaces.find((x:AnyObj)=>x.id===workspaceId)??workspaces[0]; const canManage=['owner','admin'].includes(active?.role);
  return <div className="page identity-page">
    <div className="page-title"><div><span className="eyebrow">IDENTITY · MFA · SECRET MANAGEMENT · V2.31</span><h1>Identité & Secrets</h1><p>Sessions persistantes, SSO OIDC Authorization Code + PKCE, provisioning JIT et coffre de secrets à rotation contrôlée.</p></div><span className="module-state implemented">Security v2.31</span></div>
    <div className="identity-toolbar"><label>Workspace<select value={workspaceId} onChange={e=>changeWorkspace(e.target.value)}>{workspaces.map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><button className="secondary-btn" onClick={()=>refresh()} disabled={busy}>↻ Actualiser</button></div>
    <div className="identity-scorecards"><Stat label="MFA / Passkeys" value={mfa?.credential_count??0} detail={mfa?.enrolled?'WebAuthn actif':'Non configuré'}/><Stat label="SSO actifs" value={providers.filter(x=>x.enabled).length} detail="OIDC / PKCE"/><Stat label="Sessions actives" value={sessions.filter(x=>x.active).length} detail="Révocables côté serveur"/><Stat label="Secrets" value={secrets.length} detail="Valeurs jamais relues dans l’UI"/><Stat label="Rôle" value={active?.role??'—'} detail={canManage?'Administration identité':'Lecture limitée'}/></div>
    {message&&<div className="success-box">✓ {message}</div>}
    <Panel title="Authentification multifacteur" action={<span className="quiet">WebAuthn · passkeys · user verification</span>}><div className="mfa-security-card"><div><b>{mfa?.enrolled?'MFA actif':'Ajouter une passkey'}</b><p>Utilisez Windows Hello, Touch ID, une clé de sécurité ou une passkey synchronisée. Le mot de passe seul ne suffit plus après enrôlement.</p><small>RP ID : {mfa?.rp_id??'—'} · politique : {mfa?.policy??'optional'}</small></div><button className="primary-btn" disabled={busy||!mfa?.webauthn_enabled} onClick={enrollPasskey}>+ Enregistrer une passkey</button></div><div className="passkey-list">{(mfa?.credentials??[]).map((x:AnyObj)=><article key={x.id}><div><b>{x.label||'Passkey'}</b><small>{x.credential_id_preview}… · créée {x.created_at?new Date(x.created_at).toLocaleString('fr-FR'):'—'}</small></div><span className={`status-chip ${x.active?'ok':'muted'}`}>{x.active?'ACTIVE':'OFF'}</span>{x.active&&<button className="danger-link" onClick={()=>disablePasskey(x.id)}>Désactiver</button>}</article>)}</div></Panel>
    <div className="two-col identity-grid">
      <Panel title="Sessions & sécurité du compte" action={<button className="secondary-btn" onClick={closeOtherSessions}>Fermer les autres sessions</button>}><div className="session-list">{sessions.map((x:AnyObj)=><article key={x.id}><span className={`session-state ${x.active?'active':'revoked'}`}/><div><b>{x.provider==='local'?'Mot de passe':x.provider}</b><small>{x.device_label||'Session DataVision'} · créée {x.created_at?new Date(x.created_at).toLocaleString('fr-FR'):'—'}</small><span>Dernière activité : {x.last_seen_at?new Date(x.last_seen_at).toLocaleString('fr-FR'):'—'}</span></div><div><span className={`status-chip ${x.active?'ok':'muted'}`}>{x.active?'ACTIVE':'REVOKED'}</span>{x.active&&<button className="danger-link" onClick={()=>revokeSessionNow(x.id)}>Révoquer</button>}</div></article>)}</div><div className="identity-note"><b>Rotation automatique</b><span>Les access tokens sont courts et les refresh tokens sont rotatifs. Un refresh déjà utilisé ne peut pas être rejoué.</span></div></Panel>
      <Panel title="Fournisseurs SSO" action={canManage?<span className="quiet">RS256 · PKCE S256 · JIT</span>:undefined}><div className="oidc-provider-list">{providers.map((p:AnyObj)=><article key={p.id}><div className="idp-logo">SSO</div><div><b>{p.name}</b><small>{p.issuer}</small><span>Rôle JIT : {p.default_role} · domaines {(p.allowed_domains??[]).join(', ')||'tous'}</span></div><span className={`status-chip ${p.enabled?'ok':'muted'}`}>{p.enabled?'ACTIVE':'OFF'}</span>{canManage&&p.enabled&&<button className="danger-link" onClick={async()=>{try{await disableWorkspaceOIDCProvider(token,workspaceId,p.id);await refresh();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}}>Désactiver</button>}</article>)}{!providers.length&&<div className="quiet-empty">Aucun fournisseur OIDC configuré pour ce workspace.</div>}</div></Panel>
    </div>
    {canManage&&<div className="two-col identity-grid">
      <Panel title="Configurer un fournisseur OIDC"><div className="stack-form identity-form"><label>Nom<input value={oidcName} onChange={e=>setOidcName(e.target.value)}/></label><label>Issuer<input value={issuer} onChange={e=>setIssuer(e.target.value)} placeholder="https://login.example.com/tenant"/></label><div className="two-col"><label>Client ID<input value={clientId} onChange={e=>setClientId(e.target.value)}/></label><label>Client secret<input type="password" value={clientSecret} onChange={e=>setClientSecret(e.target.value)}/></label></div><div className="two-col"><label>Domaines autorisés<input value={domains} onChange={e=>setDomains(e.target.value)} placeholder="example.com, company.org"/></label><label>Rôle JIT<select value={defaultRole} onChange={e=>setDefaultRole(e.target.value)}>{['viewer','analyst','data_scientist','admin'].map(r=><option key={r}>{r}</option>)}</select></label></div><details><summary>Endpoints manuels (sinon discovery automatique)</summary><div className="stack-form"><label>Authorization endpoint<input value={authEndpoint} onChange={e=>setAuthEndpoint(e.target.value)}/></label><label>Token endpoint<input value={tokenEndpoint} onChange={e=>setTokenEndpoint(e.target.value)}/></label><label>JWKS URI<input value={jwksUri} onChange={e=>setJwksUri(e.target.value)}/></label></div></details><button className="primary-btn" onClick={createProvider} disabled={busy||!issuer||!clientId}>Enregistrer le fournisseur</button></div></Panel>
      <Panel title="Coffre de secrets"><div className="stack-form identity-form"><label>Nom logique<input value={secretName} onChange={e=>setSecretName(e.target.value)} placeholder="prod/openai/api-key"/></label><label>Provider<select value={secretProvider} onChange={e=>setSecretProvider(e.target.value)}><option value="local_encrypted">Chiffré localement</option><option value="env">Variable d’environnement</option><option value="vault_kv2">HashiCorp Vault KV v2</option></select></label>{secretProvider==='env'?<label>Variable<input value={envVariable} onChange={e=>setEnvVariable(e.target.value)} placeholder="OPENAI_API_KEY"/></label>:secretProvider==='vault_kv2'?<><label>Vault URL<input value={vaultUrl} onChange={e=>setVaultUrl(e.target.value)} placeholder="https://vault.example.com"/></label><div className="two-col"><label>Mount<input value={vaultMount} onChange={e=>setVaultMount(e.target.value)}/></label><label>Path<input value={vaultPath} onChange={e=>setVaultPath(e.target.value)}/></label></div><label>Field<input value={vaultField} onChange={e=>setVaultField(e.target.value)}/></label><label>Vault token<input type="password" value={secretValue} onChange={e=>setSecretValue(e.target.value)}/></label></>:<label>Valeur<input type="password" value={secretValue} onChange={e=>setSecretValue(e.target.value)}/></label>}<button className="primary-btn" onClick={createSecretItem} disabled={busy||!secretName}>Créer le secret</button></div></Panel>
    </div>}
    {canManage&&<Panel title="Secrets versionnés" action={<span className="quiet">La valeur n’est jamais retournée par l’API</span>}><div className="secret-grid">{secrets.map((x:AnyObj)=><article key={x.id}><div><span className="secret-provider">{x.provider}</span><b>{x.name}</b><small>version {x.current_version} · checksum {x.latest_version?.checksum??'—'}</small>{x.provider==='env'&&<span>{x.reference?.variable}</span>}{x.provider==='vault_kv2'&&<span>{x.reference?.url} · {x.reference?.mount}/{x.reference?.path} · field {x.reference?.field}</span>}</div><div className="secret-actions"><button onClick={()=>testSecretNow(x.id)}>Tester</button>{x.provider!=='env'&&<button onClick={()=>{setRotateTarget(x.id);setRotateValue('')}}>Rotation</button>}</div></article>)}</div>{rotateTarget&&<div className="secret-rotate-bar"><input type="password" value={rotateValue} onChange={e=>setRotateValue(e.target.value)} placeholder="Nouvelle valeur secrète"/><button className="primary-btn" onClick={rotateSecretNow} disabled={busy||!rotateValue}>Activer la nouvelle version</button><button className="secondary-btn" onClick={()=>{setRotateTarget('');setRotateValue('')}}>Annuler</button></div>}</Panel>}
    {!canManage&&<div className="identity-note"><b>Administration restreinte</b><span>Seuls Owner et Admin peuvent gérer les fournisseurs d’identité et les secrets. Les sessions personnelles restent révocables par l’utilisateur.</span></div>}
  </div>;
}


function PluginCenter({setError,setView}:{setError:(s:string)=>void;setView:(v:View)=>void}){
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [plugins,setPlugins]=useState<AnyObj[]>([]);
  const [runs,setRuns]=useState<AnyObj[]>([]);
  const [secrets,setSecrets]=useState<AnyObj[]>([]);
  const [selected,setSelected]=useState<AnyObj|null>(null);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [showForm,setShowForm]=useState(false);

  const [pluginKey,setPluginKey]=useState('my_plugin');
  const [pluginName,setPluginName]=useState('Mon plugin');
  const [pluginVersion,setPluginVersion]=useState('0.1.0');
  const [pluginDescription,setPluginDescription]=useState('');
  const [protocol,setProtocol]=useState<'http_json'|'mcp_http'>('mcp_http');
  const [endpoint,setEndpoint]=useState('https://');
  const [networkScope,setNetworkScope]=useState<'public'|'private'>('public');
  const [authType,setAuthType]=useState<'none'|'bearer'|'api_key'>('none');
  const [authHeader,setAuthHeader]=useState('X-API-Key');
  const [secretId,setSecretId]=useState('');
  const [contextPolicy,setContextPolicy]=useState<'none'|'semantic'>('none');
  const [healthPath,setHealthPath]=useState('');
  const [toolsText,setToolsText]=useState(JSON.stringify([
    {
      name:'search',
      description:'Recherche externe contrôlée',
      input_schema:{type:'object',properties:{query:{type:'string'}},required:['query'],additionalProperties:false},
      risk:'read',
      required_permissions:[],
      requires_dataset:false,
      requires_model:false,
      method:'POST',
      path:'/search'
    }
  ],null,2));

  const activeWorkspace=(session?.workspaces??[]).find((w:AnyObj)=>w.id===workspaceId);
  const canManage=['owner','admin'].includes(activeWorkspace?.role??'');

  async function load(nextToken=token,nextWorkspace=workspaceId){
    if(!nextToken||!nextWorkspace)return;
    try{
      const [p,s]=await Promise.all([
        getWorkspacePlugins(nextToken,nextWorkspace),
        getWorkspaceSecrets(nextToken,nextWorkspace),
      ]);
      setPlugins(p.plugins??[]);setRuns(p.runs??[]);setSecrets(s.secrets??[]);
      if(selected?.id){
        const current=(p.plugins??[]).find((x:AnyObj)=>x.id===selected.id);
        setSelected(current??null);
      }
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
  }

  useEffect(()=>{
    if(typeof window==='undefined')return;
    const t=sessionStorage.getItem('dv_enterprise_token')||'';
    if(!t)return;
    setToken(t);
    getEnterpriseSession(t).then(s=>{
      setSession(s);
      const stored=localStorage.getItem('dv_enterprise_workspace')||'';
      const ws=stored||s.workspaces?.[0]?.id||'';
      setWorkspaceId(ws);
      if(ws)void load(t,ws);
    }).catch(()=>{setToken('');setSession(null);});
  },[]);

  async function changeWorkspace(id:string){
    setWorkspaceId(id);setSelected(null);
    if(typeof window!=='undefined'){
      localStorage.setItem('dv_enterprise_workspace',id);
      window.dispatchEvent(new Event('datavision-enterprise-session'));
    }
    await load(token,id);
  }

  async function install(){
    if(!token||!workspaceId)return;
    setBusy(true);setNotice('');
    try{
      let tools:AnyObj[]=[];
      if(protocol==='http_json'){
        try{tools=JSON.parse(toolsText);}catch{throw new Error('Le JSON des tools HTTP est invalide.');}
        if(!Array.isArray(tools))throw new Error('Le manifest tools doit être un tableau JSON.');
      }
      const payload:AnyObj={
        plugin_key:pluginKey.trim(),name:pluginName.trim(),version:pluginVersion.trim()||'0.1.0',
        description:pluginDescription,protocol,endpoint:endpoint.trim(),network_scope:networkScope,
        auth_type:authType,auth_header:authType==='api_key'?authHeader:null,
        secret_id:authType==='none'?null:(secretId||null),context_policy:contextPolicy,
        timeout_seconds:15,health_path:healthPath.trim()||null,enabled:true,tools,
      };
      const r=await installWorkspacePlugin(token,workspaceId,payload);
      setSelected(r.plugin);setShowForm(false);
      setNotice(protocol==='mcp_http'?'Plugin installé. Synchronisez maintenant le catalogue MCP.':'Plugin HTTP installé et tools enregistrés.');
      await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function sync(plugin:AnyObj){
    setBusy(true);setNotice('');
    try{
      const r=await syncWorkspacePlugin(token,workspaceId,plugin.id);
      setSelected(r.plugin);setNotice(`${r.plugin.tool_count??0} tool(s) synchronisé(s).`);await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function test(plugin:AnyObj){
    setBusy(true);setNotice('');
    try{
      const r=await testWorkspacePlugin(token,workspaceId,plugin.id);
      setNotice(r.network_verified===false?(r.message||'Configuration valide, connectivité non affirmée.'):`Test plugin : ${r.status}.`);
      await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function toggle(plugin:AnyObj){
    setBusy(true);
    try{await updateWorkspacePlugin(token,workspaceId,plugin.id,{enabled:!plugin.enabled});await load();}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function remove(plugin:AnyObj){
    if(!confirm(`Supprimer le plugin « ${plugin.name} » ?`))return;
    setBusy(true);
    try{await deleteWorkspacePlugin(token,workspaceId,plugin.id);if(selected?.id===plugin.id)setSelected(null);await load();}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  async function inspect(plugin:AnyObj){
    setBusy(true);
    try{const r=await getWorkspacePluginDetail(token,workspaceId,plugin.id);setSelected(r.plugin);}
    catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
    finally{setBusy(false)}
  }

  if(!token||!session)return <div className="page plugin-page"><div className="page-title"><div><span className="eyebrow">PLUGIN SYSTEM · MCP · GOVERNED EXTENSIONS</span><h1>Plugins & MCP</h1><p>Étendez DataVision sans charger du code arbitraire dans le cœur du logiciel.</p></div><span className="module-state implemented">v2.22</span></div><div className="collab-auth-empty"><span>⌘</span><div><h3>Session Entreprise requise</h3><p>Les plugins sont isolés par workspace, utilisent Secret Vault et passent par le Tool Registry.</p></div><button className="primary-btn" onClick={()=>setView('governance')}>Ouvrir Gouvernance</button></div></div>;

  return <div className="page plugin-page">
    <div className="page-title"><div><span className="eyebrow">PLUGIN SYSTEM · MCP HTTP · HTTP JSON</span><h1>Plugins & MCP</h1><p>Registre d’extensions gouverné : schémas validés, tools namespacés, secrets référencés et confirmation obligatoire avant tout appel externe.</p></div><div className="plugin-head-actions"><label>Workspace<select value={workspaceId} onChange={e=>void changeWorkspace(e.target.value)}>{(session.workspaces??[]).map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><button className="secondary-btn" onClick={()=>void load()} disabled={busy}>↻ Actualiser</button>{canManage&&<button className="primary-btn" onClick={()=>setShowForm(v=>!v)}>+ Installer</button>}</div></div>

    <div className="plugin-safety-banner"><b>Boundary active</b><span>Les plugins ne reçoivent jamais automatiquement les lignes du dataset. Le contexte sémantique minimal n’est envoyé que si <code>context_policy=semantic</code>. Tout tool distant est classé <strong>external</strong> dans le Tool Registry et exige une confirmation humaine.</span></div>
    {notice&&<div className="source-notice"><span>✓</span><p>{notice}</p><button onClick={()=>setNotice('')}>×</button></div>}

    {showForm&&<Panel title="Installer une extension gouvernée" action={<span className="quiet">Aucun secret brut dans le manifest</span>}><div className="plugin-install-grid">
      <label>Clé plugin<input value={pluginKey} onChange={e=>setPluginKey(e.target.value.toLowerCase().replace(/[^a-z0-9_-]+/g,'_'))} placeholder="crm_tools"/></label>
      <label>Nom<input value={pluginName} onChange={e=>setPluginName(e.target.value)}/></label>
      <label>Version<input value={pluginVersion} onChange={e=>setPluginVersion(e.target.value)}/></label>
      <label>Protocole<select value={protocol} onChange={e=>setProtocol(e.target.value as any)}><option value="mcp_http">MCP HTTP</option><option value="http_json">HTTP JSON</option></select></label>
      <label className="span-2">Endpoint<input value={endpoint} onChange={e=>setEndpoint(e.target.value)} placeholder="https://plugin.company.com/mcp"/></label>
      <label>Réseau<select value={networkScope} onChange={e=>setNetworkScope(e.target.value as any)}><option value="public">Public · HTTPS uniquement</option><option value="private">Privé · intranet autorisé</option></select></label>
      <label>Authentification<select value={authType} onChange={e=>setAuthType(e.target.value as any)}><option value="none">Aucune</option><option value="bearer">Bearer Secret Vault</option><option value="api_key">API key Secret Vault</option></select></label>
      {authType==='api_key'&&<label>Header API key<input value={authHeader} onChange={e=>setAuthHeader(e.target.value)}/></label>}
      {authType!=='none'&&<label>Secret<select value={secretId} onChange={e=>setSecretId(e.target.value)}><option value="">Sélectionner…</option>{secrets.map((s:AnyObj)=><option key={s.id} value={s.id}>{s.name} · {s.provider}</option>)}</select></label>}
      <label>Contexte<select value={contextPolicy} onChange={e=>setContextPolicy(e.target.value as any)}><option value="none">Aucun contexte automatique</option><option value="semantic">Contexte sémantique minimal</option></select></label>
      {protocol==='http_json'&&<label>Health path<input value={healthPath} onChange={e=>setHealthPath(e.target.value)} placeholder="/health (optionnel)"/></label>}
      <label className="span-2">Description<textarea value={pluginDescription} onChange={e=>setPluginDescription(e.target.value)}/></label>
      {protocol==='http_json'&&<label className="span-2">Tools déclaratifs<textarea className="plugin-manifest-editor" value={toolsText} onChange={e=>setToolsText(e.target.value)} spellCheck={false}/><small>Chaque tool fournit name, description, input_schema, méthode et path. Le risque runtime reste external.</small></label>}
      <div className="connector-form-actions span-2"><button className="secondary-btn" onClick={()=>setShowForm(false)}>Annuler</button><button className="primary-btn" onClick={()=>void install()} disabled={busy}>Installer</button></div>
    </div></Panel>}

    <div className="plugin-layout">
      <section className="plugin-list-panel"><div className="plugin-section-head"><div><span>INSTALLED EXTENSIONS</span><h3>{plugins.length} plugin(s)</h3></div></div>{plugins.length?<div className="plugin-list">{plugins.map((p:AnyObj)=><article key={p.id} className={`plugin-card ${selected?.id===p.id?'selected':''}`} onClick={()=>void inspect(p)}><div className="plugin-card-icon">{p.protocol==='mcp_http'?'MCP':'HTTP'}</div><div className="plugin-card-main"><div><b>{p.name}</b><span className={`connector-status ${p.status}`}>{p.status}</span></div><p>{p.plugin_key} · v{p.version}</p><small>{p.protocol} · {p.tool_count??0} tool(s) · {p.network_scope}</small>{p.last_error&&<em>{p.last_error}</em>}</div><div className="plugin-card-actions">{canManage&&<button onClick={e=>{e.stopPropagation();void test(p)}} disabled={busy}>Tester</button>}{canManage&&<button onClick={e=>{e.stopPropagation();void sync(p)}} disabled={busy}>Synchroniser</button>}{canManage&&<button onClick={e=>{e.stopPropagation();void toggle(p)}} disabled={busy}>{p.enabled?'Désactiver':'Activer'}</button>}</div></article>)}</div>:<div className="quiet-empty">Aucun plugin installé dans ce workspace.</div>}</section>

      <section className="plugin-detail-panel">{selected?<><div className="plugin-detail-head"><div><span>PLUGIN</span><h3>{selected.name}</h3><p>{selected.description||'Aucune description.'}</p></div>{canManage&&<button className="danger-link" onClick={()=>void remove(selected)}>Supprimer</button>}</div><div className="plugin-meta-grid"><div><span>Protocol</span><b>{selected.protocol}</b></div><div><span>Status</span><b>{selected.status}</b></div><div><span>Endpoint</span><b>{selected.endpoint}</b></div><div><span>Context</span><b>{selected.context_policy}</b></div><div><span>Secret</span><b>{selected.has_secret?'référencé':'aucun'}</b></div><div><span>Checksum</span><b>{String(selected.checksum||'').slice(0,16)}</b></div></div><h4>Tools importés</h4>{(selected.tools??[]).length?<div className="plugin-tool-list">{selected.tools.map((tool:AnyObj)=><details key={tool.id}><summary><b>{tool.remote_name}</b><span>external · confirmation</span></summary><p>{tool.description}</p><code>{tool.namespaced_name}</code><pre>{JSON.stringify(tool.input_schema,null,2)}</pre></details>)}</div>:<div className="quiet-empty">Aucun tool synchronisé. Pour MCP, cliquez sur Synchroniser.</div>}</>:<div className="quiet-empty">Sélectionnez un plugin pour inspecter son manifest et ses tools.</div>}</section>
    </div>

    <Panel title="Exécutions récentes" action={<span className="quiet">Les arguments complets ne sont pas persistés</span>}><SimpleTable rows={runs.slice(0,30).map((r:AnyObj)=>({...r,argument_keys:(r.argument_keys??[]).join(', ')}))} columns={[["created_at","Date"],["tool_name","Tool"],["status","Statut"],["argument_keys","Clés arguments"],["duration_ms","ms"],["error","Erreur"]]}/></Panel>
  </div>;
}

function AuthenticationGate({status,onAuthenticated}:{status:AnyObj|null;onAuthenticated:()=>void}) {
  const [email,setEmail]=useState('admin@datavision.local');
  const [password,setPassword]=useState('');
  const [displayName,setDisplayName]=useState('Administrateur');
  const [organizationName,setOrganizationName]=useState('DataVision Organisation');
  const [setupSecret,setSetupSecret]=useState('');
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');
  const [providers,setProviders]=useState<AnyObj[]>([]);
  useEffect(()=>{getPublicOIDCProviders().then(x=>setProviders(x.providers??[])).catch(()=>setProviders([]));},[]);
  async function finishAuth(result:AnyObj){
    let r=result;
    if(r.mfa_required){
      if(typeof navigator==='undefined'||!navigator.credentials)throw new Error('MFA WebAuthn requis mais indisponible dans ce navigateur.');
      const credential=await navigator.credentials.get({publicKey:publicKeyOptionsFromJSON(r.publicKey) as PublicKeyCredentialRequestOptions});
      if(!credential)throw new Error('Validation MFA annulée.');
      r=await verifyEnterpriseWebAuthnLogin({challenge_id:r.challenge_id,credential:publicKeyCredentialToJSON(credential)});
    }
    sessionStorage.setItem('dv_enterprise_token',r.access_token);
    if(r.refresh_token)sessionStorage.setItem('dv_enterprise_refresh',r.refresh_token);
    if(r.workspace_id)localStorage.setItem('dv_enterprise_workspace',r.workspace_id);
    onAuthenticated();
  }
  async function submit(mode:'bootstrap'|'login'){
    setBusy(true);setMessage('');
    try{
      const r=mode==='bootstrap'
        ? await bootstrapEnterprise({email,password,display_name:displayName,organization_name:organizationName,setup_secret:setupSecret})
        : await loginEnterprise({email,password});
      await finishAuth(r);
    }catch(e:unknown){setMessage(e instanceof Error?e.message:String(e));}finally{setBusy(false);}
  }
  async function startSso(providerId:string){
    if(typeof window==='undefined')return;setBusy(true);setMessage('');
    try{sessionStorage.setItem('dv_oidc_provider',providerId);const out=await startEnterpriseOIDC(providerId,window.location.origin);window.location.href=out.authorization_url;}
    catch(e:unknown){sessionStorage.removeItem('dv_oidc_provider');setMessage(e instanceof Error?e.message:String(e));setBusy(false);}
  }
  const bootstrapRequired=Boolean(status?.bootstrap_required);
  return <main className="auth-gate"><section className="auth-card" aria-labelledby="auth-title"><div className="auth-brand"><div className="brand-mark" aria-hidden="true">DV</div><div><b>DataVision AI</b><span>Secure Analytics Platform</span></div></div><div className="auth-copy"><span className="eyebrow">AUTHENTIFICATION OBLIGATOIRE</span><h1 id="auth-title">{bootstrapRequired?'Initialiser DataVision':'Se connecter à DataVision'}</h1><p>{bootstrapRequired?'Créez le premier compte administrateur et l’organisation principale.':'Une session authentifiée et un workspace autorisé sont requis pour accéder aux données et aux outils analytiques.'}</p></div>{message&&<div className="alert" role="alert"><b>Accès refusé</b><span>{message}</span></div>}<div className="stack-form"><label>Email<input autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Mot de passe<input type="password" autoComplete={bootstrapRequired?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)}/></label>{bootstrapRequired&&<><label>Nom affiché<input value={displayName} onChange={e=>setDisplayName(e.target.value)}/></label><label>Organisation<input value={organizationName} onChange={e=>setOrganizationName(e.target.value)}/></label><label>Secret d’initialisation<input type="password" autoComplete="off" value={setupSecret} onChange={e=>setSetupSecret(e.target.value)} placeholder="Secret généré lors de l’installation"/></label></>}<button className="primary-btn auth-submit" disabled={busy||!email||!password} onClick={()=>submit(bootstrapRequired?'bootstrap':'login')}>{busy?'Vérification…':bootstrapRequired?'Initialiser et se connecter':'Se connecter'}</button></div>{!bootstrapRequired&&providers.length>0&&<div className="auth-sso"><span>ou</span>{providers.map((provider:AnyObj)=><button key={provider.id} className="secondary-btn" disabled={busy} onClick={()=>startSso(provider.id)}>Continuer avec {provider.name}</button>)}</div>}<small className="auth-security-note">Sessions révocables · RBAC workspace · MFA WebAuthn/SSO selon la politique de l’organisation.</small></section></main>;
}

function GovernanceCenter({ result, setError }: { result:AnyObj|null; setError:(s:string)=>void }) {
  const [status,setStatus]=useState<AnyObj|null>(null);
  const [oidcPublic,setOidcPublic]=useState<AnyObj[]>([]);
  const [token,setToken]=useState('');
  const [session,setSession]=useState<AnyObj|null>(null);
  const [workspaceId,setWorkspaceId]=useState('');
  const [workspace,setWorkspace]=useState<AnyObj|null>(null);
  const [audit,setAudit]=useState<AnyObj[]>([]);
  const [jobs,setJobs]=useState<AnyObj[]>([]);
  const [busy,setBusy]=useState(false);
  const [email,setEmail]=useState('admin@datavision.local');
  const [password,setPassword]=useState('');
  const [displayName,setDisplayName]=useState('Administrateur');
  const [orgName,setOrgName]=useState('DataVision Organisation');
  const [newWorkspace,setNewWorkspace]=useState('Équipe Analytics');
  const [memberEmail,setMemberEmail]=useState('');
  const [memberName,setMemberName]=useState('');
  const [memberPassword,setMemberPassword]=useState('');
  const [memberRole,setMemberRole]=useState('analyst');
  const [policyName,setPolicyName]=useState('Accès analyste');
  const [policyColumns,setPolicyColumns]=useState('');
  const [policyRole,setPolicyRole]=useState('analyst');
  const [policyFilterColumn,setPolicyFilterColumn]=useState('');
  const [policyFilterOperator,setPolicyFilterOperator]=useState('eq');
  const [policyFilterValue,setPolicyFilterValue]=useState('');
  const [previewRole,setPreviewRole]=useState('analyst');
  const [jobType,setJobType]=useState('ai_analysis');
  const [jobPayload,setJobPayload]=useState('{\n  "question": "Analyse ce dataset et identifie les principaux risques et opportunités",\n  "mode": "deep"\n}');
  const [jobRetries,setJobRetries]=useState(2);
  const [jobBackoff,setJobBackoff]=useState(15);
  const [governedPreview,setGovernedPreview]=useState<AnyObj|null>(null);
  const [controlPlane,setControlPlane]=useState<AnyObj|null>(null);
  const [governanceSnapshots,setGovernanceSnapshots]=useState<AnyObj[]>([]);
  const [entrepriseReadiness,setEntrepriseReadiness]=useState<AnyObj|null>(null);

  async function loadSession(nextToken:string){
    try{
      const s=await getEnterpriseSession(nextToken); setSession(s);
      const stored=typeof window!=='undefined'?localStorage.getItem('dv_enterprise_workspace')||'':'';
      const ws=workspaceId||stored||s.workspaces?.[0]?.id||''; setWorkspaceId(ws);
      if(typeof window!=='undefined'&&ws){localStorage.setItem('dv_enterprise_workspace',ws);window.dispatchEvent(new Event('datavision-enterprise-session'));}
      if(ws) await loadWorkspace(nextToken,ws);
    }catch(e:unknown){ setSession(null); setToken(''); if(typeof window!=='undefined')sessionStorage.removeItem('dv_enterprise_token'); }
  }
  async function loadWorkspace(nextToken=token,nextWs=workspaceId){
    if(!nextToken||!nextWs)return;
    try{
      const [w,a,j,cp,snaps,readiness]=await Promise.all([
        getEnterpriseWorkspace(nextToken,nextWs),getAuditEvents(nextToken,nextWs),getEnterpriseJobs(nextToken,nextWs),
        getGovernanceControlPlane(nextToken,nextWs,result?.dataset?.id),getGovernanceSnapshots(nextToken,nextWs,20),
        getEntrepriseReadiness(nextToken,nextWs).catch(()=>null)
      ]);
      setWorkspace(w);setAudit(a.events??[]);setJobs(j.jobs??[]);setControlPlane(cp);setGovernanceSnapshots(snaps.snapshots??[]);setEntrepriseReadiness(readiness);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}
  }
  useEffect(()=>{getEnterpriseStatus().then(setStatus).catch(()=>setStatus(null));getPublicOIDCProviders().then(x=>setOidcPublic(x.providers??[])).catch(()=>setOidcPublic([]));if(typeof window!=='undefined'){const t=sessionStorage.getItem('dv_enterprise_token')||'';if(t){setToken(t);loadSession(t);}}},[]);
  useEffect(()=>{if(token&&workspaceId)loadWorkspace(token,workspaceId);},[workspaceId]);

  async function authenticate(mode:'bootstrap'|'login'){
    setBusy(true);setError('');
    try{
      let r=mode==='bootstrap'?await bootstrapEnterprise({email,password,display_name:displayName,organization_name:orgName}):await loginEnterprise({email,password});
      if(r.mfa_required){
        if(typeof navigator==='undefined'||!navigator.credentials)throw new Error('MFA WebAuthn requis mais indisponible dans ce navigateur.');
        const credential=await navigator.credentials.get({publicKey:publicKeyOptionsFromJSON(r.publicKey) as PublicKeyCredentialRequestOptions});
        if(!credential)throw new Error('Validation MFA annulée.');
        r=await verifyEnterpriseWebAuthnLogin({challenge_id:r.challenge_id,credential:publicKeyCredentialToJSON(credential)});
      }
      setToken(r.access_token); if(typeof window!=='undefined'){sessionStorage.setItem('dv_enterprise_token',r.access_token);if(r.refresh_token)sessionStorage.setItem('dv_enterprise_refresh',r.refresh_token);} await loadSession(r.access_token);
    }catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}
  }
  function logout(){setToken('');setSession(null);setWorkspace(null);setAudit([]);setJobs([]);setControlPlane(null);setGovernanceSnapshots([]);setEntrepriseReadiness(null);if(typeof window!=='undefined'){sessionStorage.removeItem('dv_enterprise_token');sessionStorage.removeItem('dv_enterprise_refresh');localStorage.removeItem('dv_enterprise_workspace');window.dispatchEvent(new Event('datavision-enterprise-session'));}}
  async function startSso(providerId:string){if(typeof window==='undefined')return;setBusy(true);try{sessionStorage.setItem('dv_oidc_provider',providerId);const out=await startEnterpriseOIDC(providerId,window.location.origin);window.location.href=out.authorization_url;}catch(e:unknown){sessionStorage.removeItem('dv_oidc_provider');setError(e instanceof Error?e.message:String(e));setBusy(false);}}
  async function createWs(){if(!token||!session?.organizations?.[0]?.id)return;setBusy(true);try{await createEnterpriseWorkspace(token,session.organizations[0].id,newWorkspace);await loadSession(token);}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function provisionMember(){if(!token||!workspaceId||!memberEmail)return;setBusy(true);try{await addWorkspaceMember(token,workspaceId,memberEmail,memberRole,memberName,memberPassword);setMemberEmail('');setMemberName('');setMemberPassword('');await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function bindCurrent(){if(!token||!workspaceId||!result)return;setBusy(true);try{await bindWorkspaceDataset(token,workspaceId,result.dataset.id);await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function previewGoverned(){if(!token||!workspaceId||!result)return;setBusy(true);try{setGovernedPreview(await getGovernedPreview(token,workspaceId,result.dataset.id,25,previewRole));}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function captureGovernance(){if(!token||!workspaceId||!result)return;setBusy(true);try{await captureGovernanceSnapshot(token,workspaceId,result.dataset.id);await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function createPolicy(){if(!token||!workspaceId||!result)return;setBusy(true);try{const cols=policyColumns.split(',').map(x=>x.trim()).filter(Boolean);const row_filters=policyFilterColumn?[{column:policyFilterColumn,operator:policyFilterOperator,value:policyFilterValue}]:[];await saveWorkspacePolicy(token,workspaceId,{dataset_id:result.dataset.id,name:policyName,allowed_columns:cols,row_filters,applies_to_role:policyRole});await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function submitJob(){if(!token||!workspaceId||!result)return;setBusy(true);try{const payload=JSON.parse(jobPayload||'{}');await submitEnterpriseJob(token,{workspace_id:workspaceId,organization_id:workspace?.workspace?.organization_id,job_type:jobType,dataset_id:result.dataset.id,payload,max_retries:jobRetries,retry_backoff_seconds:jobBackoff});await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function enforcePrivateAI(){if(!token||!workspaceId)return;setBusy(true);try{await enforceEntreprisePrivateAI(token,workspaceId);await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false)}}
  async function cancelJob(id:string){try{await cancelEnterpriseJob(token,id);await loadWorkspace();}catch(e:unknown){setError(e instanceof Error?e.message:String(e));}}

  if(!session) return <div className="page governance-page"><div className="page-title"><div><span className="eyebrow">TENANT-AWARE SECURITY</span><h1>Gouvernance & sécurité</h1><p>Identité, workspaces, RBAC, RLS et sécurité colonne appliqués au pipeline analytique complet. L’authentification est obligatoire par défaut. Le mode local anonyme n’est disponible qu’en développement explicite.</p></div><span className="module-state implemented">Entreprise v2.58</span></div>
    <div className="governance-intro-grid">
      <Panel title="Initialiser DataVision Entreprise"><div className="stack-form"><label>Email administrateur<input value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Mot de passe<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="8 caractères minimum"/></label><div className="two-col"><label>Nom affiché<input value={displayName} onChange={e=>setDisplayName(e.target.value)}/></label><label>Organisation<input value={orgName} onChange={e=>setOrgName(e.target.value)}/></label></div><div className="button-row"><RunButton busy={busy} label="Initialiser" busyLabel="Initialisation…" onClick={()=>authenticate('bootstrap')}/><button className="secondary-btn" disabled={busy} onClick={()=>authenticate('login')}>Se connecter</button></div><small className="help-text">Le bootstrap ne fonctionne qu’une seule fois. Ensuite, utilisez la connexion.</small></div></Panel>
      <Panel title="Connexion d’entreprise"><div className="sso-login-panel">{oidcPublic.length?oidcPublic.map((p:AnyObj)=><button key={p.id} className="sso-provider-btn" disabled={busy} onClick={()=>startSso(p.id)}><span>SSO</span><div><b>Continuer avec {p.name}</b><small>Connexion OIDC sécurisée</small></div><i>→</i></button>):<div className="quiet-empty">Aucun fournisseur SSO actif. Un Owner/Admin peut en configurer un dans Identité & Secrets.</div>}</div></Panel>
      <Panel title="Architecture Entreprise"><div className="enterprise-status-list"><div><span>Metadata store</span><b>{status?.metadata?.url??'—'}</b><small>{status?.metadata?.dialect??'Non connecté'}</small></div><div><span>RBAC</span><b>Owner → Viewer</b><small>Permissions explicites par workspace</small></div><div><span>Jobs</span><b>{status?.queue?.available?'Redis opérationnel':'Redis à vérifier'}</b><small>{status?.queue?.available?`${status.queue.queue_depth??0} job(s) en attente`:'Le worker nécessite Redis'}</small></div><div><span>OIDC / SSO</span><b>Authorization Code + PKCE</b><small>RS256, JIT provisioning et domaines autorisés</small></div></div></Panel>
    </div></div>;

  const wsOptions=session.workspaces??[]; const detail=workspace?.workspace; const governedDatasets=workspace?.datasets??[]; const governancePolicies=workspace?.policies??[];
  return <div className="page governance-page"><div className="page-title"><div><span className="eyebrow">TENANT-AWARE SECURITY</span><h1>Gouvernance & sécurité</h1><p>Administration des workspaces, rôles et politiques. Les mêmes restrictions sont maintenant appliquées à SQL, statistiques, ML, AI Analyst, dashboards, rapports et jobs.</p></div><div className="governance-user"><span>{session.user?.display_name}</span><b>{session.user?.email}</b><button onClick={logout}>Déconnexion</button></div></div>
    <div className="governance-toolbar"><label>Workspace<select value={workspaceId} onChange={e=>{const id=e.target.value;setWorkspaceId(id);if(typeof window!=='undefined'){localStorage.setItem('dv_enterprise_workspace',id);window.dispatchEvent(new Event('datavision-enterprise-session'));}}}>{wsOptions.map((w:AnyObj)=><option key={w.id} value={w.id}>{w.name} · {w.role}</option>)}</select></label><div className="workspace-create-inline"><input value={newWorkspace} onChange={e=>setNewWorkspace(e.target.value)} placeholder="Nouveau workspace"/><button onClick={createWs} disabled={busy}>+ Créer</button></div><button className="secondary-btn" onClick={()=>loadWorkspace()} disabled={busy}>↻ Actualiser</button></div>
    <div className="governance-scorecards"><Stat label="Rôle actif" value={detail?.role??'—'} detail="RBAC workspace"/><Stat label="Membres" value={detail?.members_count??0} detail="Utilisateurs autorisés"/><Stat label="Datasets" value={detail?.datasets_count??0} detail="Ressources liées"/><Stat label="Politiques" value={workspace?.policies?.length??0} detail="Colonnes / lignes"/><Stat label="Jobs" value={jobs.length} detail="Historique asynchrone"/></div>
    <Panel title="Posture Entreprise · v2.58" action={<div className="button-row"><span className={`control-plane-status ${Number(entrepriseReadiness?.score??0)>=80?'pass':Number(entrepriseReadiness?.score??0)>=50?'warn':'fail'}`}>{entrepriseReadiness?.score??0}%</span><button className="secondary-btn" onClick={enforcePrivateAI} disabled={busy||entrepriseReadiness?.private_ai?.strict_private_ai===true}>Forcer Private AI</button></div>}>
      {entrepriseReadiness?<><div className="control-plane-grid"><div className="control-list">{(entrepriseReadiness.checks??[]).map((c:AnyObj)=><article key={c.id} className={`control-item ${c.status}`}><span>{c.status==='pass'?'✓':c.status==='fail'?'×':'!'}</span><div><b>{c.label}</b><small>{c.detail}</small></div></article>)}</div><div className="control-plane-side"><h4>Déploiement</h4><div className="role-matrix"><div><b>{entrepriseReadiness.deployment?.profile??'—'}</b><span>Profil de déploiement</span><small>Egress externe : {entrepriseReadiness.deployment?.external_egress_policy??'—'}</small></div><div><b>{entrepriseReadiness.private_ai?.privacy_mode??'—'}</b><span>Private AI</span><small>IA externe : {entrepriseReadiness.private_ai?.allow_external_ai?'autorisée':'bloquée'}</small></div><div><b>{entrepriseReadiness.scim?.active_tokens??0} / {entrepriseReadiness.scim?.groups??0}</b><span>SCIM jetons / groupes</span><small>Users + Groups 2.0</small></div><div><b>{entrepriseReadiness.kms?.provider??'local'}</b><span>KMS / HSM</span><small>{entrepriseReadiness.kms?.external_kms?'Clé externe':'Clé locale'} · HSM {entrepriseReadiness.kms?.hsm_backed?'oui':'non'}</small></div><div><b>{entrepriseReadiness.session_device_policy?.idle_timeout_minutes??'—'} min</b><span>Session / appareil</span><small>{entrepriseReadiness.session_device_policy?.max_active_sessions??'—'} session(s) max · appareil géré {entrepriseReadiness.session_device_policy?.require_managed_device?'requis':'optionnel'}</small></div></div></div></div><div className="publication-readiness"><b>Socle Entreprise : {entrepriseReadiness.ready?'prêt':'à compléter'}</b><span>SSO/MFA · SCIM Users/Groups · KMS/HSM · sessions/appareils · Private AI · OpenTelemetry · Helm/Kubernetes.</span></div></>:<div className="quiet-empty">Posture Entreprise indisponible pour ce workspace.</div>}
    </Panel>
    <RegulatoryCompliancePanel token={token} workspaceId={workspaceId} setError={setError}/>
    <Panel title="Governance Control Plane" action={<div className="button-row"><span className={`control-plane-status ${controlPlane?.control_status??'unknown'}`}>{controlPlane?.control_status??'—'}</span>{result&&<button className="secondary-btn" onClick={captureGovernance} disabled={busy}>Capturer un snapshot</button>}</div>}>
      <div className="control-plane-summary"><div><span>Couverture des contrôles</span><b>{controlPlane?.control_coverage_percent??0}%</b><small>Critères déterministes configurés / sains</small></div><div><span>Audit digest</span><b>{String(controlPlane?.audit_digest_sha256??'—').slice(0,16)}</b><small>SHA-256 des événements récents</small></div><div><span>Lineage</span><b>{controlPlane?.summary?.lineage?.nodes??0} / {controlPlane?.summary?.lineage?.edges??0}</b><small>nœuds / relations</small></div><div><span>IA</span><b>{controlPlane?.ai?.settings?.planner_mode??'—'}</b><small>{controlPlane?.ai?.settings?.privacy_mode??'—'}</small></div></div>
      <div className="control-plane-grid"><div className="control-list">{(controlPlane?.controls??[]).map((c:AnyObj)=><article key={c.id} className={`control-item ${c.status}`}><span>{c.status==='pass'?'✓':c.status==='fail'?'×':'!'}</span><div><b>{c.name}</b><small>{c.evidence}</small></div></article>)}{!controlPlane&&<div className="quiet-empty">Control Plane indisponible.</div>}</div><div className="control-plane-side"><h4>Matrice d'accès effective</h4>{(controlPlane?.dataset?.role_matrix??[]).length?<div className="role-matrix">{(controlPlane?.dataset?.role_matrix??[]).map((r:AnyObj)=><div key={r.role}><b>{r.role}</b><span>{r.allowed_column_count}/{r.total_column_count} colonnes</span><small>{r.row_filter_count} filtre(s) ligne · {r.policy_count} politique(s)</small></div>)}</div>:<div className="quiet-empty">Liez et activez un dataset pour calculer la matrice.</div>}<h4>Snapshots</h4><div className="governance-snapshots">{governanceSnapshots.slice(0,5).map((x:AnyObj)=><div key={x.id}><b>{x.control_coverage_percent??'—'}%</b><span>{x.control_status}</span><small>{x.created_at?new Date(x.created_at).toLocaleString('fr-FR'):''} · {String(x.sha256??'').slice(0,10)}</small></div>)}{!governanceSnapshots.length&&<div className="quiet-empty">Aucun snapshot capturé.</div>}</div></div></div>
      {controlPlane?.dataset&&<div className="publication-readiness"><b>Publication dataset : {controlPlane.dataset.publication?.allowed?'autorisée':'bloquée'}</b><span>{(controlPlane.dataset.publication?.blockers??[]).length} bloqueur(s) · {(controlPlane.dataset.publication?.warnings??[]).length} avertissement(s) · {(controlPlane.dataset.certifications??[]).length} certification(s) active(s) · Trust {controlPlane.dataset.trust?.overall_score??'—'}/100</span></div>}
    </Panel>
    <div className="two-col governance-main-grid">
      <Panel title="Membres & rôles" action={<span className="quiet">owner · admin · data scientist · analyst · viewer</span>}><div className="member-table">{(workspace?.members??[]).map((m:AnyObj)=><div key={m.id}><div className="member-avatar">{String(m.display_name||m.email).slice(0,2).toUpperCase()}</div><div><b>{m.display_name}</b><small>{m.email}</small></div><span className={`role-pill role-${m.role}`}>{m.role}</span></div>)}</div><details className="governance-details"><summary>Provisionner / ajouter un membre</summary><div className="stack-form compact-governance-form"><label>Email<input value={memberEmail} onChange={e=>setMemberEmail(e.target.value)}/></label><label>Nom<input value={memberName} onChange={e=>setMemberName(e.target.value)}/></label><label>Mot de passe initial<input type="password" value={memberPassword} onChange={e=>setMemberPassword(e.target.value)} placeholder="Requis si nouvel utilisateur"/></label><label>Rôle<select value={memberRole} onChange={e=>setMemberRole(e.target.value)}>{['admin','data_scientist','analyst','viewer'].map(r=><option key={r}>{r}</option>)}</select></label><button className="primary-btn" onClick={provisionMember}>Ajouter / mettre à jour</button></div></details></Panel>
      <Panel title="Datasets gouvernés" action={result?<div className="button-row governance-access-test"><button className="secondary-btn" onClick={bindCurrent}>Lier le dataset actif</button><select value={previewRole} onChange={e=>setPreviewRole(e.target.value)}><option value="data_scientist">Data scientist</option><option value="analyst">Analyst</option><option value="viewer">Viewer</option></select><button className="secondary-btn" onClick={previewGoverned}>Tester l’accès</button></div>:undefined}><div className="governed-resource-list">{governedDatasets.length?governedDatasets.map((d:AnyObj)=><div key={d.dataset_id}><span>▦</span><div><b>{d.dataset_id.slice(0,12)}…</b><small>lié le {new Date(d.created_at).toLocaleString('fr-FR')}</small></div></div>):<div className="quiet-empty">Aucun dataset lié à ce workspace.</div>}</div>{governedPreview&&<div className="governed-preview-summary"><b>Aperçu gouverné · {governedPreview.effective_role??previewRole}</b><span>{governedPreview.total_rows} lignes · {(governedPreview.columns??[]).length} colonnes</span><small>{(governedPreview.columns??[]).join(' · ')}</small></div>}{result&&<details className="governance-details"><summary>Créer une politique sur le dataset actif</summary><div className="stack-form compact-governance-form"><label>Nom<input value={policyName} onChange={e=>setPolicyName(e.target.value)}/></label><label>Colonnes autorisées<input value={policyColumns} onChange={e=>setPolicyColumns(e.target.value)} placeholder="region, sales, margin"/></label><label>Rôle<select value={policyRole} onChange={e=>setPolicyRole(e.target.value)}>{['data_scientist','analyst','viewer'].map(r=><option key={r}>{r}</option>)}</select></label><div className="policy-filter-builder"><label>Filtre ligne (optionnel)<select value={policyFilterColumn} onChange={e=>setPolicyFilterColumn(e.target.value)}><option value="">Aucun</option>{(result?.profile?.columns??[]).map((c:AnyObj)=><option key={c.name} value={c.name}>{c.name}</option>)}</select></label><label>Opérateur<select value={policyFilterOperator} onChange={e=>setPolicyFilterOperator(e.target.value)}>{['eq','neq','gt','gte','lt','lte','contains'].map(op=><option key={op} value={op}>{op}</option>)}</select></label><label>Valeur<input value={policyFilterValue} onChange={e=>setPolicyFilterValue(e.target.value)}/></label></div><button className="primary-btn" onClick={createPolicy}>Enregistrer la politique</button></div></details>}</Panel>
    </div>
    <div className="two-col governance-main-grid">
      <Panel title="Jobs asynchrones" action={result?<button className="secondary-btn" onClick={submitJob}>Mettre en file</button>:undefined}>{result&&<div className="job-compose"><select value={jobType} onChange={e=>setJobType(e.target.value)}><option value="ai_analysis">AI Analyst</option><option value="automl">AutoML</option><option value="forecast">Forecasting</option><option value="report">Rapport</option><option value="proactive_scan">Proactive scan</option></select><div><textarea value={jobPayload} onChange={e=>setJobPayload(e.target.value)} spellCheck={false}/><div className="job-retry-config"><label>Retries max<input type="number" min={0} max={5} value={jobRetries} onChange={e=>setJobRetries(Math.max(0,Math.min(5,Number(e.target.value)||0)))}/></label><label>Backoff initial (s)<input type="number" min={1} max={3600} value={jobBackoff} onChange={e=>setJobBackoff(Math.max(1,Math.min(3600,Number(e.target.value)||1)))}/></label></div></div></div>}<div className="job-list">{jobs.length?jobs.slice(0,12).map((j:AnyObj)=><div key={j.id}><span className={`job-status ${j.status}`}>{j.status}</span><div><b>{j.job_type}</b><small>{j.dataset_id?`${j.dataset_id.slice(0,10)}… · `:''}{j.created_at?new Date(j.created_at).toLocaleString('fr-FR'):''}</small></div><div className="job-progress"><i style={{width:`${Number(j.progress)||0}%`}}/></div>{!['completed','failed','cancelled'].includes(j.status)&&<button onClick={()=>cancelJob(j.id)}>Annuler</button>}</div>):<div className="quiet-empty">Aucun job pour ce workspace.</div>}</div></Panel>
      <Panel title="Journal d’audit" action={<span className="quiet">{audit.length} événement(s)</span>}><div className="audit-timeline">{audit.length?audit.slice(0,16).map((e:AnyObj)=><div key={e.id}><span className={e.outcome==='success'?'audit-dot ok':'audit-dot bad'}/><div><b>{e.event_type}</b><small>{e.resource_type||'system'}{e.resource_id?` · ${String(e.resource_id).slice(0,12)}…`:''}</small></div><time>{e.created_at?new Date(e.created_at).toLocaleString('fr-FR'):''}</time></div>):<div className="quiet-empty">Le journal est vide.</div>}</div></Panel>
    </div>
    <Panel title="Politiques d’accès" action={<span className="quiet">Fondation RLS / sécurité colonne</span>}><div className="policy-grid">{governancePolicies.length?governancePolicies.map((p:AnyObj)=><article key={p.id}><div><span>POLICY</span><b>{p.name}</b></div><p>Rôle : <strong>{p.applies_to_role||'tous'}</strong></p><p>Colonnes : {(p.allowed_columns??[]).length?(p.allowed_columns??[]).join(', '):'toutes'}</p><small>{(p.row_filters??[]).length} filtre(s) de lignes</small></article>):<div className="quiet-empty">Aucune politique enregistrée.</div>}</div><div className="governance-success"><b>Security boundary active</b><span>Le contexte workspace est injecté dans toutes les routes dataset. RLS, sécurité colonne et RBAC s’appliquent aux moteurs statistiques, SQL, ML, AI Analyst, dashboards, rapports et jobs asynchrones.</span></div></Panel>
  </div>;
}
